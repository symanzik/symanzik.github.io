swe.svd.mcmc <- function(Y, q, n.mcmc, mm = NULL, outdat = 100){

#
#  Mevin Hooten, James Odei & Juergen Symansik (20081212)
#
#  Y is a T by m matrix with T = number of years, m = number of days
#  q is number of important signals chosen for dimension reduction
#  n.mcmc is number of simulations to be done
#  outdat is the day after which forecasting is done based on the Posterior Distribution 
#
#
#  20081212:  Updated from swe.svd.mcmc.R to do all alphas and seasonal autocorrelation.
#  20081219:  Continued debugging and improvements. 
#  20081231:  Added conditional MVN posterior predictive sampler also improved speed.
#


####
####  Subroutines and Libraries
####

require(MCMCpack)
require(mvtnorm)
require(spdep)
require(msm)
source("invgammastrt.R")

makeW <- function(m){
#  W <- matrix(0, m, m)
#  diag(W[1:(m-1), 2:m]) <- 1
#  diag(W[2:m, 1:(m-1)]) <- 1
#  W<- W/apply(W, 1, sum)

 W <- as.matrix(as_dsTMatrix_listw(similar.listw(nb2listw(knn2nb(knearneigh(cbind(rep(1, m), 
                1:m)), sym = TRUE), style = "W"))))
 W
}


####
####  Setup Variables
####

T <- dim(Y)[1] - 1
m <- dim(Y)[2]
Y.c <- scale(Y[-(T + 1), ], scale = FALSE)
mu <- attributes(Y.c)[[2]]
Y.svd <- svd(Y.c)
U <- Y.svd$u
D <- diag(Y.svd$d)
V <- Y.svd$v[, 1:q]
X <- (U%*%D)[, 1:q]

Y.Tplus1 <- Y[T + 1, ]

if(is.null(mm)){
  mm <- max((1:m)[!is.na(Y.Tplus1)])
}

#s2.save <- matrix(0, m, n.mcmc)
s2.save <- rep(0, n.mcmc)
rho.save <- rep(0, n.mcmc)
alpha.mean <- matrix(0, q, T + 1)
alpha.save <- matrix(0, q, n.mcmc)
alpha.Tplus1.save <- matrix(0, q, n.mcmc)
Y.pred <- matrix(Y[T + 1, ], m, n.mcmc)
Y.max <- apply(Y[1:T, ], 2, max)


####
####  Priors and Starting Values 
####

s2alpha <- 10
s2rho <- 4
taualpha <- 100
s2mn <- 10
s2var <- 100
rr <- invgammastrt(s2mn, s2var)$r
qq <- invgammastrt(s2mn, s2var)$q

alphat <- matrix(0, q, T+1)
alpha <- rep(0, q)
s2 <- 1
rho <- 0.99
rho.tune <- 0.01
Phi <- diag(m)
R <- solve(diag(m) - rho * makeW(m))%*%Phi
Rinv <- solve(R)
Sig <- s2 * R
Siginv <- solve(Sig)

MU <- mu + V%*%t(X)


####
####  Initialize Timing Variables 
####

time1 <- proc.time()
time2 <- time1
timeidx <- 0


####
####  Begin MCMC Loop 
####

for(k in 1:n.mcmc){
  #cat(k, " ")

  ###
  ### Timing Calculations
  ###

  if(k==12){
    tentime <- (proc.time()-time1)[3]
    #cat("\n", tentime * (n.mcmc/600), "expected minutes", "\n")
  }
  if(k%%100==0){
    timeidx <- timeidx + 1
    elapsetime <- (proc.time()-time2)[3]
    #cat("\n", elapsetime/60, "elapsed minutes", " ")
    leftidx <- n.mcmc/100 - timeidx
    #cat(" ", (elapsetime/timeidx) * leftidx/60, "remaining minutes", "\n")
  }

  ####
  ####  Sample alpha_t 
  ####
  
  #cat("a_t", " ")

  for(t in 2:T){
    alpha.var <- solve(diag(X[t - 1, ])%*%t(V)%*%Siginv%*%V%*%diag(X[t - 1, ]) + 
                 diag(q)/s2alpha)
                 
    alpha.mn <- alpha.var%*%t(c(Y[t] - mu)%*%Siginv%*%V%*%diag(X[t - 1, ]) + 
                alpha/s2alpha)
                 
    alphat[, t] <- rmvnorm(1, alpha.mn, alpha.var, method = "chol")
  }
  
  alpha.var <- solve(diag(X[T, ])%*%t(V[1:mm, ])%*%solve(Sig[1:mm, 1:mm])%*%V[1:mm, ]%*%     
               diag(X[T, ]) + diag(q)/s2alpha)
                
  alpha.mn <- alpha.var%*%t(c(Y.Tplus1[1:mm] - mu[1:mm])%*%solve(Sig[1:mm, 1:mm])%*%V[1:mm, ]%*%   
              diag(X[T, ]) + alpha/s2alpha)
               
  alphat[, T + 1] <- rmvnorm(1, alpha.mn, alpha.var, method = "chol")

  
  ####
  ####  Sample alpha 
  ####
  
  #cat("a", " ")

  alpha.var <- solve(T * diag(q)/s2alpha + diag(q)/taualpha)
  alpha.mn <- alpha.var%*%(apply(alphat, 1, sum)/s2alpha)
  alpha <- rmvnorm(1, alpha.mn, alpha.var, method = "chol")


  ####
  ####  Sample s2 
  ####
  
  #cat("s2", " ")

  tmpsum <- sum(diag((Y[1:T, ] - t(MU[, 1:T]))%*%Rinv%*%t(Y[1:T, ] - t(MU[, 1:T]))))

  rstar <- 1/(tmpsum/2 + 1/rr)
  qstar <- (m * T)/2 + qq
  s2 <- 1/rgamma(1, qstar, ,rstar)

  Sig <- s2 * R
  Siginv <- solve(Sig)

  
  ####
  ####  Sample rho 
  ####
  
  #cat("rho", " ")

  rho.star <- rtnorm(1, rho, rho.tune, -1, 1)
  
  #cat(rho, rho.star, " ")

  R.star <- solve(diag(m) - rho.star * makeW( m))%*%Phi
  Sig.star <- s2 * R.star

  tmpsum1 <- -sum(log(eigen(Sig.star, symmetric = TRUE, only.values = TRUE)$values)) -
              sum(diag((Y[2:T, ] - t(MU[, 2:T]))%*%solve(Sig.star)%*%
              t(Y[2:T, ] - t(MU[, 2:T]))))
              
  tmpsum2 <- -sum(log(eigen(Sig, symmetric = TRUE, only.values = TRUE)$values)) - 
              sum(diag((Y[2:T, ] - t(MU[, 2:T]))%*%
              Siginv%*%t(Y[2:T, ] - t(MU[, 2:T]))))

  mh1 <- tmpsum1 + dtnorm(rho.star, 0, sqrt(s2rho), -1, 1, log = TRUE) + 
         dtnorm(rho, rho.star, sqrt(s2rho), -1, 1, log = TRUE)
  mh2 <- tmpsum2 + dtnorm(rho, 0, sqrt(s2rho), -1, 1, log = TRUE) + 
         dtnorm(rho.star, rho, sqrt(s2rho), -1, 1, log = TRUE)
         
  mh <- exp(mh1-mh2)
  if(mh > runif(1)){
    rho <- rho.star
    Sig <- Sig.star
    R <- R.star
    Rinv <- solve(R.star)
    Siginv <- solve(Sig)
  }   


  ####
  ####  Save Samples 
  ####

  alpha.mean <- alpha.mean + alphat/n.mcmc
  alpha.save[, k] <- alpha
  rho.save[k] <- rho
  s2.save[k] <- s2

  
  ####
  ####  Get Predictions 
  ####
  
  #cat("pred", "\n")
  
  Sig.obs.inv <- solve(Sig[1:mm, 1:mm])
  
  Y.pred.mn <- V%*%diag(c(alphat[, T + 1]))%*%X[T, ] + mu
  
  Y.pp.mn <- Y.pred.mn[(mm + 1):m] + Sig[(mm + 1):m, 1:mm]%*%Sig.obs.inv%*%
             (Y[T + 1, 1:mm] - Y.pred.mn[1:mm])
             
  Y.pp.Sig <- Sig[(mm + 1):m, (mm + 1):m] - Sig[(mm + 1):m, 1:mm]%*%
              Sig.obs.inv%*%Sig[1:mm, (mm + 1):m]
 
  Y.pred[(mm + 1):m, k] <- rmvnorm(1, Y.pp.mn, Y.pp.Sig, method = "chol")
  Y.pred[, k][Y.pred[, k] < 0] <- 0
  Y.pred[, k][Y.pred[, k] > Y.max] <- Y.max[Y.pred[, k] > Y.max]

  
  ####
  ####  Write Temporary Output 
  ####

  if(k%%outdat==0){
   tmpout <- list(n.mcmc = n.mcmc, alpha.save = alpha.save, s2.save = s2.save, 
                 Y = Y, Y.pred = Y.pred, mu = mu, mm = mm, rho.save = rho.save, 
                 alpha.mean = alpha.mean, Y.svd = Y.svd)
   save(tmpout, file = "tmpout.RData")
  }
}

#cat("\n")

####
####  Write Output 
####

list(n.mcmc = n.mcmc, alpha.save = alpha.save, s2.save = s2.save, Y = Y, mu = mu, mm = mm, 
     Y.pred = Y.pred, rho.save = rho.save, alpha.mean = alpha.mean, Y.svd = Y.svd)
}
