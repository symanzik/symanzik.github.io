utah.snotel.historical.data <- function(n.sites, current.year){

##
## Example:  swe.utah <- utah.snotel.historical.data(n.sites = 90, current.year = 2009)
##

u <- rep(NA, n.sites)

u[1] <- "Historical_Data/12m26s_s.txt"
u[2] <- "Historical_Data/11k13s_s.txt"
u[3] <- "Historical_Data/11j46s_s.txt"
u[4] <- "Historical_Data/11h08s_s.txt"
u[5] <- "Historical_Data/11h30s_s.txt"
u[6] <- "Historical_Data/12l07s_s.txt"
u[7] <- "Historical_Data/11l04s_s.txt"
u[8] <- "Historical_Data/12l04s_s.txt"
u[9] <- "Historical_Data/11j57s_s.txt"
u[10] <- "Historical_Data/10j30s_s.txt"
u[11] <- "Historical_Data/11k31s_s.txt"
u[12] <- "Historical_Data/11h37s_s.txt"
u[13] <- "Historical_Data/09m02s_s.txt"
u[14] <- "Historical_Data/11j70s_s.txt"
u[15] <- "Historical_Data/12m13s_s.txt"
u[16] <- "Historical_Data/11j01s_s.txt"
u[17] <- "Historical_Data/11j02s_s.txt"
u[18] <- "Historical_Data/10j43s_s.txt"
u[19] <- "Historical_Data/11m06s_s.txt"
u[20] <- "Historical_Data/11k21s_s.txt"
u[21] <- "Historical_Data/11k22s_s.txt"
u[22] <- "Historical_Data/11j32s_s.txt"
u[23] <- "Historical_Data/11j23s_s.txt"
u[24] <- "Historical_Data/11k15s_s.txt"
u[25] <- "Historical_Data/11l05s_s.txt"
u[26] <- "Historical_Data/11h55s_s.txt"
u[27] <- "Historical_Data/12j09s_s.txt"
u[28] <- "Historical_Data/09k01s_s.txt"
u[29] <- "Historical_Data/11j11s_s.txt"
u[30] <- "Historical_Data/11j12s_s.txt"
u[31] <- "Historical_Data/11l01s_s.txt"
u[32] <- "Historical_Data/10j26s_s.txt"
u[33] <- "Historical_Data/13m07s_s.txt"
u[34] <- "Historical_Data/11l12s_s.txt"
u[35] <- "Historical_Data/13m06s_s.txt"
u[36] <- "Historical_Data/11j37s_s.txt"
u[37] <- "Historical_Data/12m05s_s.txt"
u[38] <- "Historical_Data/10j44s_s.txt"
u[39] <- "Historical_Data/10j04s_s.txt"
u[40] <- "Historical_Data/09j08s_s.txt"
u[41] <- "Historical_Data/10j01s_s.txt"
u[42] <- "Historical_Data/11h21s_s.txt"
u[43] <- "Historical_Data/10k01s_s.txt"
u[44] <- "Historical_Data/12l20s_s.txt"
u[45] <- "Historical_Data/12l06s_s.txt"
u[46] <- "Historical_Data/09j01s_s.txt"
#u[47] <- "Historical_Data/11h01s_s.txt"
u[47] <- "Historical_Data/13m05s_s.txt"
u[48] <- "Historical_Data/10j10s_s.txt"
u[49] <- "Historical_Data/10j25s_s.txt"
u[50] <- "Historical_Data/09l03s_s.txt"
u[51] <- "Historical_Data/11h59s_s.txt"
u[52] <- "Historical_Data/10j35s_s.txt"
u[53] <- "Historical_Data/11h25s_s.txt"
u[54] <- "Historical_Data/13m04s_s.txt"
u[55] <- "Historical_Data/13m02s_s.txt"
u[56] <- "Historical_Data/12m06s_s.txt"
u[57] <- "Historical_Data/11j64s_s.txt"
u[58] <- "Historical_Data/11j69s_s.txt"
u[59] <- "Historical_Data/11k03s_s.txt"
u[60] <- "Historical_Data/12l12s_s.txt"
u[61] <- "Historical_Data/12m23s_s.txt"
u[62] <- "Historical_Data/11j65s_s.txt"
u[63] <- "Historical_Data/12j07s_s.txt"
u[64] <- "Historical_Data/11h57s_s.txt"
u[65] <- "Historical_Data/09j05s_s.txt"
u[66] <- "Historical_Data/11j52s_s.txt"
u[67] <- "Historical_Data/11j68s_s.txt"
u[68] <- "Historical_Data/11k52s_s.txt"
u[69] <- "Historical_Data/11k39s_s.txt"
u[70] <- "Historical_Data/12l15s_s.txt"
u[71] <- "Historical_Data/11k28s_s.txt"
u[72] <- "Historical_Data/10j18s_s.txt"
u[73] <- "Historical_Data/12j06s_s.txt"
u[74] <- "Historical_Data/11k09s_s.txt"
u[75] <- "Historical_Data/11j53s_s.txt"
u[76] <- "Historical_Data/11j42s_s.txt"
u[77] <- "Historical_Data/10j20s_s.txt"
u[78] <- "Historical_Data/11j08s_s.txt"
u[79] <- "Historical_Data/11h58s_s.txt"
u[80] <- "Historical_Data/10k06s_s.txt"
u[81] <- "Historical_Data/11j56s_s.txt"
u[82] <- "Historical_Data/11j21s_s.txt"
u[83] <- "Historical_Data/11h36s_s.txt"
#u[85] <- "Historical_Data/11h03s_s.txt"
u[84] <- "Historical_Data/10j52s_s.txt"
u[85] <- "Historical_Data/09j16s_s.txt"
u[86] <- "Historical_Data/11h60s_s.txt"
u[87] <- "Historical_Data/12k01s_s.txt"
u[88] <- "Historical_Data/12m03s_s.txt"
u[89] <- "Historical_Data/10k02s_s.txt"
u[90] <- "Historical_Data/11m03s_s.txt"

s <- rep(NA, n.sites)

s[1] <- 1995
s[2] <- 1981
s[3] <- 1979
s[4] <- 1979
s[5] <- 1981
s[6] <- 1980
s[7] <- 1982
s[8] <- 1980
s[9] <- 1987
s[10] <- 1979
s[11] <- 1980
s[12] <- 1979
s[13] <- 1986
s[14] <- 2003
s[15] <- 1981
s[16] <- 1979
s[17] <- 1979
s[18] <- 1982
s[19] <- 2001
s[20] <- 1980
s[21] <- 1980
s[22] <- 1979
s[23] <- 1979
s[24] <- 1980 ## missing year 1980
s[25] <- 1986
s[26] <- 1979
s[27] <- 1995
s[28] <- 1986
s[29] <- 1979
s[30] <- 2004
s[31] <- 1981
s[32] <- 1982
s[33] <- 2005
s[34] <- 1981 ## missing years 1979, and 1981
s[35] <- 2005
s[36] <- 1994
s[37] <- 1980
s[38] <- 1979
s[39] <- 1986
s[40] <- 1986
s[41] <- 1986
s[42] <- 1979
s[43] <- 1980
s[44] <- 2008
s[45] <- 1981
s[46] <- 1980
#s[47] <- 2009
s[47] <- 1980
s[48] <- 1980
s[49] <- 1990
s[50] <- 1982
s[51] <- 2005
s[52] <- 1982
s[53] <- 1979
s[54] <- 1986
s[55] <- 1982
s[56] <- 1986
s[57] <- 1988
s[58] <- 2000
s[59] <- 1980
s[60] <- 1981
s[61] <- 1982
s[62] <- 1989
s[63] <- 1989
s[64] <- 1979
s[65] <- 1979
s[66] <- 1979
s[67] <- 2000
s[68] <- 1981
s[69] <- 1979
s[70] <- 1986
s[71] <- 1981 # missing years 1979, and 1981
s[72] <- 1981
s[73] <- 1982
s[74] <- 1982
s[75] <- 1979
s[76] <- 1990
s[77] <- 1979
s[78] <- 1979
s[79] <- 2002
s[80] <- 2008
s[81] <- 1988
s[82] <- 1979
s[83] <- 1979
#s[85] <- 2009
s[84] <- 1979
s[85] <- 1980
s[86] <- 2007
s[87] <- 1979
s[88] <- 1981
s[89] <- 1980 # missing year 1983
s[90] <- 1979


#source("read.snotel.R")

snotel.list <- vector("list", length = n.sites)

T.vec <- rep(0, n.sites)

idx.no0 <- -c(62, 153, 154, 155, 217, 279, 372)

 for (i in 1:n.sites){
    #cat(i, "\n")
    T.vec[i] <- current.year - s[i]
    swe.mat <- matrix(NA, 372, T.vec[i])
    data <- u[i]
  for (j in 1:T.vec[i]){
     #cat(j, " ")
     swe.mat[, j] <- read.snotel(f = data, j)
    #cat("\n")	
  }
    snotel.list[[i]] <- swe.mat[idx.no0,  ]
    #cat("\n")
 }
snotel.list
}









