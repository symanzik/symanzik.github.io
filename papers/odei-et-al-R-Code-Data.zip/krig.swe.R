krig.swe <- function(Y, X){
	
library(geoR)

T <- dim(Y)[2]
n <- dim(Y)[3]
m <- dim(Y)[1]

Y.aug <- Y
for(t in 1:T){
  for (i in 1:m){
    #cat(t,i,"\n")
    tmp.idx=!is.na(Y[i, t, ])
    if(!all(tmp.idx)){
      yo.tmp <- Y[i, t, tmp.idx]
      xo.tmp <- X[tmp.idx, ]
      xu.tmp <- X[!tmp.idx, ]
#      if(!all(yo.tmp==0)){
        tmp.dat <- cbind(xo.tmp[, 1], xo.tmp[, 2], yo.tmp)
        tmp.pred.dat <- cbind(xu.tmp[, 1], xu.tmp[, 2])
               
        o.gd <- as.geodata(tmp.dat) 
#        u.gd <- as.geodata(tmp.pred.dat) 
#        tmp.v <- variog(o.gd, max.dist = 2, messages = FALSE)
        tmp.v <- variog(o.gd, messages = FALSE)
      #print(max(tmp.v$v))
      do.idx <- (max(tmp.v$v) >= .5)
      if(do.idx){
#        tmp.f <- variofit(tmp.v, ini=c(max(tmp.v$v), 1), cov.model = "exponential", 
#                 fix.nug = TRUE, wei = "cressie",  max.dist = 2, messages = FALSE)
         tmp.f <- variofit(tmp.v, ini = c(max(tmp.v$v), 1), cov.model = "exponential", 
                  fix.nug = TRUE, wei = "cressie", messages = FALSE)
         tmp.k <- krige.conv(o.gd, loc = xu.tmp, 
                  krige = krige.control(type.krige = "SK", obj.m = tmp.f),
                  output = output.control(messages = FALSE))
         yu.tmp <- tmp.k$predict
#        yu.tmp <- krige(yo.tmp, xo.tmp, xu.tmp)
         Y.aug[i, t, !tmp.idx]  <-  yu.tmp
       }
       if(!do.idx){
        Y.aug[i, t, ]  <-  0 
      }
    }
  }
}

Y.aug[Y.aug < 0]  <-  0

Y.aug	
}
