utah.snotel.current.data <- function(n.sites){

##
## Example:  swe.utah.current <- utah.snotel.current.data(n.sites = 90)
##

u <- rep(NA, n.sites)

u[1] <- "Current_Data/12m26s_s.txt"
u[2] <- "Current_Data/11k13s_s.txt"
u[3] <- "Current_Data/11j46s_s.txt"
u[4] <- "Current_Data/11h08s_s.txt"
u[5] <- "Current_Data/11h30s_s.txt"
u[6] <- "Current_Data/12l07s_s.txt"
u[7] <- "Current_Data/11l04s_s.txt"
u[8] <- "Current_Data/12l04s_s.txt"
u[9] <- "Current_Data/11j57s_s.txt"
u[10] <- "Current_Data/10j30s_s.txt"
u[11] <- "Current_Data/11k31s_s.txt"
u[12] <- "Current_Data/11h37s_s.txt"
u[13] <- "Current_Data/09m02s_s.txt"
u[14] <- "Current_Data/11j70s_s.txt"
u[15] <- "Current_Data/12m13s_s.txt"
u[16] <- "Current_Data/11j01s_s.txt"
u[17] <- "Current_Data/11j02s_s.txt"
u[18] <- "Current_Data/10j43s_s.txt"
u[19] <- "Current_Data/11m06s_s.txt"
u[20] <- "Current_Data/11k21s_s.txt"
u[21] <- "Current_Data/11k22s_s.txt" 
u[22] <- "Current_Data/11j32s_s.txt"
u[23] <- "Current_Data/11j23s_s.txt"
u[24] <- "Current_Data/11k15s_s.txt"
u[25] <- "Current_Data/11l05s_s.txt"
u[26] <- "Current_Data/11h55s_s.txt"
u[27] <- "Current_Data/12j09s_s.txt"
u[28] <- "Current_Data/09k01s_s.txt"
u[29] <- "Current_Data/11j11s_s.txt"
u[30] <- "Current_Data/11j12s_s.txt"
u[31] <- "Current_Data/11l01s_s.txt"
u[32] <- "Current_Data/10j26s_s.txt"
u[33] <- "Current_Data/13m07s_s.txt"
u[34] <- "Current_Data/11l12s_s.txt"
u[35] <- "Current_Data/13m06s_s.txt"
u[36] <- "Current_Data/11j37s_s.txt"
u[37] <- "Current_Data/12m05s_s.txt"
u[38] <- "Current_Data/10j44s_s.txt"
u[39] <- "Current_Data/10j04s_s.txt"
u[40] <- "Current_Data/09j08s_s.txt"
u[41] <- "Current_Data/10j01s_s.txt"
u[42] <- "Current_Data/11h21s_s.txt"
u[43] <- "Current_Data/10k01s_s.txt"
u[44] <- "Current_Data/12l20s_s.txt"
u[45] <- "Current_Data/12l06s_s.txt"
u[46] <- "Current_Data/09j01s_s.txt"
#u[47] <- "Current_Data/11h01s_s.txt"
u[47] <- "Current_Data/13m05s_s.txt"
u[48] <- "Current_Data/10j10s_s.txt"
u[49] <- "Current_Data/10j25s_s.txt"
u[50] <- "Current_Data/09l03s_s.txt"
u[51] <- "Current_Data/11h59s_s.txt"
u[52] <- "Current_Data/10j35s_s.txt"
u[53] <- "Current_Data/11h25s_s.txt"
u[54] <- "Current_Data/13m04s_s.txt"
u[55] <- "Current_Data/13m02s_s.txt"
u[56] <- "Current_Data/12m06s_s.txt"
u[57] <- "Current_Data/11j64s_s.txt"
u[58] <- "Current_Data/11j69s_s.txt"
u[59] <- "Current_Data/11k03s_s.txt"
u[60] <- "Current_Data/12l12s_s.txt"
u[61] <- "Current_Data/12m23s_s.txt"
u[62] <- "Current_Data/11j65s_s.txt"
u[63] <- "Current_Data/12j07s_s.txt"
u[64] <- "Current_Data/11h57s_s.txt"
u[65] <- "Current_Data/09j05s_s.txt"
u[66] <- "Current_Data/11j52s_s.txt"
u[67] <- "Current_Data/11j68s_s.txt"
u[68] <- "Current_Data/11k52s_s.txt"
u[69] <- "Current_Data/11k39s_s.txt"
u[70] <- "Current_Data/12l15s_s.txt"
u[71] <- "Current_Data/11k28s_s.txt"
u[72] <- "Current_Data/10j18s_s.txt"
u[73] <- "Current_Data/12j06s_s.txt"
u[74] <- "Current_Data/11k09s_s.txt"
u[75] <- "Current_Data/11j53s_s.txt"
u[76] <- "Current_Data/11j42s_s.txt"
u[77] <- "Current_Data/10j20s_s.txt"
u[78] <- "Current_Data/11j08s_s.txt"
u[79] <- "Current_Data/11h58s_s.txt"
u[80] <- "Current_Data/10k06s_s.txt"
u[81] <- "Current_Data/11j56s_s.txt"
u[82] <- "Current_Data/11j21s_s.txt"
u[83] <- "Current_Data/11h36s_s.txt"
#u[85] <- "Current_Data/11h03s_s.txt"
u[84] <- "Current_Data/10j52s_s.txt"
u[85] <- "Current_Data/09j16s_s.txt"
u[86] <- "Current_Data/11h60s_s.txt"
u[87] <- "Current_Data/12k01s_s.txt"
u[88] <- "Current_Data/12m03s_s.txt"
u[89] <- "Current_Data/10k02s_s.txt"
u[90] <- "Current_Data/11m03s_s.txt"

#source("read.snotel.R")

snotel.list <- vector("list", length = n.sites)

idx.no0 <- -c(62, 153, 154, 155, 217, 279, 372)

 for (i in 1:n.sites){
    #cat(i, "\n")
    data <- u[i]
    swe.mat <- read.snotel(f = data)
    #cat("\n")	
    snotel.list[[i]] <- swe.mat[idx.no0]
    #cat("\n")
 }
snotel.list
}











