invgammastrt <- function(igmn, igvar){
  q <- 2 + (igmn^2)/igvar
  r <- 1/(igmn * (q - 1))
  list(r = r, q = q)
}
