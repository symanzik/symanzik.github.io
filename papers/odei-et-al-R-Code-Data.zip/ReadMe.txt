
To run this code successfully, one has to start with Codes-Used.R but has to ensure the path in the setwd command in the Codes-Used.R is accordingly adjusted to the directory (or folder) where the Historical_Data, Current_Data, and Output folders and the source codes can all be found on your computer.

A user must also install the following R libraries before running this code: 
MCMCpack, mvtnorm, spdep, msm, lattice, geoR, and maps 

The Historical_Data folder contains already downloaded Historical SWE Data from 1979 to 2012 Water-Years for the 90 active sites in Utah

The Current_Data folder contains already downloaded current SWE Data for the 2013 Water-Year for the 90 active sites in Utah

The Output folder is initially empty but when the R code is run successfully, it will contain all the figures used in pdf format as well as the tables generated in this article 

In this article we ran 5000 simulations but depending on the specifications of a user's computer, one would have to change the number of simulations (n.mcmc) in the code. The larger the number of simulations, the more time is required to run the code successfully (especially the MCMC part). Any value of n.mcmc between 500 and 1000 will produce results and figures comparable to what is in this article.

To ensure the boundaries for the 50% and 95% credible interval are as smooth as possible, the user must not install or uninstall the RANN package in R.