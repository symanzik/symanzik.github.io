plot.swe.post <- function(dat, date = NULL, head = NULL){

#  
# Uses output from swe.svd.mcmc.R
#

####
####  Setup Variables 
####

n.burn <- round(dat$n.mcmc/4)
T <- dim(dat$Y)[1]
m <- dim(dat$Y)[2]
modays <- c(31, 30, 31, 31, 28, 31, 30, 31, 30, 31, 31, 30)
mos <- cumsum(modays)
#y.max <- max(dat$Y, na.rm = TRUE)
y.max <- 75


####
####  Get Prediction 50% and 95% Credible Intervals 
####

CI.95 <- apply(dat$Y.pred[, n.burn:dat$n.mcmc], 1, quantile, c(0.025, 0.975))
CI.95 <- c(CI.95[1, ], rev(CI.95[2, ]))
CI.50 <- apply(dat$Y.pred[, n.burn:dat$n.mcmc], 1, quantile, c(0.25, 0.75))
CI.50 <- c(CI.50[1, ],rev(CI.50[2, ]))


####
####  Plot The Graphics
####

matplot((dat$Y.pred[, sample(n.burn:dat$n.mcmc, 20)]),
        type    = "n",
        col     = 3,
        lty     = 1,
#        ylab    = "SWE",
        ylab    = "",
        ylim    = c(0,y.max),
#        xlab    = "Day (in water-year)", 
#        cex.lab = 1.65, 
#        main    = paste(head),
#        cex.main = 2.4, 
        axes    = FALSE)

axis(1, c(0, 92, 182, 273), 
    c("Oct. 1", "Jan. 1", "Apr. 1", "Jul. 1"), 
    cex.axis = 2.5, font = 2)
        
axis(2, cex.axis = 2.4, las = 0, tck = -0.023, line = -0.03, font = 2)
#mtext(side = 2, c(0, 20, 40, 60), c("0", "20", "40", "60"), line = 1)

box()

abline(v = c(0, mos), col = 8)
text(mos - 15, rep(y.max, 12), labels = c(10:12, 1:9), cex = 2.3)

polygon(c(1:m, m:1), CI.95, col = gray(.5), border = NA, lwd=5)
polygon(c(1:m, m:1), CI.50, col=gray(.25), border = NA, lwd=5)

matplot(t(apply(dat$Y[-T, ], 2, quantile, c(0.001,0.999))), 
        type = "l", 
        lty  = 2, 
        col  = 1, 
        lwd  = 9, 
        add  = TRUE)

#lines(apply(dat$Y[-T, ], 2, mean), col = 4, lwd = 11)
lines(apply(dat$Y[-T, ], 2, mean), col = "salmon", lwd = 11)  # peachpuff3", salmon


matplot(t(apply(dat$Y[-T, ], 2, quantile, c(0.05,0.95))), 
        type = "l", 
        lty  = 3,
#       pch  = 3,  
        col  = 1, 
        lwd  = 9, 
        add  = TRUE)
        
#lines(dat$Y[T, ], lwd = 11, col = 2)
lines(dat$Y[T, ], lwd = 11, col = "orange")

abline(v = 130, col = "darkred", lty = 4, lwd = 10)
text(x = 130, y = 62, labels = "Feb. 7 --", pos = 2, col = "darkred", cex = 2.6, font = 2) 

#legend(x = c(225, 380), y = c(32.5, 72.5),
#      col    = c(1, gray(0.25), gray(0.5), 4, 2, 8, 1), lty = c(2, 1, 1, 1, 1, 1, 3), cex = 2.3, 
#      lwd    = c(7, 10, 10, 8, 8, 4, 8),
#      legend = c("prev. data env.","pred. CI: 50%","pred. CI: 95%","prev. data mean",
#                 "current data","months", "5th & 95th perc."), bg = "white")

#legend(x = c(283, 377), y = c(49, 72),
#      #col    = c(1, gray(0.25), gray(0.5), 4, 2, 8, 1), lty = c(2, 1, 1, 1, 1, 1, 3), cex = 1.2, 
#      col    = c(1, gray(0.25), gray(0.5), "salmon", "orange", 8, 1), lty = c(2, 1, 1, 1, 1, 1, 3), cex = 1.3,
#      lwd    = c(4, 8, 8, 5, 5, 3, 4),
#      legend = c("prev. data env.","pred. CI: 50%","pred. CI: 95%","prev. data mean",
#                 "current data","months", "5th & 95th perc."), bg = "white")
}
