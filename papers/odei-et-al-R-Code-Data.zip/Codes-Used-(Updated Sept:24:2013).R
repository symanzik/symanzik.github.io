##
## Summary of All R-Codes Used In Producing Figures and Tables In The Journal Article
##
## Title: A Bayesian Hierarchical Model For Forecasting Intermountain Snow Dynamics
##
## Authors: James B. Odei, JÜrgen Symanzik, and Mevin B. Hooten
##


## IMPORTANT: Users Must Make Sure To Set Working Directory To Read The Data Files and Source Codes ##
## setwd('/Users/jamesbeg/Desktop/AGU Publication/WRR-Article-R-Codes-&-Functions')


#### 1. Import needed functions and data ###

## 1.1 The Following Functions As Well As Libraries Should Be Installed

source("read.snotel.R")
source("invgammastrt.R")
source("swe.svd.mcmc.R")
source("plot.swe.post.R")
source("plot.swe.post_jan/Fig8.R")
source("plot.swe.post_jan.R")
source("plot.swe.post_feb.R")
source("plot.swe.post_mar.R")
source("plot.swe.post_apr.R")
source("plot.swe.post_jan_LBsite.R")
source("plot.swe.post_feb_LBsite.R")
source("plot.swe.post_mar_LBsite.R")
source("plot.swe.post_apr_LBsite.R")
source("prop.pred.R")
source("krig.swe.R")
source("utah.snotel.historical.data.R")
source("utah.snotel.current.data.R")

require(MCMCpack)
require(mvtnorm)
require(spdep)
require(msm)
require(lattice)
require(geoR)
require(maps)
require(grid)

n.sites <- 90  ## Number of Active Utah SNOTEL Sites
m <- 365  ## Number of days in a Water-Year
T <- 34  ## Number of Historical Water-Years considered (1979 to 2012)


## 1.2 Read The Latitude And Longitude Coordinates Of All The 90 Active UTAH SNOTEL Sites

LatLonCoord <- read.table("xcoord.txt", header = TRUE)    
  

###### 1.3 Read The Already Downloaded Historical And Current Water-Year SWE 
######     txt Files For The 90 Active UTAH SNOTEL Sites

print("Starting Step 1: Reading In Already Downloaded Historical SWE Data (from 1979 to 2012 Water-Years) 
       and the Current SWE Data (2013 Water-Year) for the 90 Active Utah SNOTEL Sites")

## 1.3.1 Historical SWE Data from 1979 to 2012 Water-Years ###

past.yr <- 2012
swe.utah <- utah.snotel.historical.data(n.sites = 90, current.year = past.yr + 1) 

## 1.3.2  Current Year SWE Data (2013 Water-Year) ### 
swe.utah.current <- utah.snotel.current.data(n.sites = 90)			        



####  2. Augmenting The SWE Data (Y)  ####
print("Starting Step 2: Augmenting the Historical Data With Missing Values Of SWE Using Kriging")

Y <- array(NA, c(m, T, n.sites))  ## Original Historical Data With Missing Values Of SWE

Y[, 17:T, 1] <- swe.utah[[1]]
Y[, 3:T, 2] <- swe.utah[[2]]
Y[, 1:T, 3] <- swe.utah[[3]]
Y[, 1:T, 4] <- swe.utah[[4]]
Y[, 3:T, 5] <- swe.utah[[5]]
Y[, 2:T, 6] <- swe.utah[[6]]
Y[, 4:T, 7] <- swe.utah[[7]]
Y[, 2:T, 8] <- swe.utah[[8]]
Y[, 9:T, 9] <- swe.utah[[9]]
Y[, 1:T, 10] <- swe.utah[[10]]
Y[, 2:T, 11] <- swe.utah[[11]]

Y[, 1:T, 12] <- swe.utah[[12]]
Y[76, 34, 12] <- 4.3

Y[, 8:T, 13] <- swe.utah[[13]]
Y[, 25:T, 14] <- swe.utah[[14]]
Y[, 3:T, 15] <- swe.utah[[15]]
Y[, 1:T, 16] <- swe.utah[[16]]
Y[, 1:T, 17] <- swe.utah[[17]]
Y[, 4:T, 18] <- swe.utah[[18]]
Y[, 23:T, 19] <- swe.utah[[19]]
Y[, 2:T, 20] <- swe.utah[[20]]
Y[, 2:T, 21] <- swe.utah[[21]]
Y[, 1:T, 22] <- swe.utah[[22]]
Y[, 1:T, 23] <- swe.utah[[23]]

Y[, 1, 24] <- swe.utah[[24]][, 1]
Y[, 3:T, 24] <- swe.utah[[24]][, -1]

Y[, 8:T, 25] <- swe.utah[[25]]
Y[, 1:T, 26] <- swe.utah[[26]]
Y[, 17:T, 27] <- swe.utah[[27]]
Y[, 8:T, 28] <- swe.utah[[28]]
Y[, 1:T, 29] <- swe.utah[[29]]
Y[, 26:T, 30] <- swe.utah[[30]]
Y[, 3:T, 31] <- swe.utah[[31]]
Y[, 4:T, 32] <- swe.utah[[32]]
Y[, 27:T, 33] <- swe.utah[[33]]

Y[, 2, 34] <- swe.utah[[34]][, 1]
Y[, 4:T, 34] <- swe.utah[[34]][, -1]

Y[, 27:T, 35] <- swe.utah[[35]]
Y[, 16:T, 36] <- swe.utah[[36]]
Y[, 2:T, 37] <- swe.utah[[37]]
Y[, 1:T, 38] <- swe.utah[[38]]
Y[, 8:T, 39] <- swe.utah[[39]]
Y[, 8:T, 40] <- swe.utah[[40]]
Y[, 8:T, 41] <- swe.utah[[41]]
Y[, 1:T, 42] <- swe.utah[[42]]
Y[, 2:T, 43] <- swe.utah[[43]]
Y[, 30:T, 44] <- swe.utah[[44]]
Y[, 3:T, 45] <- swe.utah[[45]]
Y[, 2:T, 46] <- swe.utah[[46]]
Y[, 2:T, 47] <- swe.utah[[47]]
Y[, 2:T, 48] <- swe.utah[[48]]
Y[, 12:T, 49] <- swe.utah[[49]]
Y[, 4:T, 50] <- swe.utah[[50]]
Y[, 27:T, 51] <- swe.utah[[51]]
Y[, 4:T, 52] <- swe.utah[[52]]
Y[, 1:T, 53] <- swe.utah[[53]]
Y[, 8:T, 54] <- swe.utah[[54]]
Y[, 4:T, 55] <- swe.utah[[55]]
Y[, 8:T, 56] <- swe.utah[[56]]
Y[, 10:T, 57] <- swe.utah[[57]]
Y[, 22:T, 58] <- swe.utah[[58]]
Y[, 2:T, 59] <- swe.utah[[59]]
Y[, 3:T, 60] <- swe.utah[[60]]
Y[, 4:T, 61] <- swe.utah[[61]]
Y[, 11:T, 62] <- swe.utah[[62]]
Y[, 11:T, 63] <- swe.utah[[63]]
Y[, 1:T, 64] <- swe.utah[[64]]
Y[, 1:T, 65] <- swe.utah[[65]]
Y[, 1:T, 66] <- swe.utah[[66]]
Y[, 22:T, 67] <- swe.utah[[67]]
Y[, 3:T, 68] <- swe.utah[[68]]
Y[, 1:T, 69] <- swe.utah[[69]]
Y[, 8:T, 70] <- swe.utah[[70]]

Y[, 2, 71] <- swe.utah[[71]][, 1]
Y[, 4:T, 71] <- swe.utah[[71]][, -1]

Y[, 3:T, 72] <- swe.utah[[72]]
Y[, 4:T, 73] <- swe.utah[[73]]
Y[, 4:T, 74] <- swe.utah[[74]]
Y[, 1:T, 75] <- swe.utah[[75]]
Y[, 12:T, 76] <- swe.utah[[76]]

Y[, 1:T, 77] <- swe.utah[[77]]
Y[, 1:T, 78] <- swe.utah[[78]]
Y[, 24:T, 79] <- swe.utah[[79]]
Y[, 30:T, 80] <- swe.utah[[80]]
Y[, 10:T, 81] <- swe.utah[[81]]
Y[, 1:T, 82] <- swe.utah[[82]]

Y[, 1:T, 83] <- swe.utah[[83]]
Y[61, 30, 83] <- 1.5

Y[, 1:T, 84] <- swe.utah[[84]]
Y[, 2:T, 85] <- swe.utah[[85]]
Y[, 29:T, 86] <- swe.utah[[86]]
Y[, 1:T, 87] <- swe.utah[[87]]
Y[, 3:T, 88] <- swe.utah[[88]]

Y[, 1:4, 89] <- swe.utah[[89]][, 1:4]
Y[, 6:T, 89] <- swe.utah[[89]][, -(1:4)]

Y[, 1:T, 90] <- swe.utah[[90]]

Y.aug <- krig.swe(Y, LatLonCoord)  ## Augmenting Historical Data With Missing Values Of SWE Using Kriging



### 3. Map Of UTAH With The Highlighted SNOTEL Sites -- (Figure 1 In Article) ###

print("Starting Step 3: Plotting the Map Of UTAH With the Selected SNOTEL Sites Highlighted")

pdf(file = "Output/UtahSNOTELsites(Fig_1).pdf", width = 8, height = 8, pointsize = 12, bg = "white")

layout(matrix(1:2, 1, 2))

map("state", "utah", interior = FALSE, ylim = c(35.8, 44), lwd = 2.5, mar=c(0, 1, 0, 0))    
map("county", "utah", boundary = FALSE, lty = 2, add = TRUE)

points(LatLonCoord[-c(4, 12, 26, 29, 42, 53, 64, 66, 82, 83), ], 
       pch = 16, 
       cex = 1.3, 
       col = "gray55")       

points(LatLonCoord[c(4, 12, 26, 29, 42, 53, 64, 66, 82), ], 
       pch = 18, 
       cex = 1.6, 
       col = 1)       

points(LatLonCoord[83, ], 
       pch = 17, 
       cex = 1.2, 
       col = 1)

loc <- LatLonCoord[c(83, 4, 42, 53, 12, 26, 64, 29, 82, 66), ]
lonadd <- c(-0.06, -0.07, 0.08, 0.06, 0.08, -0.07, 0.08, 0.08, 0.08, 0.10)
latadd <- c(0, 0, 0, 0.02, 0, 0, 0, 0, 0, 0)

map.scale(relwidth = 0.5, metric = FALSE, font = 2)

rect(xleft   = -112.2, 
     ybottom = 40, 
     xright  = -110.8, 
     ytop    = 42.1, 
     border  = "steelblue4",
     lwd     = 3) 

map("state","utah", interior = FALSE, 
    xlim = c(-112.2, -110.8), 
    ylim = c(40, 42.3), 
    lwd  = 2.5,
    mar=c(0, 0, 0, 0))    

map("county", "utah", boundary = FALSE, lty = 2, add = TRUE)

points(LatLonCoord[-c(4, 12, 26, 29, 42, 53, 64, 66, 82, 83), ], 
       pch = 16, 
       cex = 1.6, 
       col = "gray55")       

points(LatLonCoord[c(4, 12, 26, 29, 42, 53, 64, 66, 82), ], 
       pch = 18, 
       cex = 1.6, 
       col = 1)       

points(LatLonCoord[83, ], 
       pch = 17, 
       cex = 1.2, 
       col = 1)

loc <- LatLonCoord[c(83, 4, 42, 53, 12, 26, 64, 29, 82, 66),]
lonadd <- c(-0.06, -0.07, 0.08, 0.06, 0.08, -0.07, 0.08, 0.08, 0.08, 0.10)
latadd <- c(0, 0, 0, 0.02, 0, 0, 0, 0, 0, 0)
text(loc[, 1] + lonadd, loc[, 2] - latadd, cex = 1.7, lwd = 1, col = 1)

rect(xleft   = -112.2, 
     ybottom = 40, 
     xright  = -110.8, 
     ytop    = 42.1, 
     border  = "steelblue4", 
     lwd     = 3) 
     
xleft <- grconvertX(-112.2, "user", "ndc")
xright <- grconvertX(-110.8, "user", "ndc")   
ytop  <- grconvertY(42.1, "user", "ndc")  
ybottom <- grconvertY(40, "user", "ndc") 

pushViewport(viewport())
grid.lines(x = c(0.1915, xleft), y = c( 0.51, ybottom), gp = gpar(col = "steelblue4", lwd = 3.5, lty = 2)) 
grid.lines(x = c(0.1915, xleft), y = c( 0.765, ytop), gp = gpar(col = "steelblue4", lwd = 3.5, lty = 2))  
popViewport()
 
dev.off()


### 4. Plots Of SWE Measurements For TONY GROVE SNOTEL Site (1979 to 2008) -- (Figure 2 In Article)

print("Starting Step 4: Plotting of SWE Measurements for TONY GROVE SNOTEL Site (1979 to 2008)")
TGdata <- swe.utah[[83]]  ## TONY GROVE SITE					
TGdata[61, 30] <- 1.5
T <- 2008 - 1979 + 1
TGdata <- TGdata[, 1:T]
day.mat <- matrix(rep(1:365, T))
year.mat <- matrix(1979:2008, m, T, byrow = TRUE)
year.mat2 <- matrix(NA, m, T)

for (i in 1:5){
year.mat2[, (6*i - 5):(6*i)] = year.mat[, (25 - (6*(i - 1))):(30 - (6*(i - 1)))]
}

year.series <- as.factor(matrix(year.mat2))
TGdata2 <- data.frame(rev(TGdata), rev(day.mat), rev(year.series))
colnames(TGdata2) <- c("SWE", "Day", "Year")

labels <- c("2003", "2004", "2005", "2006", "2007", "2008", "1997", "1998", "1999", "2000","2001", "2002", 
            "1991", "1992", "1993", "1994", "1995", "1996", "1985", "1986", "1987", "1988", "1989", "1990",
            "1979", "1980", "1981", "1982", "1983", "1984")

my.strip <- function(which.given, which.panel, ...) {
            strip.labels <- labels
            panel.rect(0, 0, 1, 1, col = "bisque1", border = 1)
            panel.text(x    = 0.5, 
                       y    = 0.5, 
                       adj  = c(0.5, 0.55), 
                       cex  = 1.2, 
                       lwd  = 2, 
                       font = 2,
                       lab  = strip.labels[which.panel[which.given]])
}

pdf(file = "Output/Tony-Grove-SWEdata(Fig_2).pdf", width = 15, height = 11, pointsize = 12, bg = "white")
print(xyplot(SWE ~ Day | Year, data = TGdata2, 
	         scales = list(alternating = c(1), tck = c(1.0, 0), cex = 1.4), 
             strip  = my.strip, 
             outer  = TRUE, 
             layout = c(6, 5), 
             ylab   = list("SWE", cex = 1.5), 
             xlab   = list("Day", cex = 1.8),
             main   = " ",
             panel  = function(x, y, ...){ 
                      panel.xyplot(x, y, ..., type = "l", col = "black", pch = 16, lwd = 2) 
}))
dev.off()


## 5. Combining the Augmented Historical SWE and Current SWE Data For Each UTAH SNOTEL Site In A List Form 

print("Starting Step 5: Combining the Augmented Historical SWE and Current SWE Data For Each UTAH SNOTEL Site")

swe.utah.list <- vector("list", length = n.sites)

for (i in 1:n.sites){
	#cat(i, "\n")
	swe.utah.list[[i]] <- cbind(Y.aug[, , i], as.matrix(swe.utah.current[[i]]))
	#cat("\n")
}

#swe.utah.list[[8]][287:365, 31] <- 0


## 6. Obtaining The SWE Measurements For The Ten Selected UTAH SNOTEL Sites In The Article 
print("Starting Step 6: Obtaining the SWE Measurements for the Ten Selected UTAH SNOTEL Sites In the Article")

TGswe <- swe.utah.list[[83]]  ## TONY GROVE					
TGswe[61, 30] <- 1.5
#TGswe[287:365, 31] <- 0

BLPswe <- swe.utah.list[[4]]  ## BEN LOMOND PEAK
#BLPswe[287:365, 31] <- 0

HRswe <- swe.utah.list[[42]]  ## HORSE RIDGE
#HRswe[287:365, 31] <- 0

LBswe <- swe.utah.list[[53]]  ## LITTLE BEAR
#LBswe[287:365, 31] <- 0

BLswe <- swe.utah.list[[12]]  ## BUG LAKE
#BLswe[287:365, 31] <- 0

DBPswe <- swe.utah.list[[26]]  ## DRY BREAD POND
#DBPswe[287:365, 31] <- 0

MCswe <- swe.utah.list[[9]]  ## MONTE CRISTO
#MCswe[287:365, 31] <- 0

FARMswe <- swe.utah.list[[29]]  ## FARMINGTON
#FARMswe[287:365, 31] <- 0

TDswe <- swe.utah.list[[82]]  ## TIMPANOGOS DIVIDE
#TDswe[287:365, 31] <- 0

PSswe <- swe.utah.list[[66]]  ## PARLEY'S SUMMIT
#PSswe[287:365, 31] <- 0



## 6.1 Creating The Data Matrix And Performing The SVD For the Dimension Reduction Decribed In Section 2.2 

print("Starting Step 6.1.1: Creating The Data Matrix And Performing The SVD For the Dimension Reduction Decribed In Section 2.2")

n <- n.sites
T <- 30 ## This Value is Dependent on the Past Water-Years. For Example in 2008 Water-Year, T = 29, 
        ## For 2009 Water-Year, T = 30, For 2010 Water-Year, T = 31, For 2011 Water-Year, T = 32, etc. 
Ymat <- matrix(Y.aug[, 1:T], m, n*T)  ## Creating The Data Matrix Decribed In Section 2.2
Y.c2 <- scale(t(Ymat), scale = FALSE)  ## Scaling The Data Matrix Decribed In Section 2.2
mu2 <- attributes(Y.c2)[[2]]

M <- matrix(mu2, m, n*T)

Y.svd <- svd(Y.c2)  ## Performing The SVD On The Scaled Data Matrix Described In Equation 1
U <- Y.svd$u
D <- diag(Y.svd$d)
V <- Y.svd$v
UD <- U%*%D

print("Starting Step 6.1.2: Writing the Table for Cummulative Proportion Of Variance Explained 
       By the Orthogonal Components of Each Decomposition (Signal) As .csv File")

pvar <- ((Y.svd$d)^2)/sum((Y.svd$d)^2)  ## Proportion Of Variance Explained By The Orthogonal Components 
								        ##  of Each Decomposition (Signal)
cumpvar <- cumsum(pvar)  ## Cummulative Proportion Of Variance Explained By The Orthogonal Components 
                         ## of Each Decomposition (Signal). See Table 1 in Article For The First Four 
Table1_full <- data.frame(cumpvar) 
write.csv(Table1_full, file="Output/Table1.csv")

#q <- 4  ## Number of Important Signals Chosen For Data Dimension Reduction
#U <- Y.svd$u[, 1:q]
#V <- Y.svd$v[, 1:q]
#Z <- t(UD[, 1:q])

## 6.2. Choosing A Reasonable q-Value (from 2, 4, 6) for the Dimension Reduction Described In Section 2.2    

print("Starting Step 6.2: Choosing A Reasonable q-Value for the Dimension Reduction Described In Section 2.2")                                                   

set.seed(12345)

tmp2008.out1 <- swe.svd.mcmc.2(t(TGswe[, -c(31, 32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2008.out2 <- swe.svd.mcmc.2(t(TGswe[, -c(31, 32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2008.out3 <- swe.svd.mcmc.2(t(TGswe[, -c(31, 32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2008.out4 <- swe.svd.mcmc.2(t(BLPswe[, -c(31, 32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2008.out5 <- swe.svd.mcmc.2(t(BLPswe[, -c(31, 32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2008.out6 <- swe.svd.mcmc.2(t(BLPswe[, -c(31, 32, 33, 34, 35)]), 6, 1000, 100, )  

tmp2008.out7 <- swe.svd.mcmc.2(t(HRswe[, -c(31, 32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2008.out8 <- swe.svd.mcmc.2(t(HRswe[, -c(31, 32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2008.out9 <- swe.svd.mcmc.2(t(HRswe[, -c(31, 32, 33, 34, 35)]), 6, 1000, 100, )  

tmp2008.out10 <- swe.svd.mcmc.2(t(LBswe[, -c(31, 32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2008.out11 <- swe.svd.mcmc.2(t(LBswe[, -c(31, 32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2008.out12 <- swe.svd.mcmc.2(t(LBswe[, -c(31, 32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2008.out13 <- swe.svd.mcmc.2(t(BLswe[, -c(31, 32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2008.out14 <- swe.svd.mcmc.2(t(BLswe[, -c(31, 32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2008.out15 <- swe.svd.mcmc.2(t(BLswe[, -c(31, 32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2008.out16 <- swe.svd.mcmc.2(t(DBPswe[, -c(31, 32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2008.out17 <- swe.svd.mcmc.2(t(DBPswe[, -c(31, 32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2008.out18 <- swe.svd.mcmc.2(t(DBPswe[, -c(31, 32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2008.out19 <- swe.svd.mcmc.2(t(MCswe[, -c(31, 32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2008.out20 <- swe.svd.mcmc.2(t(MCswe[, -c(31, 32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2008.out21 <- swe.svd.mcmc.2(t(MCswe[, -c(31, 32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2008.out22 <- swe.svd.mcmc.2(t(FARMswe[, -c(31, 32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2008.out23 <- swe.svd.mcmc.2(t(FARMswe[, -c(31, 32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2008.out24 <- swe.svd.mcmc.2(t(FARMswe[, -c(31, 32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2008.out25 <- swe.svd.mcmc.2(t(TDswe[, -c(31, 32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2008.out26 <- swe.svd.mcmc.2(t(TDswe[, -c(31, 32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2008.out27 <- swe.svd.mcmc.2(t(TDswe[, -c(31, 32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2008.out28 <- swe.svd.mcmc.2(t(PSswe[, -c(31, 32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2008.out29 <- swe.svd.mcmc.2(t(PSswe[, -c(31, 32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2008.out30 <- swe.svd.mcmc.2(t(PSswe[, -c(31, 32, 33, 34, 35)]), 6, 1000, 100, ) 

n <- 30
tmpswe <- list(NA, n)

tmpswe[[1]] <- tmp2008.out1
tmpswe[[2]] <- tmp2008.out2
tmpswe[[3]] <- tmp2008.out3

tmpswe[[4]] <- tmp2008.out4
tmpswe[[5]] <- tmp2008.out5
tmpswe[[6]] <- tmp2008.out6

tmpswe[[7]] <- tmp2008.out7
tmpswe[[8]] <- tmp2008.out8
tmpswe[[9]] <- tmp2008.out9

tmpswe[[10]] <- tmp2008.out10
tmpswe[[11]] <- tmp2008.out11
tmpswe[[12]] <- tmp2008.out12

tmpswe[[13]] <- tmp2008.out13
tmpswe[[14]] <- tmp2008.out14
tmpswe[[15]] <- tmp2008.out15

tmpswe[[16]] <- tmp2008.out16
tmpswe[[17]] <- tmp2008.out17
tmpswe[[18]] <- tmp2008.out18

tmpswe[[19]] <- tmp2008.out19
tmpswe[[20]] <- tmp2008.out20
tmpswe[[21]] <- tmp2008.out21

tmpswe[[22]] <- tmp2008.out22
tmpswe[[23]] <- tmp2008.out23
tmpswe[[24]] <- tmp2008.out24

tmpswe[[25]] <- tmp2008.out25
tmpswe[[26]] <- tmp2008.out26
tmpswe[[27]] <- tmp2008.out27

tmpswe[[28]] <- tmp2008.out28
tmpswe[[29]] <- tmp2008.out29
tmpswe[[30]] <- tmp2008.out30

prop.pred <- function(tmpswe, n = 30, day = 100, ncol = 6){

prop.mat <- matrix(NA, n, ncol)
colnames(prop.mat) <- c("50%CL.LL", "50%CL.UL", "50%CL.LLUL", "95%CL.LL", "95%CL.UL", "95%CL.LLUL")
rownames(prop.mat) <- c("TGsweQ2", "TGsweQ4", "TGsweQ6", "BLPsweQ2", "BLPsweQ4", "BLPsweQ6", 
                        "HRsweQ2", "HRsweQ4", "HRsweQ6", "LBsweQ2", "LBsweQ4", "LBsweQ6", 
                        "BLsweQ2", "BLsweQ4", "BLsweQ6", "DBPsweQ2", "DBPsweQ4", "DBPsweQ6", 
                        "MCsweQ2", "MCsweQ4", "MCsweQ6", "FARMsweQ2", "FARMsweQ4", "FARMsweQ6", 
                        "TDsweQ2", "TDsweQ4", "TDsweQ6", "PSsweQ2", "PSsweQ4", "PSsweQ6")
for(i in 1:n){
n.burn <- round(tmpswe[[i]]$n.mcmc/4)
T <- dim(tmpswe[[i]]$Y)[1]
m <- dim(tmpswe[[i]]$Y)[2]

CI.50 <- apply(tmpswe[[i]]$Y.pred[, n.burn:tmpswe[[i]]$n.mcmc], 1, quantile, c(0.25, 0.75))
CI.95 <- apply(tmpswe[[i]]$Y.pred[, n.burn:tmpswe[[i]]$n.mcmc], 1, quantile, c(0.025, 0.975))

nc <- c(1:ncol)
prop.mat[i, nc[1]] <- 100*sum(tmpswe[[i]]$Y[T, (day+1):m] < CI.50[1, (day+1):m])/(m-day)
prop.mat[i, nc[2]] <- 100*sum(tmpswe[[i]]$Y[T, (day+1):m] > CI.50[2, (day+1):m])/(m-day)
prop.mat[i, nc[3]] <- 100*sum((tmpswe[[i]]$Y[T,(day+1):m] < CI.50[1, (day+1):m]),
                           (tmpswe[[i]]$Y[T, (day+1):m] > CI.50[2, (day+1):m]))/(m-day)
prop.mat[i, nc[4]] <- 100*sum(tmpswe[[i]]$Y[T, (day+1):m] < CI.95[1, (day+1):m])/(m-day)
prop.mat[i, nc[5]] <- 100*sum(tmpswe[[i]]$Y[T, (day+1):m] > CI.95[2, (day+1):m])/(m-day)
prop.mat[i, nc[6]] <- 100*sum((tmpswe[[i]]$Y[T,(day+1):m] < CI.95[1, (day+1):m]), 
                           (tmpswe[[i]]$Y[T, (day+1):m] > CI.95[2, (day+1):m]))/(m-day)

}
cat("\n")
list(prop.mat = prop.mat)
}

env <- prop.pred(tmpswe)

propmat <- cbind(env$prop.mat[, 3], env$prop.mat[, 6])

s <- 10
qprop <- matrix(NA, s, 6)
colnames(qprop) <- c("50%-CI.(q = 2)", "50%-CI.(q = 4)", "50%-CI.(q = 6)", 
                     "95%-CI.(q = 2)", "95%-CI.(q = 4)", "95%-CI.(q = 6)")

for(j in 1:s){
qprop[j, 1] <- propmat[(3*j-2), 1]
qprop[j, 2] <- propmat[(3*j-1), 1]
qprop[j, 3] <- propmat[3*j, 1]
qprop[j, 4] <- propmat[(3*j-2), 2]
qprop[j, 5] <- propmat[(3*j-1), 2]
qprop[j, 6] <- propmat[3*j, 2]
}

set.seed(12345)

tmp2009.out1 <- swe.svd.mcmc.2(t(TGswe[, -c(32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2009.out2 <- swe.svd.mcmc.2(t(TGswe[, -c(32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2009.out3 <- swe.svd.mcmc.2(t(TGswe[, -c(32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2009.out4 <- swe.svd.mcmc.2(t(BLPswe[, -c(32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2009.out5 <- swe.svd.mcmc.2(t(BLPswe[, -c(32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2009.out6 <- swe.svd.mcmc.2(t(BLPswe[, -c(32, 33, 34)]), 6, 1000, 100, )  

tmp2009.out7 <- swe.svd.mcmc.2(t(HRswe[, -c(32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2009.out8 <- swe.svd.mcmc.2(t(HRswe[, -c(32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2009.out9 <- swe.svd.mcmc.2(t(HRswe[, -c(32, 33, 34, 35)]), 6, 1000, 100, )  

tmp2009.out10 <- swe.svd.mcmc.2(t(LBswe[, -c(32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2009.out11 <- swe.svd.mcmc.2(t(LBswe[, -c(32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2009.out12 <- swe.svd.mcmc.2(t(LBswe[, -c(32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2009.out13 <- swe.svd.mcmc.2(t(BLswe[, -c(32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2009.out14 <- swe.svd.mcmc.2(t(BLswe[, -c(32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2009.out15 <- swe.svd.mcmc.2(t(BLswe[, -c(32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2009.out16 <- swe.svd.mcmc.2(t(DBPswe[, -c(32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2009.out17 <- swe.svd.mcmc.2(t(DBPswe[, -c(32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2009.out18 <- swe.svd.mcmc.2(t(DBPswe[, -c(32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2009.out19 <- swe.svd.mcmc.2(t(MCswe[, -c(32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2009.out20 <- swe.svd.mcmc.2(t(MCswe[, -c(32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2009.out21 <- swe.svd.mcmc.2(t(MCswe[, -c(32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2009.out22 <- swe.svd.mcmc.2(t(FARMswe[, -c(32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2009.out23 <- swe.svd.mcmc.2(t(FARMswe[, -c(32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2009.out24 <- swe.svd.mcmc.2(t(FARMswe[, -c(32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2009.out25 <- swe.svd.mcmc.2(t(TDswe[, -c(32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2009.out26 <- swe.svd.mcmc.2(t(TDswe[, -c(32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2009.out27 <- swe.svd.mcmc.2(t(TDswe[, -c(32, 33, 34, 35)]), 6, 1000, 100, ) 

tmp2009.out28 <- swe.svd.mcmc.2(t(PSswe[, -c(32, 33, 34, 35)]), 2, 1000, 100, )  
tmp2009.out29 <- swe.svd.mcmc.2(t(PSswe[, -c(32, 33, 34, 35)]), 4, 1000, 100, )  
tmp2009.out30 <- swe.svd.mcmc.2(t(PSswe[, -c(32, 33, 34, 35)]), 6, 1000, 100, ) 

n <- 30
tmpswe2 <- list(NA, n)

tmpswe2[[1]] <- tmp2009.out1
tmpswe2[[2]] <- tmp2009.out2
tmpswe2[[3]] <- tmp2009.out3

tmpswe2[[4]] <- tmp2009.out4
tmpswe2[[5]] <- tmp2009.out5
tmpswe2[[6]] <- tmp2009.out6

tmpswe2[[7]] <- tmp2009.out7
tmpswe2[[8]] <- tmp2009.out8
tmpswe2[[9]] <- tmp2009.out9

tmpswe2[[10]] <- tmp2009.out10
tmpswe2[[11]] <- tmp2009.out11
tmpswe2[[12]] <- tmp2009.out12

tmpswe2[[13]] <- tmp2009.out13
tmpswe2[[14]] <- tmp2009.out14
tmpswe2[[15]] <- tmp2009.out15

tmpswe2[[16]] <- tmp2009.out16
tmpswe2[[17]] <- tmp2009.out17
tmpswe2[[18]] <- tmp2009.out18

tmpswe2[[19]] <- tmp2009.out19
tmpswe2[[20]] <- tmp2009.out20
tmpswe2[[21]] <- tmp2009.out21

tmpswe2[[22]] <- tmp2009.out22
tmpswe2[[23]] <- tmp2009.out23
tmpswe2[[24]] <- tmp2009.out24

tmpswe2[[25]] <- tmp2009.out25
tmpswe2[[26]] <- tmp2009.out26
tmpswe2[[27]] <- tmp2009.out27

tmpswe2[[28]] <- tmp2009.out28
tmpswe2[[29]] <- tmp2009.out29
tmpswe2[[30]] <- tmp2009.out30

prop.pred <- function(tmpswe, n = 30, day = 100, ncol = 6){
prop.mat <- matrix(NA, n, ncol)
colnames(prop.mat) <- c("50%CL.LL", "50%CL.UL", "50%CL.LLUL", "95%CL.LL", "95%CL.UL", "95%CL.LLUL")
rownames(prop.mat) <- c("TGsweQ2", "TGsweQ4", "TGsweQ6", "BLPsweQ2", "BLPsweQ4", "BLPsweQ6", 
                        "HRsweQ2", "HRsweQ4", "HRsweQ6", "LBsweQ2", "LBsweQ4", "LBsweQ6", 
                        "BLsweQ2", "BLsweQ4", "BLsweQ6", "DBPsweQ2", "DBPsweQ4", "DBPsweQ6", 
                        "MCsweQ2", "MCsweQ4", "MCsweQ6", "FARMsweQ2", "FARMsweQ4", "FARMsweQ6",
					    "TDsweQ2", "TDsweQ4", "TDsweQ6", "PSsweQ2", "PSsweQ4", "PSsweQ6")
for(i in 1:n){
n.burn <- round(tmpswe[[i]]$n.mcmc/4)
T <- dim(tmpswe[[i]]$Y)[1]
m <- dim(tmpswe[[i]]$Y)[2]

CI.50 <- apply(tmpswe[[i]]$Y.pred[, n.burn:tmpswe[[i]]$n.mcmc], 1, quantile, c(0.25, 0.75))
CI.95 <- apply(tmpswe[[i]]$Y.pred[, n.burn:tmpswe[[i]]$n.mcmc], 1, quantile, c(0.025, 0.975))

nc <- c(1:ncol)
prop.mat[i, nc[1]] <- 100*sum(tmpswe[[i]]$Y[T, (day+1):m] < CI.50[1, (day+1):m])/(m-day)
prop.mat[i, nc[2]] <- 100*sum(tmpswe[[i]]$Y[T, (day+1):m] > CI.50[2, (day+1):m])/(m-day)
prop.mat[i, nc[3]] <- 100*sum((tmpswe[[i]]$Y[T,(day+1):m] < CI.50[1, (day+1):m]), 
                              (tmpswe[[i]]$Y[T, (day+1):m] > CI.50[2, (day+1):m]))/(m-day)
prop.mat[i, nc[4]] <- 100*sum(tmpswe[[i]]$Y[T, (day+1):m] < CI.95[1, (day+1):m])/(m-day)
prop.mat[i, nc[5]] <- 100*sum(tmpswe[[i]]$Y[T, (day+1):m] > CI.95[2, (day+1):m])/(m-day)
prop.mat[i, nc[6]] <- 100*sum((tmpswe[[i]]$Y[T,(day+1):m] < CI.95[1, (day+1):m]), 
                              (tmpswe[[i]]$Y[T, (day+1):m] > CI.95[2, (day+1):m]))/(m-day)

}
cat("\n")
list(prop.mat = prop.mat)
}

env <- prop.pred(tmpswe2)

propmat2 <- cbind(env$prop.mat[,3], env$prop.mat[,6])

s <- 10
qprop2 <- matrix(NA, s, 6)
colnames(qprop2) <- c("50%-CI.(q = 2)", "50%-CI.(q = 4)", "50%-CI.(q = 6)", 
                      "95%-CI.(q = 2)", "95%-CI.(q = 4)", "95%-CI.(q = 6)")

for(j in 1:s){
qprop2[j, 1] <- propmat2[(3*j-2), 1]
qprop2[j, 2] <- propmat2[(3*j-1), 1]
qprop2[j, 3] <- propmat2[3*j, 1]
qprop2[j, 4] <- propmat2[(3*j-2), 2]
qprop2[j, 5] <- propmat2[(3*j-1), 2]
qprop2[j, 6] <- propmat2[3*j, 2]
}

## 6.3. Plot of the Proportion of SWE That Fell Outside the 50% and 95% Credible Interval 
##    for q = 2, 4, and 6 -- (Figure 3 In Article)

print("Starting Step 6.3: Plotting the Proportion of SWE That Fell Outside the 50% 
       and 95% Credible Interval for q = 2, 4, and 6")

pdf(file = "Output/Proportion-of-SWE-Boxplots-for-2008-&-2009-Water-Years(Fig_3).pdf", 
    width = 18, height = 10, pointsize = 12, bg = "white")
layout (matrix(1:2, 2, 1))
par(mar = c(0, 4, 2, 2))
boxplot(qprop, col = "lightgrey", main = " ", axes = FALSE, lwd = 2.3, cex.axis = 2)
axis(2, cex.axis = 2)
axis(1, labels = FALSE)
box()
text(x = 0.4, y = 52.5, labels = "(a)", cex = 1.8, font = 2)
rect(xleft = 0, ybottom = 48.2, xright = 0.54, ytop = 57)
par(mar = c(3, 4, 1, 2))
boxplot(qprop2, col = "lightgrey", main = " ", lwd = 2.3, cex.axis = 2)
text(x = 0.4, y = 51, labels = "(b)", cex = 1.8, font = 2)
rect(xleft = 0, ybottom = 46.1, xright = 0.54, ytop = 56)
dev.off()



## 7. Plot Of The Orthogonal Vectors Containing The First Four Dominant Signals -- (Figure 4 In Article)

print("Starting Step 7: Plotting The Orthogonal Vectors Containing The First Four Dominant Signals")

pdf(file = "Output/Utah_Annual_Signals(Fig_4).pdf", width = 17, height = 12, pointsize = 12, bg = "white")
snowday <- c(1, 100, 200, 300, 365)
waterday <- c("Oct. 1(Day 1)", "Jan. 8 (Day 100)", "Apr. 18 (Day 200)",
              "Jul. 27 (Day 300)", "Sep. 30 (Day 365)")
linetype <- c(1:4)
legendText <- c("Signal 1", "Signal 2", "Signal 3", "Signal 4")
lineColor <- c("gray0", "gray10", "gray25", "gray40")
plotchar <- c(17, 8, 15, 9)

xypoints1 <- cbind(c(3, 43, 83, 123, 163, 198, 243, 263), 
                   Y.svd$v[, 1:q][c(3, 43, 83, 123, 163, 198, 243, 263), 
                   c(1, 3)])
                   
xypoints2 <- cbind(c(10, 50, 80, 130, 177, 230, 243, 280), 
                   Y.svd$v[, 1:q][c(10, 50, 80, 130, 177, 230, 243, 280), 
                   c(2, 4)])
                   
matplot(Y.svd$v[, 1:q], 
        type = "l", 
        lty  = linetype, 
        axes = FALSE, col = lineColor, 
        lwd  = 5, 
        ylab = NA,
        #ylab = expression(italic(upsilon)[ts]), 
        xlab = "Day (in water-year)",
        cex.lab = 2.1) 
axis(1, snowday, waterday, cex.axis = 1.7) 
axis(2, cex.axis = 1.5)
#axis(2, cex.axis = 1.4, las = 2)
mtext(side = 2, expression(italic(upsilon[tg])), line = 1.85, cex = 3)
box(lwd = 2)

for (i in 1:2){
points(xypoints1[, 1], xypoints1[, i + 1], pch = plotchar[(2*i) - 1], cex = 2, lwd = 1.5)
}

for (i in 1:2){
points(xypoints2[, 1], xypoints2[, i + 1], pch = plotchar[2*i], cex = 2, lwd = 1.5)
}

legend("topright", legendText, lty = linetype, lwd = 2.2, cex = 2.0, pch = plotchar)

dev.off()



## 8. Plot Of Left Singular Vectors Containing The Inter-Annual Time Series 
##    For TONY GROVE SNOTEL Site -- (Figure 5 In Article)

print("Starting Step 8: Plotting The Left Singular Vectors Containing The Inter-Annual Time Series for TONY GROVE SNOTEL Site")

k <- 83  ## UTAH SNOTEL Site Number Selected
T <- 30  ## Number Of Years For Historical SWE Data
q <- 4  ## Number Of Important Signals Selected

u.dat <- matrix(round(U[(T*(k - 1) + 1):(T*k), 1:q], 3))
year.num <- matrix(rep(1979:2008, q))
series.num <- matrix(c(rep(1, T), rep(2, T), rep(3, T), rep(4, T)))

series.f <- factor(series.num, levels = c(1:q),
                   labels = c("Latent Time Series 1", "Latent Time Series 2", 
                              "Latent Time Series 3", "Latent Time Series 4"))

series.data <- data.frame(rev(u.dat), rev(year.num), rev(series.num))

my.strip2 <- function(which.given, which.panel, ...) {
             strip.labels <- c("Latent Time Series 4", "Latent Time Series 3", 
                               "Latent Time Series 2", "Latent Time Series 1")
             panel.rect(0, 0, 1, 1, col = "grey85", border = 1)
             panel.text(x    = 0.5, 
                        y    = 0.5, 
                        adj  = c(0.5, 0.55), 
                        cex  = 1.1,
                        lwd  = 2, 
                        font = 2,
                        lab  = strip.labels[which.panel[which.given]])
}

##  Define X and Y Axis Range:
xlim <- c(1978, 2009)
ylim <- c(-0.08, 0.09)

## Define Annual Quarters for Plot Grid Line Markers:

d <- seq(from = 1978, to = 2009, by = 1)

##Create multipanel plot:

pdf(file = "Output/Latent_Time_Series-XYplot(Fig_5).pdf", width = 8.5, height = 11, pointsize = 12, bg = "white")
print(xyplot(u.dat~year.num|rev(series.f), data = series.data,
       scales = list(y = "free", rot = 0, cex = 1.5), 
       xlim   = xlim, 
       ylim   = ylim,
       strip  = my.strip2, 
       outer  = TRUE, 
       layout = c(1, 4, 1), 
       ylab   = list(expression(italic(phi[gt])), cex = 2.0), 
       xlab   = list("Year", cex = 1.6),
       main   = " ",
       panel  = function(x, y, ...) {panel.grid(h = -1, v = 0)  # plot default horizontal gridlines
	             panel.abline(h = 0, lty = 2, col = "brown", lwd = 1.5)  # custom vertical gridlines
                 panel.abline(v = d, col = "grey90", lwd = 1.5)  # custom vertical gridlines
                 panel.xyplot(x, y, ..., type = "b", col = 1, pch = 16, lwd = 1)  # raw data
               },))
dev.off()


## 9. Obtaining The SWE Measurements For The Ten Selected UTAH SNOTEL Sites In The Article 
print("Starting Step 9: Obtaining the SWE Measurements for the Ten Selected UTAH SNOTEL Sites In the Article")

TGswe <- swe.utah.list[[83]]  ## TONY GROVE					
TGswe[61, 30] <- 1.5
#TGswe[287:365, 31] <- 0

BLPswe <- swe.utah.list[[4]]  ## BEN LOMOND PEAK
#BLPswe[287:365, 31] <- 0

HRswe <- swe.utah.list[[42]]  ## HORSE RIDGE
#HRswe[287:365, 31] <- 0

LBswe <- swe.utah.list[[53]]  ## LITTLE BEAR
#LBswe[287:365, 31] <- 0

BLswe <- swe.utah.list[[12]]  ## BUG LAKE
#BLswe[287:365, 31] <- 0

DBPswe <- swe.utah.list[[26]]  ## DRY BREAD POND
#DBPswe[287:365, 31] <- 0

MCswe <- swe.utah.list[[9]]  ## MONTE CRISTO
#MCswe[287:365, 31] <- 0

FARMswe <- swe.utah.list[[29]]  ## FARMINGTON
#FARMswe[287:365, 31] <- 0

TDswe <- swe.utah.list[[82]]  ## TIMPANOGOS DIVIDE
#TDswe[287:365, 31] <- 0

PSswe <- swe.utah.list[[66]]  ## PARLEY'S SUMMIT
#PSswe[287:365, 31] <- 0



## 10. Applying The "swe.svd.mcmc.R" Function To The 2008 Water-Year For The Ten Selected UTAH SNOTEL Sites

print("Starting Step 10: Applying the swe.svd.mcmc.R Function to the 2008 Water-Year for the Ten Selected 
       UTAH SNOTEL Sites Based on q = 4 (Important Signals)")


## 10.1 2008 Water-Year MCMC Forecasting After day 100

set.seed(12345)
#source("swe.svd.mcmc.R")

q <- 4  ## Number Of Important Signals Selected
n.mcmc <- 5000  ## Number of MCMC Simulations To Be Done
outdat <- 100   ## The Day After Which Forecasting Is Done based on The Posterior Distribution
mm <-100

tmp2008.out1 <- swe.svd.mcmc(t(TGswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2008.out2 <- swe.svd.mcmc(t(BLPswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008.out3 <- swe.svd.mcmc(t(HRswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008.out4 <- swe.svd.mcmc(t(LBswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008.out5 <- swe.svd.mcmc(t(BLswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2008.out6 <- swe.svd.mcmc(t(DBPswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008.out7 <- swe.svd.mcmc(t(MCswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008.out8 <- swe.svd.mcmc(t(FARMswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008.out9 <- swe.svd.mcmc(t(TDswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008.out10 <- swe.svd.mcmc(t(PSswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)


## 10.2 2008 Water-Year MCMC Forecasting After day 130

set.seed(12345)

q <- 4  
n.mcmc <- 5000  
outdat <- 130
mm <-130

tmp2008a.out1 <- swe.svd.mcmc(t(TGswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2008a.out2 <- swe.svd.mcmc(t(BLPswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008a.out3 <- swe.svd.mcmc(t(HRswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008a.out4 <- swe.svd.mcmc(t(LBswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008a.out5 <- swe.svd.mcmc(t(BLswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2008a.out6 <- swe.svd.mcmc(t(DBPswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008a.out7 <- swe.svd.mcmc(t(MCswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008a.out8 <- swe.svd.mcmc(t(FARMswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008a.out9 <- swe.svd.mcmc(t(TDswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008a.out10 <- swe.svd.mcmc(t(PSswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)


## 10.3 2008 Water-Year MCMC Forecasting After day 160

set.seed(12345)

q <- 4  
n.mcmc <- 5000  
outdat <- 160
mm <-160

tmp2008b.out1 <- swe.svd.mcmc(t(TGswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2008b.out2 <- swe.svd.mcmc(t(BLPswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008b.out3 <- swe.svd.mcmc(t(HRswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008b.out4 <- swe.svd.mcmc(t(LBswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008b.out5 <- swe.svd.mcmc(t(BLswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2008b.out6 <- swe.svd.mcmc(t(DBPswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008b.out7 <- swe.svd.mcmc(t(MCswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008b.out8 <- swe.svd.mcmc(t(FARMswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008b.out9 <- swe.svd.mcmc(t(TDswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008b.out10 <- swe.svd.mcmc(t(PSswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)


## 10.4 2008 Water-Year MCMC Forecasting After day 190

set.seed(12345)

q <- 4  
n.mcmc <- 5000  
outdat <- 190
mm <-190

tmp2008c.out1 <- swe.svd.mcmc(t(TGswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2008c.out2 <- swe.svd.mcmc(t(BLPswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008c.out3 <- swe.svd.mcmc(t(HRswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008c.out4 <- swe.svd.mcmc(t(LBswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008c.out5 <- swe.svd.mcmc(t(BLswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2008c.out6 <- swe.svd.mcmc(t(DBPswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008c.out7 <- swe.svd.mcmc(t(MCswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008c.out8 <- swe.svd.mcmc(t(FARMswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008c.out9 <- swe.svd.mcmc(t(TDswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2008c.out10 <- swe.svd.mcmc(t(PSswe[, -c(31, 32, 33, 34, 35)]), q, n.mcmc, mm, outdat)


## 11. Creating The Tables For The Proportion Of Observed SWE After days 100 (January 8), 130 (February 7), 
##     160 (March 9), and 190 (April 8) In The 2008 Water-Year That Lies Outside The 50% and 95% Credible 
##     Intervals Obtained For The Posterior Predictive Distribution

print("Starting Step 11: Writing the Table for The Proportion Of Observed SWE After days 100 (January 8), 
       130 (February 7), 160 (March 9), and 190 (April 8) in the 2008 Water-Year That Lies Outside the 50% 
       and 95% Credible Intervals As .csv File")
flush.console()

n <- 10  ## Number Of Selected Sites

## 11.1 Table for Day 100

tmpswe2008 <- list(NA, n)
tmpswe2008[[1]] <- tmp2008.out1
tmpswe2008[[2]] <- tmp2008.out2
tmpswe2008[[3]] <- tmp2008.out3
tmpswe2008[[4]] <- tmp2008.out4
tmpswe2008[[5]] <- tmp2008.out5
tmpswe2008[[6]] <- tmp2008.out6
tmpswe2008[[7]] <- tmp2008.out7
tmpswe2008[[8]] <- tmp2008.out8
tmpswe2008[[9]] <- tmp2008.out9
tmpswe2008[[10]] <- tmp2008.out10

Table2008 <- prop.pred(tmpswe2008)
Table2008 <- data.frame(Table2008)
write.csv(Table2008, file = "Output/Table2008.csv")

## 11.2 Table for Day 130

tmpswe2008a <- list(NA, n)
tmpswe2008a[[1]] <- tmp2008a.out1
tmpswe2008a[[2]] <- tmp2008a.out2
tmpswe2008a[[3]] <- tmp2008a.out3
tmpswe2008a[[4]] <- tmp2008a.out4
tmpswe2008a[[5]] <- tmp2008a.out5
tmpswe2008a[[6]] <- tmp2008a.out6
tmpswe2008a[[7]] <- tmp2008a.out7
tmpswe2008a[[8]] <- tmp2008a.out8
tmpswe2008a[[9]] <- tmp2008a.out9
tmpswe2008a[[10]] <- tmp2008a.out10

Table2008a <- prop.pred(tmpswe2008a)
Table2008a <- data.frame(Table2008a)
write.csv(Table2008a, file = "Output/Table2008a.csv")

## 11.3 Table for Day 160

tmpswe2008b <- list(NA, n)
tmpswe2008b[[1]] <- tmp2008b.out1
tmpswe2008b[[2]] <- tmp2008b.out2
tmpswe2008b[[3]] <- tmp2008b.out3
tmpswe2008b[[4]] <- tmp2008b.out4
tmpswe2008b[[5]] <- tmp2008b.out5
tmpswe2008b[[6]] <- tmp2008b.out6
tmpswe2008b[[7]] <- tmp2008b.out7
tmpswe2008b[[8]] <- tmp2008b.out8
tmpswe2008b[[9]] <- tmp2008b.out9
tmpswe2008b[[10]] <- tmp2008b.out10

Table2008b <- prop.pred(tmpswe2008b)
Table2008b <- data.frame(Table2008b)
write.csv(Table2008b, file = "Output/Table2008b.csv")

## 11.4 Table for Day 190

tmpswe2008c <- list(NA, n)
tmpswe2008c[[1]] <- tmp2008c.out1
tmpswe2008c[[2]] <- tmp2008c.out2
tmpswe2008c[[3]] <- tmp2008c.out3
tmpswe2008c[[4]] <- tmp2008c.out4
tmpswe2008c[[5]] <- tmp2008c.out5
tmpswe2008c[[6]] <- tmp2008c.out6
tmpswe2008c[[7]] <- tmp2008c.out7
tmpswe2008c[[8]] <- tmp2008c.out8
tmpswe2008c[[9]] <- tmp2008c.out9
tmpswe2008c[[10]] <- tmp2008c.out10

Table2008c <- prop.pred(tmpswe2008c)
Table2008c <- data.frame(Table2008c)
write.csv(Table2008c, file = "Output/Table2008c.csv")


## 12. Plots of The Ten SNOTEL Site SWE Measurements and Posterior Prediction As Of January 8 (Day 100),
##     Febraury 7 (Day 130), March 9 (Day 160), and April 8 (Day 190) In The 2008 Water-Year

print("Starting Step 12: Plotting the SWE Measurements and Posterior Prediction of the Ten Sites Selected for the 2008 Water-Year")
flush.console()

## 12.1 Plots for Forecasting After Day 100

source("plot.swe.post_jan.R")
pdf(file = "Output/Output1/SWE2008TGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out1)
dev.off()

pdf(file = "Output/Output2/SWE2008BLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out2)
dev.off()

pdf(file = "Output/Output3/SWE2008HRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out3)
dev.off()

source("plot.swe.post_jan_LBsite.R")
pdf(file = "Output/Output4/SWE2008LBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out4)
dev.off()

source("plot.swe.post_jan.R")
pdf(file = "Output/Output5/SWE2008BLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out5)
dev.off()

pdf(file = "Output/Output6/SWE2008DBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out6)
dev.off()

pdf(file = "Output/Output7/SWE2008MCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out7)
dev.off()

pdf(file = "Output/Output8/SWE2008FARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out8)
dev.off()

pdf(file = "Output/Output9/SWE2008TDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out9)
dev.off()

pdf(file = "Output/Output10/SWE2008PSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out10)
dev.off()


## 12.2 Plots for Forecasting After Day 130

source("plot.swe.post_feb.R")
pdf(file = "Output/Output1/SWE2008aTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008a.out1)
dev.off()

pdf(file = "Output/Output2/SWE2008aBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008a.out2)
dev.off()

pdf(file = "Output/Output3/SWE2008aHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008a.out3)
dev.off()

source("plot.swe.post_feb_LBsite.R")
pdf(file = "Output/Output4/SWE2008aLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008a.out4)
dev.off()

source("plot.swe.post_feb.R")
pdf(file = "Output/Output5/SWE2008aBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008a.out5)
dev.off()

pdf(file = "Output/Output6/SWE2008aDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008a.out6)
dev.off()

pdf(file = "Output/Output7/SWE2008aMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008a.out7)
dev.off()

pdf(file = "Output/Output8/SWE2008aFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008a.out8)
dev.off()

pdf(file = "Output/Output9/SWE2008aTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008a.out9)
dev.off()

pdf(file = "Output/Output10/SWE2008aPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008a.out10)
dev.off()


## 12.3 Plots for Forecasting After Day 160

source("plot.swe.post_mar.R")
pdf(file = "Output/Output1/SWE2008bTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008b.out1)
dev.off()

pdf(file = "Output/Output2/SWE2008bBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008b.out2)
dev.off()

pdf(file = "Output/Output3/SWE2008bHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008b.out3)
dev.off()

source("plot.swe.post_mar_LBsite.R")
pdf(file = "Output/Output4/SWE2008bLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008b.out4)
dev.off()

source("plot.swe.post_mar.R")
pdf(file = "Output/Output5/SWE2008bBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008b.out5)
dev.off()

pdf(file = "Output/Output6/SWE2008bDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008b.out6)
dev.off()

pdf(file = "Output/Output7/SWE2008bMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008b.out7)
dev.off()

pdf(file = "Output/Output8/SWE2008bFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008b.out8)
dev.off()

pdf(file = "Output/Output9/SWE2008bTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008b.out9)
dev.off()

pdf(file = "Output/Output10/SWE2008bPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008b.out10)
dev.off()


## 12.4 Plots for Forecasting After Day 190

source("plot.swe.post_apr.R")
pdf(file = "Output/Output1/SWE2008cTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008c.out1)
dev.off()

pdf(file = "Output/Output2/SWE2008cBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008c.out2)
dev.off()

pdf(file = "Output/Output3/SWE2008cHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008c.out3)
dev.off()

source("plot.swe.post_apr_LBsite.R")
pdf(file = "Output/Output4/SWE2008cLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008c.out4)
dev.off()

source("plot.swe.post_apr.R")
pdf(file = "Output/Output5/SWE2008cBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008c.out5)
dev.off()

pdf(file = "Output/Output6/SWE2008cDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008c.out6)
dev.off()

pdf(file = "Output/Output7/SWE2008cMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008c.out7)
dev.off()

pdf(file = "Output/Output8/SWE2008cFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008c.out8)
dev.off()

pdf(file = "Output/Output9/SWE2008cTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008c.out9)
dev.off()

pdf(file = "Output/Output10/SWE2008cPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008c.out10)
dev.off()


## 12.5 XYPlot for the Estimates of the Model Parameter Alpha_t (∝_st) (Figure 6 In Article) 
print("Starting Step 12.5: XYPlot for the Estimates of the Model Parameter Alpha_st (∝_st)")

 
alphatmean1 <- c(tmp2008.out1$alpha.mean[1,], tmp2008.out2$alpha.mean[1,],   
                tmp2008.out3$alpha.mean[1,], tmp2008.out4$alpha.mean[1,], 
                tmp2008.out5$alpha.mean[1,], tmp2008.out6$alpha.mean[1,],
                tmp2008.out7$alpha.mean[1,], tmp2008.out8$alpha.mean[1,], 
                tmp2008.out9$alpha.mean[1,], tmp2008.out10$alpha.mean[1,])

alphatmean2 <- c(tmp2008.out1$alpha.mean[2,], tmp2008.out2$alpha.mean[1,],   
                tmp2008.out3$alpha.mean[2,], tmp2008.out4$alpha.mean[1,], 
                tmp2008.out5$alpha.mean[2,], tmp2008.out6$alpha.mean[1,],
                tmp2008.out7$alpha.mean[2,], tmp2008.out8$alpha.mean[1,], 
                tmp2008.out9$alpha.mean[2,], tmp2008.out10$alpha.mean[1,])
                
alphatmean3 <- c(tmp2008.out1$alpha.mean[3,], tmp2008.out2$alpha.mean[1,],   
                tmp2008.out3$alpha.mean[3,], tmp2008.out4$alpha.mean[1,], 
                tmp2008.out5$alpha.mean[3,], tmp2008.out6$alpha.mean[1,],
                tmp2008.out7$alpha.mean[3,], tmp2008.out8$alpha.mean[1,], 
                tmp2008.out9$alpha.mean[3,], tmp2008.out10$alpha.mean[1,])
 
 alphatmean4 <- c(tmp2008.out1$alpha.mean[4,], tmp2008.out2$alpha.mean[1,],   
                tmp2008.out3$alpha.mean[4,], tmp2008.out4$alpha.mean[1,], 
                tmp2008.out5$alpha.mean[4,], tmp2008.out6$alpha.mean[1,],
                tmp2008.out7$alpha.mean[4,], tmp2008.out8$alpha.mean[1,], 
                tmp2008.out9$alpha.mean[4,], tmp2008.out10$alpha.mean[1,])
                
alphatmean <- round(cbind(alphatmean1, alphatmean2, alphatmean3, alphatmean4), 3)

q <- 4  ## Number Of Important Signals Selected
T <- 30
n <- 10

year.num <- matrix(rep(1:(n*T), q))
series.num <- matrix(c(rep(1, n*T), rep(2, n*T), rep(3, n*T), rep(4, n*T)))

series.f <- factor(series.num, levels = c(1:q),
                   labels = c("Signal 1", "Signal 2", "Signal 3", "Signal 4"))

series.data <- data.frame(rev(alphatmean), rev(year.num), rev(series.num))

my.strip2 <- function(which.given, which.panel, ...) {
             strip.labels <- c("Signal 4", "Signal 3", "Signal 2", "Signal 1")
             panel.rect(0, 0, 1, 1, col = "grey85", border = 1)
             panel.text(x    = 0.5, 
                        y    = 0.5, 
                        adj  = c(0.5, 0.55), 
                        cex  = 1.1,
                        lwd  = 2, 
                        font = 2,
                        lab  = strip.labels[which.panel[which.given]])
}

##  Define X and Y Axis Range:
xlim <- c(1, n*T)
ylim <- c(-16, 15.5)

## Define Annual Quarters for Plot Grid Line Markers:

d <- seq(from = 1, to = n*T, by = 1)

## Create Multipanel Plot:

pdf(file = "Output/alpha_t-XYplot(Fig_6).pdf", width = 8, height = 11, pointsize = 12, bg = "white")

print(xyplot(alphatmean~year.num|rev(series.f), data = series.data,
       scales = list(y = "free", rot = 0, cex = 1.5), 
       xlim   = xlim, 
       ylim   = ylim,
       strip  = my.strip2, 
       outer  = TRUE, 
       layout = c(1, 4, 1), 
       ylab   = list(expression(italic(alpha[st])), cex = 2.0), 
       xlab   = list(" ", cex = 1.6),
       main   = " ",
       panel  = function(x, y, ...) {panel.grid(h = -1, v = 0)  # plot default horizontal gridlines
	             panel.abline(h = 0, lty = 2, col = "brown", lwd = 3)  # custom vertical gridlines
               # panel.abline(v = d, col = "grey90", lwd = 1.5)  # custom vertical gridlines
                 panel.xyplot(x, y, ..., type = "l", col = 1, pch = 16, lwd = 1.5)  # raw data
               },))
dev.off()


## 12.6 Boxplots for the Estimates of the Model Parameter Alpha (∝) (Figure 7 In Article)
print("Starting Step 12.6: Boxplots for the Estimates of the Model Parameter Alpha (∝)")

pdf(file = "Output/alpha-Boxplots(Fig_7).pdf", width = 8, height = 4, pointsize = 4, bg = "white")
nmcmc <- 2000
layout (matrix(1:2, 1, 2))
boxplot(list(tmp2008.out1$alpha.save[1,1:nmcmc], tmp2008.out1$alpha.save[2,1:nmcmc], 
             tmp2008.out1$alpha.save[3,1:nmcmc], tmp2008.out1$alpha.save[4,1:nmcmc]), 
             names = (expression(alpha[1],alpha[2], alpha[3], alpha[4])), 
             main= " ", col="lightgrey", lwd=2, cex.axis = 3, font = 2)
abline(h=0, lty=4, lwd=3, col=1)
text(x = 0.57, y = 2.3, labels = "(a)", cex = 2.5, font = 2)
rect(xleft = 0, ybottom = 2.05, xright = 0.8, ytop = 2.7)

boxplot(list(tmp2008.out4$alpha.save[1,1:nmcmc], tmp2008.out4$alpha.save[2,1:nmcmc], 
             tmp2008.out4$alpha.save[3,1:nmcmc], tmp2008.out4$alpha.save[4,1:nmcmc]), 
             names = (expression(alpha[1],alpha[2], alpha[3], alpha[4])), 
             main = " ", col = "lightgrey", lwd = 2,  cex.axis = 3, font = 2)
abline(h = 0, lty = 4, lwd = 3, col = 1)
text(x = 0.57, y = 2.2, labels = "(b)", cex = 2.5, font = 2)
rect(xleft = 0, ybottom = 1.98, xright = 0.8, ytop = 2.5)
dev.off()


## 12.7 Plot of Posterior Prediction As of January 8, 2008 for Tony Grove SNOTEL Site (Figure 8 In Article)

print("Starting Step 12.7: Plot of Posterior Prediction As of January 8, 2008 for Tony Grove SNOTEL Site")

source("plot.swe.post_jan/Fig8.R")
pdf(file = "Output/SWE2008xxTGswe(Fig_8).pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2008.out1)
dev.off()


## 13. Applying The "swe.svd.mcmc.R" Function To The 2009 Water-Year For The Ten Selected UTAH SNOTEL Sites

print("Starting Step 13: Applying the swe.svd.mcmc.R Function to the 2009 Water-Year for the Ten Selected 
       UTAH SNOTEL Sites Based on the 4 Signals (q = 1, 2, 3, 4)")

## 13.1 2009 Water-Year MCMC Forecasting After day 100

set.seed(12345)
#source("swe.svd.mcmc.R")

q <- 4  ## Number Of Important Signals Selected
n.mcmc <- 5000  ## Number of MCMC Simulations To Be Done
outdat <- 100   ## The Day After Which Forecasting Is Done based on The Posterior Distribution
mm <-100

tmp2009.out1 <- swe.svd.mcmc(t(TGswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009.out2 <- swe.svd.mcmc(t(BLPswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009.out3 <- swe.svd.mcmc(t(HRswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009.out4 <- swe.svd.mcmc(t(LBswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009.out5 <- swe.svd.mcmc(t(BLswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2009.out6 <- swe.svd.mcmc(t(DBPswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009.out7 <- swe.svd.mcmc(t(MCswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009.out8 <- swe.svd.mcmc(t(FARMswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009.out9 <- swe.svd.mcmc(t(TDswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009.out10 <- swe.svd.mcmc(t(PSswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)


## 13.2 2009 Water-Year MCMC Forecasting After day 130

set.seed(12345)

q <- 4  
n.mcmc <- 5000  
outdat <- 130
mm <-130

tmp2009a.out1 <- swe.svd.mcmc(t(TGswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2009a.out2 <- swe.svd.mcmc(t(BLPswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009a.out3 <- swe.svd.mcmc(t(HRswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009a.out4 <- swe.svd.mcmc(t(LBswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009a.out5 <- swe.svd.mcmc(t(BLswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2009a.out6 <- swe.svd.mcmc(t(DBPswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009a.out7 <- swe.svd.mcmc(t(MCswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009a.out8 <- swe.svd.mcmc(t(FARMswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009a.out9 <- swe.svd.mcmc(t(TDswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009a.out10 <- swe.svd.mcmc(t(PSswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)


## 13.3 2009 Water-Year MCMC Forecasting After day 160

set.seed(12345)

q <- 4  
n.mcmc <- 5000  
outdat <- 160
mm <-160

tmp2009b.out1 <- swe.svd.mcmc(t(TGswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2009b.out2 <- swe.svd.mcmc(t(BLPswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009b.out3 <- swe.svd.mcmc(t(HRswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009b.out4 <- swe.svd.mcmc(t(LBswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009b.out5 <- swe.svd.mcmc(t(BLswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2009b.out6 <- swe.svd.mcmc(t(DBPswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009b.out7 <- swe.svd.mcmc(t(MCswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009b.out8 <- swe.svd.mcmc(t(FARMswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009b.out9 <- swe.svd.mcmc(t(TDswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009b.out10 <- swe.svd.mcmc(t(PSswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)


## 13.4 2009 Water-Year MCMC Forecasting After day 190

set.seed(12345)

q <- 4  
n.mcmc <- 5000  
outdat <- 190
mm <-190

tmp2009c.out1 <- swe.svd.mcmc(t(TGswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2009c.out2 <- swe.svd.mcmc(t(BLPswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009c.out3 <- swe.svd.mcmc(t(HRswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009c.out4 <- swe.svd.mcmc(t(LBswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009c.out5 <- swe.svd.mcmc(t(BLswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2009c.out6 <- swe.svd.mcmc(t(DBPswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009c.out7 <- swe.svd.mcmc(t(MCswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009c.out8 <- swe.svd.mcmc(t(FARMswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009c.out9 <- swe.svd.mcmc(t(TDswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2009c.out10 <- swe.svd.mcmc(t(PSswe[, -c(32, 33, 34, 35)]), q, n.mcmc, mm, outdat)


## 14. Creating The Tables For The Proportion Of Observed SWE After days 100 (January 8), 130 (February 7), 
##     160 (March 9), and 190 (April 8) In The 2009 Water-Year That Lies Outside The 50% and 95% Credible 
##     Intervals Obtained For The Posterior Predictive Distribution

print("Starting Step 14: Writing the Table for The Proportion Of Observed SWE After days 100 (January 8), 
       130 (February 7), 160 (March 9), and 190 (April 8) in the 2009 Water-Year That Lies Outside the 50% 
       and 95% Credible Intervals As .csv File")
flush.console()

n <- 10  ## Number Of Selected Sites

## 14.1 Table for Day 100

tmpswe2009 <- list(NA, n)
tmpswe2009[[1]] <- tmp2009.out1
tmpswe2009[[2]] <- tmp2009.out2
tmpswe2009[[3]] <- tmp2009.out3
tmpswe2009[[4]] <- tmp2009.out4
tmpswe2009[[5]] <- tmp2009.out5
tmpswe2009[[6]] <- tmp2009.out6
tmpswe2009[[7]] <- tmp2009.out7
tmpswe2009[[8]] <- tmp2009.out8
tmpswe2009[[9]] <- tmp2009.out9
tmpswe2009[[10]] <- tmp2009.out10

Table2009 <- prop.pred(tmpswe2009)
Table2009 <- data.frame(Table2009)
write.csv(Table2009, file = "Output/Table2009.csv")

## 14.2 Table for Day 130

tmpswe2009a <- list(NA, n)
tmpswe2009a[[1]] <- tmp2009a.out1
tmpswe2009a[[2]] <- tmp2009a.out2
tmpswe2009a[[3]] <- tmp2009a.out3
tmpswe2009a[[4]] <- tmp2009a.out4
tmpswe2009a[[5]] <- tmp2009a.out5
tmpswe2009a[[6]] <- tmp2009a.out6
tmpswe2009a[[7]] <- tmp2009a.out7
tmpswe2009a[[8]] <- tmp2009a.out8
tmpswe2009a[[9]] <- tmp2009a.out9
tmpswe2009a[[10]] <- tmp2009a.out10

Table2009a <- prop.pred(tmpswe2009a)
Table2009a <- data.frame(Table2009a)
write.csv(Table2009a, file = "Output/Table2009a.csv")

## 14.3 Table for Day 160

tmpswe2009b <- list(NA, n)
tmpswe2009b[[1]] <- tmp2009b.out1
tmpswe2009b[[2]] <- tmp2009b.out2
tmpswe2009b[[3]] <- tmp2009b.out3
tmpswe2009b[[4]] <- tmp2009b.out4
tmpswe2009b[[5]] <- tmp2009b.out5
tmpswe2009b[[6]] <- tmp2009b.out6
tmpswe2009b[[7]] <- tmp2009b.out7
tmpswe2009b[[8]] <- tmp2009b.out8
tmpswe2009b[[9]] <- tmp2009b.out9
tmpswe2009b[[10]] <- tmp2009b.out10

Table2009b <- prop.pred(tmpswe2009b)
Table2009b <- data.frame(Table2009b)
write.csv(Table2009b, file = "Output/Table2009b.csv")

## 14.4 Table for Day 190

tmpswe2009c <- list(NA, n)
tmpswe2009c[[1]] <- tmp2009c.out1
tmpswe2009c[[2]] <- tmp2009c.out2
tmpswe2009c[[3]] <- tmp2009c.out3
tmpswe2009c[[4]] <- tmp2009c.out4
tmpswe2009c[[5]] <- tmp2009c.out5
tmpswe2009c[[6]] <- tmp2009c.out6
tmpswe2009c[[7]] <- tmp2009c.out7
tmpswe2009c[[8]] <- tmp2009c.out8
tmpswe2009c[[9]] <- tmp2009c.out9
tmpswe2009c[[10]] <- tmp2009c.out10

Table2009c <- prop.pred(tmpswe2009c)
Table2009c <- data.frame(Table2009c)
write.csv(Table2009c, file = "Output/Table2009c.csv")


## 15. Plots of The Ten SNOTEL Site SWE Measurements and Posterior Prediction As Of January 8 (Day 100),
##     Febraury 7 (Day 130), March 9 (Day 160), and April 8 (Day 190) In The 2009 Water-Year

print("Starting Step 15: Plotting the SWE Measurements and Posterior Prediction of the Ten Sites Selected 
       for the 2009 Water-Year")
flush.console()

## 15.1 Plots for Forecasting After Day 100

source("plot.swe.post_jan.R")
pdf(file = "Output/Output1/SWE2009TGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009.out1)
dev.off()

pdf(file = "Output/Output2/SWE2009BLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009.out2)
dev.off()

pdf(file = "Output/Output3/SWE2009HRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009.out3)
dev.off()

source("plot.swe.post_jan_LBsite.R")
pdf(file = "Output_paper/Output4/SWE2009LBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009.out4)
dev.off()

source("plot.swe.post_jan.R")
pdf(file = "Output/Output5/SWE2009BLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009.out5)
dev.off()

pdf(file = "Output/Output6/SWE2009DBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009.out6)
dev.off()


pdf(file = "Output/Output7/SWE2009MCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009.out7)
dev.off()

pdf(file = "Output/Output8/SWE2009FARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009.out8)
dev.off()

pdf(file = "Output/Output9/SWE2009TDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009.out9)
dev.off()

pdf(file = "Output/Output10/SWE2009PSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009.out10)
dev.off()

## 15.2 Plots for Forecasting After Day 130

source("plot.swe.post_feb.R")
pdf(file = "Output/Output1/SWE2009aTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009a.out1)
dev.off()

pdf(file = "Output/Output2/SWE2009aBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009a.out2)
dev.off()

pdf(file = "Output/Output3/SWE2009aHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009a.out3)
dev.off()

source("plot.swe.post_feb_LBsite.R")
pdf(file = "Output/Output4/SWE2009aLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009a.out4)
dev.off()

source("plot.swe.post_feb.R")
pdf(file = "Output/Output5/SWE2009aBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009a.out5)
dev.off()

pdf(file = "Output/Output6/SWE2009aDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009a.out6)
dev.off()

pdf(file = "Output/Output7/SWE2009aMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009a.out7)
dev.off()

pdf(file = "Output/Output8/SWE2009aFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009a.out8)
dev.off()

pdf(file = "Output/Output9/SWE2009aTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009a.out9)
dev.off()

pdf(file = "Output/Output10/SWE2009aPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009a.out10)
dev.off()


## 15.3 Plots for Forecasting After Day 160

source("plot.swe.post_mar.R")
pdf(file = "Output/Output1/SWE2009bTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009b.out1)
dev.off()

pdf(file = "Output/Output2/SWE2009bBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009b.out2)
dev.off()

pdf(file = "Output/Output3/SWE2009bHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009b.out3)
dev.off()

source("plot.swe.post_mar_LBsite.R")
pdf(file = "Output/Output4/SWE2009bLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009b.out4)
dev.off()

source("plot.swe.post_mar.R")
pdf(file = "Output/Output5/SWE2009bBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009b.out5)
dev.off()

pdf(file = "Output/Output6/SWE2009bDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009b.out6)
dev.off()

pdf(file = "Output/Output7/SWE2009bMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009b.out7)
dev.off()

pdf(file = "Output/Output8/SWE2009bFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009b.out8)
dev.off()

pdf(file = "Output/Output9/SWE2009bTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009b.out9)
dev.off()

pdf(file = "Output/Output10/SWE2009bPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009b.out10)
dev.off()


## 15.4 Plots for Forecasting After Day 190

source("plot.swe.post_apr.R")
pdf(file = "Output/Output1/SWE2009cTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009c.out1)
dev.off()

pdf(file = "Output/Output2/SWE2009cBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009c.out2)
dev.off()

pdf(file = "Output/Output3/SWE2009cHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009c.out3)
dev.off()

source("plot.swe.post_apr_LBsite.R")
pdf(file = "Output_paper/Output4/SWE2009cLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009c.out4)
dev.off()

source("plot.swe.post_apr.R")
pdf(file = "Output/Output5/SWE2009cBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009c.out5)
dev.off()

pdf(file = "Output/Output6/SWE2009cDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009c.out6)
dev.off()

pdf(file = "Output/Output7/SWE2009cMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009c.out7)
dev.off()

pdf(file = "Output_paper/Output8/SWE2009cFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009c.out8)
dev.off()

pdf(file = "Output/Output9/SWE2009cTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009c.out9)
dev.off()

pdf(file = "Output/Output10/SWE2009cPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2009c.out10)
dev.off()



## 16. Applying The "swe.svd.mcmc.R" Function To The 2010 Water-Year For The Ten Selected UTAH SNOTEL Sites

print("Starting Step 16: Applying the swe.svd.mcmc.R Function to the 2010 Water-Year for the 
       Ten Selected UTAH SNOTEL Sites Based on the 4 Signals (q = 1, 2, 3, 4)")


## 16.1 2010 Water-Year MCMC Forecasting After day 100

set.seed(12345)
#source("swe.svd.mcmc.R")
q <- 4  ## Number Of Important Signals Selected
n.mcmc <- 5000  ## Number of MCMC Simulations To Be Done
outdat <- 100   ## The Day After Which Forecasting Is Done based on The Posterior Distribution
mm <-100

tmp2010.out1 <- swe.svd.mcmc(t(TGswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2010.out2 <- swe.svd.mcmc(t(BLPswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010.out3 <- swe.svd.mcmc(t(HRswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010.out4 <- swe.svd.mcmc(t(LBswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010.out5 <- swe.svd.mcmc(t(BLswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2010.out6 <- swe.svd.mcmc(t(DBPswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010.out7 <- swe.svd.mcmc(t(MCswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010.out8 <- swe.svd.mcmc(t(FARMswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010.out9 <- swe.svd.mcmc(t(TDswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010.out10 <- swe.svd.mcmc(t(PSswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)

## 16.2 2010 Water-Year MCMC Forecasting After day 130

set.seed(12345)
q <- 4  
n.mcmc <- 5000  
outdat <- 130
mm <-130

tmp2010a.out1 <- swe.svd.mcmc(t(TGswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2010a.out2 <- swe.svd.mcmc(t(BLPswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010a.out3 <- swe.svd.mcmc(t(HRswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010a.out4 <- swe.svd.mcmc(t(LBswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010a.out5 <- swe.svd.mcmc(t(BLswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2010a.out6 <- swe.svd.mcmc(t(DBPswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010a.out7 <- swe.svd.mcmc(t(MCswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010a.out8 <- swe.svd.mcmc(t(FARMswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010a.out9 <- swe.svd.mcmc(t(TDswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010a.out10 <- swe.svd.mcmc(t(PSswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)

## 16.3 2010 Water-Year MCMC Forecasting After day 160

set.seed(12345)
q <- 4  
n.mcmc <- 5000  
outdat <- 160
mm <-160

tmp2010b.out1 <- swe.svd.mcmc(t(TGswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2010b.out2 <- swe.svd.mcmc(t(BLPswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010b.out3 <- swe.svd.mcmc(t(HRswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010b.out4 <- swe.svd.mcmc(t(LBswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010b.out5 <- swe.svd.mcmc(t(BLswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2010b.out6 <- swe.svd.mcmc(t(DBPswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010b.out7 <- swe.svd.mcmc(t(MCswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010b.out8 <- swe.svd.mcmc(t(FARMswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010b.out9 <- swe.svd.mcmc(t(TDswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010b.out10 <- swe.svd.mcmc(t(PSswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)


## 16.4 2010 Water-Year MCMC Forecasting After day 190
set.seed(12345)
#source("swe.svd.mcmc.R")
q <- 4  
n.mcmc <- 5000  
outdat <- 190
mm <-190

tmp2010c.out1 <- swe.svd.mcmc(t(TGswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)  
tmp2010c.out2 <- swe.svd.mcmc(t(BLPswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010c.out3 <- swe.svd.mcmc(t(HRswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010c.out4 <- swe.svd.mcmc(t(LBswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010c.out5 <- swe.svd.mcmc(t(BLswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)

tmp2010c.out6 <- swe.svd.mcmc(t(DBPswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010c.out7 <- swe.svd.mcmc(t(MCswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010c.out8 <- swe.svd.mcmc(t(FARMswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010c.out9 <- swe.svd.mcmc(t(TDswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)
tmp2010c.out10 <- swe.svd.mcmc(t(PSswe[, -c(33, 34, 35)]), q, n.mcmc, mm, outdat)


## 17. Creating The Tables For The Proportion Of Observed SWE After days 100 (January 8), 130 (February 7), 
##     160 (March 9), and 190 (April 8) In The 2010 Water-Year That Lies Outside The 50% and 95% Credible 
##     Intervals Obtained For The Posterior Predictive Distribution

print("Starting Step 17: Writing the Table for The Proportion Of Observed SWE After days 100 (January 8), 
       130 (February 7), 160 (March 9), and 190 (April 8) in the 2010 Water-Year That Lies Outside the 50% 
       and 95% Credible Intervals As .csv File")
flush.console()

n <- 10  ## Number Of Selected Sites

## 17.1 Table for Day 100

tmpswe2010 <- list(NA, n)
tmpswe2010[[1]] <- tmp2010.out1
tmpswe2010[[2]] <- tmp2010.out2
tmpswe2010[[3]] <- tmp2010.out3
tmpswe2010[[4]] <- tmp2010.out4
tmpswe2010[[5]] <- tmp2010.out5
tmpswe2010[[6]] <- tmp2010.out6
tmpswe2010[[7]] <- tmp2010.out7
tmpswe2010[[8]] <- tmp2010.out8
tmpswe2010[[9]] <- tmp2010.out9
tmpswe2010[[10]] <- tmp2010.out10

Table2010 <- prop.pred(tmpswe2010)
Table2010 <- data.frame(Table2010)
write.csv(Table2010, file = "Output/Table2010.csv")

## 17.2 Table for Day 130

tmpswe2010a <- list(NA, n)
tmpswe2010a[[1]] <- tmp2010a.out1
tmpswe2010a[[2]] <- tmp2010a.out2
tmpswe2010a[[3]] <- tmp2010a.out3
tmpswe2010a[[4]] <- tmp2010a.out4
tmpswe2010a[[5]] <- tmp2010a.out5
tmpswe2010a[[6]] <- tmp2010a.out6
tmpswe2010a[[7]] <- tmp2010a.out7
tmpswe2010a[[8]] <- tmp2010a.out8
tmpswe2010a[[9]] <- tmp2010a.out9
tmpswe2010a[[10]] <- tmp2010a.out10

Table2010a <- prop.pred(tmpswe2010a)
Table2010a <- data.frame(Table2010a)
write.csv(Table2010a, file = "Output/Table2010a.csv")

## 17.3 Table for Day 160

tmpswe2010b <- list(NA, n)
tmpswe2010b[[1]] <- tmp2010b.out1
tmpswe2010b[[2]] <- tmp2010b.out2
tmpswe2010b[[3]] <- tmp2010b.out3
tmpswe2010b[[4]] <- tmp2010b.out4
tmpswe2010b[[5]] <- tmp2010b.out5
tmpswe2010b[[6]] <- tmp2010b.out6
tmpswe2010b[[7]] <- tmp2010b.out7
tmpswe2010b[[8]] <- tmp2010b.out8
tmpswe2010b[[9]] <- tmp2010b.out9
tmpswe2010b[[10]] <- tmp2010b.out10

Table2010b <- prop.pred(tmpswe2010b)
Table2010b <- data.frame(Table2010b)
write.csv(Table2010b, file = "Output/Table2010b.csv")

## 17.4 Table for Day 190

tmpswe2010c <- list(NA, n)
tmpswe2010c[[1]] <- tmp2010c.out1
tmpswe2010c[[2]] <- tmp2010c.out2
tmpswe2010c[[3]] <- tmp2010c.out3
tmpswe2010c[[4]] <- tmp2010c.out4
tmpswe2010c[[5]] <- tmp2010c.out5
tmpswe2010c[[6]] <- tmp2010c.out6
tmpswe2010c[[7]] <- tmp2010c.out7
tmpswe2010c[[8]] <- tmp2010c.out8
tmpswe2010c[[9]] <- tmp2010c.out9
tmpswe2010c[[10]] <- tmp2010c.out10

Table2010c <- prop.pred(tmpswe2010c)
Table2010c <- data.frame(Table2010c)
write.csv(Table2010c, file = "Output/Table2010c.csv")


## 18. Plots of The Ten SNOTEL Site SWE Measurements and Posterior Prediction As Of January 8 (Day 100),
##     Febraury 7 (Day 130), March 9 (Day 160), and April 8 (Day 190) In The 2010 Water-Year

print("Starting Step 18: Plotting the SWE Measurements and Posterior Prediction of the Ten Sites Selected for the 2010 Water-Year")
flush.console()

## 18.1 Plots for Forecasting After Day 100

source("plot.swe.post_jan.R")
pdf(file = "Output/Output1/SWE2010TGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010.out1)
dev.off()

pdf(file = "Output/Output2/SWE2010BLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010.out2)
dev.off()

pdf(file = "Output/Output3/SWE2010HRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010.out3)
dev.off()

source("plot.swe.post_jan_LBsite.R")
pdf(file = "Output/Output4/SWE2010LBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010.out4)
dev.off()

source("plot.swe.post_jan.R")
pdf(file = "Output/Output5/SWE2010BLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010.out5)
dev.off()

pdf(file = "Output/Output6/SWE2010DBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010.out6)
dev.off()

pdf(file = "Output/Output7/SWE2010MCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010.out7)
dev.off()

pdf(file = "Output/Output8/SWE2010FARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010.out8)
dev.off()

pdf(file = "Output/Output9/SWE2010TDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010.out9)
dev.off()

pdf(file = "Output/Output10/SWE2010PSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010.out10)
dev.off()

## 18.2 Plots for Forecasting After Day 130

source("plot.swe.post_feb.R")
pdf(file = "Output/Output1/SWE2010aTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010a.out1)
dev.off()

pdf(file = "Output/Output2/SWE2010aBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010a.out2)
dev.off()

pdf(file = "Output/Output3/SWE2010aHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010a.out3)
dev.off()

source("plot.swe.post_feb_LBsite.R")
pdf(file = "Output/Output4/SWE2010aLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010a.out4)
dev.off()

source("plot.swe.post_feb.R")
pdf(file = "Output/Output5/SWE2010aBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010a.out5)
dev.off()

pdf(file = "Output/Output6/SWE2010aDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010a.out6)
dev.off()

pdf(file = "Output/Output7/SWE2010aMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010a.out7)
dev.off()

pdf(file = "Output/Output8/SWE2010aFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010a.out8)
dev.off()

pdf(file = "Output/Output9/SWE2010aTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010a.out9)
dev.off()

pdf(file = "Output/Output10/SWE2010aPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010a.out10)
dev.off()

## 18.3 Plots for Forecasting After Day 160

source("plot.swe.post_mar.R")
pdf(file = "Output/Output1/SWE2010bTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010b.out1)
dev.off()

pdf(file = "Output/Output2/SWE2010bBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010b.out2)
dev.off()

pdf(file = "Output/Output3/SWE2010bHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010b.out3)
dev.off()

source("plot.swe.post_mar_LBsite.R")
pdf(file = "Output/Output4/SWE2010bLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010b.out4)
dev.off()

source("plot.swe.post_mar.R")
pdf(file = "Output/Output5/SWE2010bBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010b.out5)
dev.off()

pdf(file = "Output/Output6/SWE2010bDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010b.out6)
dev.off()

pdf(file = "Output/Output7/SWE2010bMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010b.out7)
dev.off()

pdf(file = "Output/Output8/SWE2010bFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010b.out8)
dev.off()

pdf(file = "Output/Output9/SWE2010bTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010b.out9)
dev.off()

pdf(file = "Output/Output10/SWE2010bPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010b.out10)
dev.off()

## 18.4 Plots for Forecasting After Day 190

source("plot.swe.post_apr.R")
pdf(file = "Output/Output1/SWE2010cTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010c.out1)
dev.off()

pdf(file = "Output/Output2/SWE2010cBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010c.out2)
dev.off()

pdf(file = "Output/Output3/SWE2010cHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010c.out3)
dev.off()

source("plot.swe.post_apr_LBsite.R")
pdf(file = "Output/Output4/SWE2010cLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010c.out4)
dev.off()

source("plot.swe.post_apr.R")
pdf(file = "Output/Output5/SWE2010cBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010c.out5)
dev.off()

pdf(file = "Output/Output6/SWE2010cDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010c.out6)
dev.off()

pdf(file = "Output/Output7/SWE2010cMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010c.out7)
dev.off()

pdf(file = "Output/Output8/SWE2010cFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010c.out8)
dev.off()

pdf(file = "Output/Output9/SWE2010cTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010c.out9)
dev.off()

pdf(file = "Output/Output10/SWE2010cPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2010c.out10)
dev.off()



## 19. Applying The "swe.svd.mcmc.R" Function To The 2011 Water-Year For The Ten Selected UTAH SNOTEL Sites

print("Starting Step 19: Applying the swe.svd.mcmc.R Function to the 2011 Water-Year for the Ten Selected 
       UTAH SNOTEL Sites Based on the 4 Signals (q = 1, 2, 3, 4)")

## 19.1 2011 Water-Year MCMC Forecasting After day 100

set.seed(12345)

q <- 4  
n.mcmc <- 5000  
outdat <- 100
mm <-100

tmp2011.out1 <- swe.svd.mcmc(t(TGswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011.out2 <- swe.svd.mcmc(t(BLPswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011.out3 <- swe.svd.mcmc(t(HRswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011.out4 <- swe.svd.mcmc(t(LBswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011.out5 <- swe.svd.mcmc(t(BLswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)

tmp2011.out6 <- swe.svd.mcmc(t(DBPswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011.out7 <- swe.svd.mcmc(t(MCswe[, -c(34, 35)), q, n.mcmc, mm, outdat)
tmp2011.out8 <- swe.svd.mcmc(t(FARMswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011.out9 <- swe.svd.mcmc(t(TDswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011.out10 <- swe.svd.mcmc(t(PSswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)

## 19.2 2011 Water-Year MCMC Forecasting After day 130

set.seed(12345)

q <- 4  
n.mcmc <- 5000  
outdat <- 130
mm <-130

tmp2011a.out1 <- swe.svd.mcmc(t(TGswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011a.out2 <- swe.svd.mcmc(t(BLPswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011a.out3 <- swe.svd.mcmc(t(HRswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011a.out4 <- swe.svd.mcmc(t(LBswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011a.out5 <- swe.svd.mcmc(t(BLswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)

tmp2011a.out6 <- swe.svd.mcmc(t(DBPswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011a.out7 <- swe.svd.mcmc(t(MCswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011a.out8 <- swe.svd.mcmc(t(FARMswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011a.out9 <- swe.svd.mcmc(t(TDswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011a.out10 <- swe.svd.mcmc(t(PSswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)

## 19.3 2011 Water-Year MCMC Forecasting After day 160

set.seed(12345)

q <- 4  
n.mcmc <- 5000  
outdat <- 160
mm <-160

tmp2011b.out1 <- swe.svd.mcmc(t(TGswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)  
tmp2011b.out2 <- swe.svd.mcmc(t(BLPswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011b.out3 <- swe.svd.mcmc(t(HRswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011b.out4 <- swe.svd.mcmc(t(LBswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011b.out5 <- swe.svd.mcmc(t(BLswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)

tmp2011b.out6 <- swe.svd.mcmc(t(DBPswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011b.out7 <- swe.svd.mcmc(t(MCswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011b.out8 <- swe.svd.mcmc(t(FARMswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011b.out9 <- swe.svd.mcmc(t(TDswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011b.out10 <- swe.svd.mcmc(t(PSswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)

## 19.4 2011 Water-Year MCMC Forecasting After day 190

set.seed(12345)

q <- 4  
n.mcmc <- 5000  
outdat <- 190
mm <-190

tmp2011c.out1 <- swe.svd.mcmc(t(TGswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)  
tmp2011c.out2 <- swe.svd.mcmc(t(BLPswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011c.out3 <- swe.svd.mcmc(t(HRswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011c.out4 <- swe.svd.mcmc(t(LBswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011c.out5 <- swe.svd.mcmc(t(BLswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)

tmp2011c.out6 <- swe.svd.mcmc(t(DBPswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011c.out7 <- swe.svd.mcmc(t(MCswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011c.out8 <- swe.svd.mcmc(t(FARMswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011c.out9 <- swe.svd.mcmc(t(TDswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)
tmp2011c.out10 <- swe.svd.mcmc(t(PSswe[, -c(34, 35)]), q, n.mcmc, mm, outdat)


## 20. Creating The Tables For The Proportion Of Observed SWE After days 100 (January 8), 130 (February 7), 
##     160 (March 9), and 190 (April 8) In The 2011 Water-Year That Lies Outside The 50% and 95% Credible 
##     Intervals Obtained For The Posterior Predictive Distribution

print("Starting Step 20: Writing the Table for The Proportion Of Observed SWE After days 100 (January 8), 
       130 (February 7), 160 (March 9), and 190 (April 8) in the 2011 Water-Year That Lies Outside the 50% 
       and 95% Credible Intervals As .csv File")
flush.console()

n <- 10  ## Number Of Selected Sites

## 20.1 Table for Day 100

tmpswe2011 <- list(NA, n)
tmpswe2011[[1]] <- tmp2011.out1
tmpswe2011[[2]] <- tmp2011.out2
tmpswe2011[[3]] <- tmp2011.out3
tmpswe2011[[4]] <- tmp2011.out4
tmpswe2011[[5]] <- tmp2011.out5
tmpswe2011[[6]] <- tmp2011.out6
tmpswe2011[[7]] <- tmp2011.out7
tmpswe2011[[8]] <- tmp2011.out8
tmpswe2011[[9]] <- tmp2011.out9
tmpswe2011[[10]] <- tmp2011.out10

Table2011 <- prop.pred(tmpswe2011)
Table2011 <- data.frame(Table2011)
write.csv(Table2011, file = "Output/Table2011.csv")

## 20.2 Table for Day 130

tmpswe2011a <- list(NA, n)
tmpswe2011a[[1]] <- tmp2011a.out1
tmpswe2011a[[2]] <- tmp2011a.out2
tmpswe2011a[[3]] <- tmp2011a.out3
tmpswe2011a[[4]] <- tmp2011a.out4
tmpswe2011a[[5]] <- tmp2011a.out5
tmpswe2011a[[6]] <- tmp2011a.out6
tmpswe2011a[[7]] <- tmp2011a.out7
tmpswe2011a[[8]] <- tmp2011a.out8
tmpswe2011a[[9]] <- tmp2011a.out9
tmpswe2011a[[10]] <- tmp2011a.out10

Table2011a <- prop.pred(tmpswe2011a)
Table2011a <- data.frame(Table2011a)
write.csv(Table2011a, file = "Output/Table2011a.csv")

## 20.3 Table for Day 160

tmpswe2011b <- list(NA, n)
tmpswe2011b[[1]] <- tmp2011b.out1
tmpswe2011b[[2]] <- tmp2011b.out2
tmpswe2011b[[3]] <- tmp2011b.out3
tmpswe2011b[[4]] <- tmp2011b.out4
tmpswe2011b[[5]] <- tmp2011b.out5
tmpswe2011b[[6]] <- tmp2011b.out6
tmpswe2011b[[7]] <- tmp2011b.out7
tmpswe2011b[[8]] <- tmp2011b.out8
tmpswe2011b[[9]] <- tmp2011b.out9
tmpswe2011b[[10]] <- tmp2011b.out10

Table2011b <- prop.pred(tmpswe2011b)
Table2011b <- data.frame(Table2011b)
write.csv(Table2011b, file = "Output/Table2011b.csv")

## 20.4 Table for Day 190

tmpswe2011c <- list(NA, n)
tmpswe2011c[[1]] <- tmp2011c.out1
tmpswe2011c[[2]] <- tmp2011c.out2
tmpswe2011c[[3]] <- tmp2011c.out3
tmpswe2011c[[4]] <- tmp2011c.out4
tmpswe2011c[[5]] <- tmp2011c.out5
tmpswe2011c[[6]] <- tmp2011c.out6
tmpswe2011c[[7]] <- tmp2011c.out7
tmpswe2011c[[8]] <- tmp2011c.out8
tmpswe2011c[[9]] <- tmp2011c.out9
tmpswe2011c[[10]] <- tmp2011c.out10

Table2011c <- prop.pred(tmpswe2011c)
Table2011c <- data.frame(Table2011c)
write.csv(Table2011c, file = "Output/Table2011c.csv")


## 21. Plots of The Ten SNOTEL Site SWE Measurements and Posterior Prediction As Of January 8 (Day 100),
##     Febraury 7 (Day 130), March 9 (Day 160), and April 8 (Day 190) In The 2011 Water-Year

print("Starting Step 21: Plotting the SWE Measurements and Posterior Prediction of the Ten Sites Selected for the 2011 Water-Year")
flush.console()

## 21.1 Plots for Forecasting After Day 100

source("plot.swe.post_jan.R")
pdf(file = "Output/Output1/SWE2011TGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011.out1)
dev.off()

pdf(file = "Output/Output2/SWE2011BLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011.out2)
dev.off()

pdf(file = "Output/Output3/SWE2011HRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011.out3)
dev.off()

source("plot.swe.post_jan_LBsite.R")
pdf(file = "Output/Output4/SWE2011LBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011.out4)
dev.off()

source("plot.swe.post_jan.R")
pdf(file = "Output/Output5/SWE2011BLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011.out5)
dev.off()

pdf(file = "Output/Output6/SWE2011DBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011.out6)
dev.off()

pdf(file = "Output/Output7/SWE2011MCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011.out7)
dev.off()

pdf(file = "Output/Output8/SWE2011FARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011.out8)
dev.off()

pdf(file = "Output/Output9/SWE2011TDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011.out9)
dev.off()

pdf(file = "Output/Output10/SWE2011PSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011.out10)
dev.off()

## 21.2 Plots for Forecasting After Day 130

source("plot.swe.post_feb.R")
pdf(file = "Output/Output1/SWE2011aTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011a.out1)
dev.off()

pdf(file = "Output/Output2/SWE2011aBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011a.out2)
dev.off()

pdf(file = "Output/Output3/SWE2011aHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011a.out3)
dev.off()

source("plot.swe.post_feb_LBsite.R")
pdf(file = "Output/Output4/SWE2011aLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011a.out4)
dev.off()

source("plot.swe.post_feb.R")
pdf(file = "Output/Output5/SWE2011aBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011a.out5)
dev.off()

pdf(file = "Output/Output6/SWE2011aDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011a.out6)
dev.off()

pdf(file = "Output/Output7/SWE2011aMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011a.out7)
dev.off()

pdf(file = "Output/Output8/SWE2011aFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011a.out8)
dev.off()

pdf(file = "Output/Output9/SWE2011aTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011a.out9)
dev.off()

pdf(file = "Output/Output10/SWE2011aPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011a.out10)
dev.off()

## 21.2 Plots for Forecasting After Day 160

source("plot.swe.post_mar.R")
pdf(file = "Output/Output1/SWE2011bTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011b.out1)
dev.off()

pdf(file = "Output/Output2/SWE2011bBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011b.out2)
dev.off()

pdf(file = "Output/Output3/SWE2011bHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011b.out3)
dev.off()

source("plot.swe.post_mar_LBsite.R")
pdf(file = "Output/Output4/SWE2011bLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011b.out4)
dev.off()

source("plot.swe.post_mar.R")
pdf(file = "Output/Output5/SWE2011bBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011b.out5)
dev.off()

pdf(file = "Output/Output6/SWE2011bDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011b.out6)
dev.off()

pdf(file = "Output/Output7/SWE2011bMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011b.out7)
dev.off()

pdf(file = "Output/Output8/SWE2011bFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011b.out8)
dev.off()

pdf(file = "Output/Output9/SWE2011bTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011b.out9)
dev.off()

pdf(file = "Output/Output10/SWE2011bPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011b.out10)
dev.off()

## 21.2 Plots for Forecasting After Day 190

source("plot.swe.post_apr.R")
pdf(file = "Output/Output1/SWE2011cTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011c.out1)
dev.off()

pdf(file = "Output/Output2/SWE2011cBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011c.out2)
dev.off()

pdf(file = "Output/Output3/SWE2011cHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011c.out3)
dev.off()

source("plot.swe.post_apr_LBsite.R")
pdf(file = "Output/Output4/SWE2011cLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011c.out4)
dev.off()

source("plot.swe.post_apr.R")
pdf(file = "Output/Output5/SWE2011cBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011c.out5)
dev.off()

pdf(file = "Output/Output6/SWE2011cDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011c.out6)
dev.off()

pdf(file = "Output/Output7/SWE2011cMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011c.out7)
dev.off()

pdf(file = "Output/Output8/SWE2011cFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011c.out8)
dev.off()

pdf(file = "Output/Output9/SWE2011cTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011c.out9)
dev.off()

pdf(file = "Output/Output10/SWE2011cPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2011c.out10)
dev.off()


## 22. Applying The "swe.svd.mcmc.R" Function To The 2012 Water-Year For The Ten Selected UTAH SNOTEL Sites

print("Starting Step 22: Applying the swe.svd.mcmc.R Function to the 2012 Water-Year for the Ten Selected 
       UTAH SNOTEL Sites Based on the q = 4 (Important Signals)")

## 22.1 2011 Water-Year MCMC Forecasting After day 100

set.seed(12345)
q <- 4  ## Number Of Important Signals Selected
n.mcmc <- 5000  ## Number of MCMC Simulations To Be Done
outdat <- 100  ## The Day After Which Forecasting Is Done based on The Posterior Distribution
mm <-100

tmp2012.out1 <- swe.svd.mcmc(t(TGswe[, -35]), q, n.mcmc, mm, outdat)  
tmp2012.out2 <- swe.svd.mcmc(t(BLPswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012.out3 <- swe.svd.mcmc(t(HRswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012.out4 <- swe.svd.mcmc(t(LBswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012.out5 <- swe.svd.mcmc(t(BLswe[, -35]), q, n.mcmc, mm, outdat)

tmp2012.out6 <- swe.svd.mcmc(t(DBPswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012.out7 <- swe.svd.mcmc(t(MCswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012.out8 <- swe.svd.mcmc(t(FARMswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012.out9 <- swe.svd.mcmc(t(TDswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012.out10 <- swe.svd.mcmc(t(PSswe[, -35]), q, n.mcmc, mm, outdat)

## 22.2 2011 Water-Year MCMC Forecasting After day 130

set.seed(12345)
q <- 4  
n.mcmc <- 5000  
outdat <- 130
mm <-130

tmp2012a.out1 <- swe.svd.mcmc(t(TGswe[, -35]), q, n.mcmc, mm, outdat)  
tmp2012a.out2 <- swe.svd.mcmc(t(BLPswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012a.out3 <- swe.svd.mcmc(t(HRswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012a.out4 <- swe.svd.mcmc(t(LBswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012a.out5 <- swe.svd.mcmc(t(BLswe[, -35]), q, n.mcmc, mm, outdat)

tmp2012a.out6 <- swe.svd.mcmc(t(DBPswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012a.out7 <- swe.svd.mcmc(t(MCswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012a.out8 <- swe.svd.mcmc(t(FARMswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012a.out9 <- swe.svd.mcmc(t(TDswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012a.out10 <- swe.svd.mcmc(t(PSswe[, -35]), q, n.mcmc, mm, outdat)

## 22.3 2011 Water-Year MCMC Forecasting After day 160

set.seed(12345)
q <- 4  
n.mcmc <- 5000  
outdat <- 160
mm <-160

tmp2012b.out1 <- swe.svd.mcmc(t(TGswe[, -35]), q, n.mcmc, mm, outdat)  
tmp2012b.out2 <- swe.svd.mcmc(t(BLPswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012b.out3 <- swe.svd.mcmc(t(HRswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012b.out4 <- swe.svd.mcmc(t(LBswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012b.out5 <- swe.svd.mcmc(t(BLswe[, -35]), q, n.mcmc, mm, outdat)

tmp2012b.out6 <- swe.svd.mcmc(t(DBPswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012b.out7 <- swe.svd.mcmc(t(MCswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012b.out8 <- swe.svd.mcmc(t(FARMswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012b.out9 <- swe.svd.mcmc(t(TDswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012b.out10 <- swe.svd.mcmc(t(PSswe[, -35]), q, n.mcmc, mm, outdat)

## 22.4 2011 Water-Year MCMC Forecasting After day 190

set.seed(12345)
q <- 4  
n.mcmc <- 5000  
outdat <- 190
mm <-190

tmp2012c.out1 <- swe.svd.mcmc(t(TGswe[, -35]), q, n.mcmc, mm, outdat)  
tmp2012c.out2 <- swe.svd.mcmc(t(BLPswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012c.out3 <- swe.svd.mcmc(t(HRswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012c.out4 <- swe.svd.mcmc(t(LBswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012c.out5 <- swe.svd.mcmc(t(BLswe[, -35]), q, n.mcmc, mm, outdat)

tmp2012c.out6 <- swe.svd.mcmc(t(DBPswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012c.out7 <- swe.svd.mcmc(t(MCswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012c.out8 <- swe.svd.mcmc(t(FARMswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012c.out9 <- swe.svd.mcmc(t(TDswe[, -35]), q, n.mcmc, mm, outdat)
tmp2012c.out10 <- swe.svd.mcmc(t(PSswe[, -35]), q, n.mcmc, mm, outdat)


## 23. Creating The Tables For The Proportion Of Observed SWE After days 100 (January 8), 130 (February 7), 
##     160 (March 9), and 190 (April 8) In The 2012 Water-Year That Lies Outside The 50% and 95% Credible 
##     Intervals Obtained For The Posterior Predictive Distribution

print("Starting Step 23: Writing the Table for The Proportion Of Observed SWE After days 100 (January 8), 
       130 (February 7), 160 (March 9), and 190 (April 8) in the 2012 Water-Year That Lies Outside the 50%
       and 95% Credible Intervals As .csv File")
flush.console()

n <- 10  ## Number Of Selected Sites

## 23.1 Table for Day 100

tmpswe2012 <- list(NA, n)
tmpswe2012[[1]] <- tmp2012.out1
tmpswe2012[[2]] <- tmp2012.out2
tmpswe2012[[3]] <- tmp2012.out3
tmpswe2012[[4]] <- tmp2012.out4
tmpswe2012[[5]] <- tmp2012.out5
tmpswe2012[[6]] <- tmp2012.out6
tmpswe2012[[7]] <- tmp2012.out7
tmpswe2012[[8]] <- tmp2012.out8
tmpswe2012[[9]] <- tmp2012.out9
tmpswe2012[[10]] <- tmp2012.out10

Table2012 <- prop.pred(tmpswe2012)
Table2012 <- data.frame(Table2012)
write.csv(Table2012, file = "Output/Table2012.csv")

## 23.2 Table for Day 130

tmpswe2012a <- list(NA, n)
tmpswe2012a[[1]] <- tmp2012a.out1
tmpswe2012a[[2]] <- tmp2012a.out2
tmpswe2012a[[3]] <- tmp2012a.out3
tmpswe2012a[[4]] <- tmp2012a.out4
tmpswe2012a[[5]] <- tmp2012a.out5
tmpswe2012a[[6]] <- tmp2012a.out6
tmpswe2012a[[7]] <- tmp2012a.out7
tmpswe2012a[[8]] <- tmp2012a.out8
tmpswe2012a[[9]] <- tmp2012a.out9
tmpswe2012a[[10]] <- tmp2012a.out10

Table2012a <- prop.pred(tmpswe2012a)
Table2012a <- data.frame(Table2012a)
write.csv(Table2012a, file = "Output/Table2012a.csv")

## 23.3 Table for Day 160

tmpswe2012b <- list(NA, n)
tmpswe2012b[[1]] <- tmp2012b.out1
tmpswe2012b[[2]] <- tmp2012b.out2
tmpswe2012b[[3]] <- tmp2012b.out3
tmpswe2012b[[4]] <- tmp2012b.out4
tmpswe2012b[[5]] <- tmp2012b.out5
tmpswe2012b[[6]] <- tmp2012b.out6
tmpswe2012b[[7]] <- tmp2012b.out7
tmpswe2012b[[8]] <- tmp2012b.out8
tmpswe2012b[[9]] <- tmp2012b.out9
tmpswe2012b[[10]] <- tmp2012b.out10

Table2012b <- prop.pred(tmpswe2012b)
Table2012b <- data.frame(Table2012b)
write.csv(Table2012b, file = "Output/Table2012b.csv")

## 23.4 Table for Day 190

tmpswe2012c <- list(NA, n)
tmpswe2012c[[1]] <- tmp2012c.out1
tmpswe2012c[[2]] <- tmp2012c.out2
tmpswe2012c[[3]] <- tmp2012c.out3
tmpswe2012c[[4]] <- tmp2012c.out4
tmpswe2012c[[5]] <- tmp2012c.out5
tmpswe2012c[[6]] <- tmp2012c.out6
tmpswe2012c[[7]] <- tmp2012c.out7
tmpswe2012c[[8]] <- tmp2012c.out8
tmpswe2012c[[9]] <- tmp2012c.out9
tmpswe2012c[[10]] <- tmp2012c.out10

Table2012c <- prop.pred(tmpswe2012c)
Table2012c <- data.frame(Table2012c)
write.csv(Table2012c, file = "Output/Table2012c.csv")



## 24. Plots of The Ten SNOTEL Site SWE Measurements and Posterior Prediction As Of January 8 (Day 100),
##     Febraury 7 (Day 130), March 9 (Day 160), and April 8 (Day 190) In The 2012 Water-Year

print("Starting Step 24: Plotting the SWE Measurements and Posterior Prediction of the Ten Sites Selected for the 2012 Water-Year")
flush.console()

## 24.1 Plots for Forecasting After Day 100

source("plot.swe.post_jan.R")
pdf(file = "Output/Output1/SWE2012TGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012.out1)
dev.off()

pdf(file = "Output/Output2/SWE2012BLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012.out2)
dev.off()

pdf(file = "Output/Output3/SWE2012HRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012.out3)
dev.off()

source("plot.swe.post_jan_LBsite.R")
pdf(file = "Output/Output4/SWE2012LBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012.out4)
dev.off()

source("plot.swe.post_jan.R")
pdf(file = "Output/Output5/SWE2012BLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012.out5)
dev.off()

pdf(file = "Output/Output6/SWE2012DBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012.out6)
dev.off()

pdf(file = "Output/Output7/SWE2012MCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012.out7)
dev.off()

pdf(file = "Output/Output8/SWE2012FARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012.out8)
dev.off()

pdf(file = "Output/Output9/SWE2012TDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012.out9)
dev.off()

pdf(file = "Output/Output10/SWE2012PSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012.out10)
dev.off()

## 24.2 Plots for Forecasting After Day 130

source("plot.swe.post_feb.R")
pdf(file = "Output/Output1/SWE2012aTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012a.out1)
dev.off()

pdf(file = "Output/Output2/SWE2012aBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012a.out2)
dev.off()

pdf(file = "Output/Output3/SWE2012aHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012a.out3)
dev.off()

source("plot.swe.post_feb_LBsite.R")
pdf(file = "Output/Output4/SWE2012aLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012a.out4)
dev.off()

source("plot.swe.post_feb.R")
pdf(file = "Output/Output5/SWE2012aBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012a.out5)
dev.off()

pdf(file = "Output/Output6/SWE2012aDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012a.out6)
dev.off()

pdf(file = "Output/Output7/SWE2012aMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012a.out7)
dev.off()

pdf(file = "Output/Output8/SWE2012aFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012a.out8)
dev.off()

pdf(file = "Output/Output9/SWE2012aTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012a.out9)
dev.off()

pdf(file = "Output/Output10/SWE2012aPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012a.out10)
dev.off()

## 24.2 Plots for Forecasting After Day 160

source("plot.swe.post_mar.R")
pdf(file = "Output/Output1/SWE2012bTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012b.out1)
dev.off()

pdf(file = "Output/Output2/SWE2012bBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012b.out2)
dev.off()

pdf(file = "Output/Output3/SWE2012bHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012b.out3)
dev.off()

source("plot.swe.post_mar_LBsite.R")
pdf(file = "Output/Output4/SWE2012bLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012b.out4)
dev.off()

source("plot.swe.post_mar.R")
pdf(file = "Output/Output5/SWE2012bBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012b.out5)
dev.off()

pdf(file = "Output/Output6/SWE2012bDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012b.out6)
dev.off()

pdf(file = "Output/Output7/SWE2012bMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012b.out7)
dev.off()

pdf(file = "Output/Output8/SWE2012bFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012b.out8)
dev.off()

pdf(file = "Output/Output9/SWE2012bTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012b.out9)
dev.off()

pdf(file = "Output/Output10/SWE2012bPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012b.out10)
dev.off()

## 24.2 Plots for Forecasting After Day 190

source("plot.swe.post_apr.R")
pdf(file = "Output/Output1/SWE2012cTGswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012c.out1)
dev.off()

pdf(file = "Output/Output2/SWE2012cBLPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012c.out2)
dev.off()

pdf(file = "Output/Output3/SWE2012cHRswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012c.out3)
dev.off()

source("plot.swe.post_apr_LBsite.R")
pdf(file = "Output/Output4/SWE2012cLBswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012c.out4)
dev.off()

source("plot.swe.post_apr.R")
pdf(file = "Output/Output5/SWE2012cBLswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012c.out5)
dev.off()

pdf(file = "Output/Output6/SWE2012cDBPswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012c.out6)
dev.off()

pdf(file = "Output/Output7/SWE2012cMCswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012c.out7)
dev.off()

pdf(file = "Output/Output8/SWE2012cFARMswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012c.out8)
dev.off()

pdf(file = "Output_paper/Output9/SWE2012cTDswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012c.out9)
dev.off()

pdf(file = "Output/Output10/SWE2012cPSswe.pdf", width = 12, height = 9, pointsize = 12, bg = "white")
plot.swe.post(tmp2012c.out10)
dev.off()


## 25. Computing and Barplots of Ranked Probability Skill Scores (RPSS) for the 2008, 2009, 2010, 
##     and 2011 Water-Years (Figure 11 In Article)

print("Starting Step 25: Computing and Barplots of Ranked Probability Skill Scores (RPSS) 
       for the 2008, 2009, 2010, and 2011 Water-Years")
flush.console()

T <- 30
dat<- vector("list", n.sites)
dat[[1]] <- tmp2008.out1
dat[[2]] <- tmp2008.out2
dat[[3]] <- tmp2008.out3
dat[[4]] <- tmp2008.out4
dat[[5]] <- tmp2008.out5
dat[[6]] <- tmp2008.out6
dat[[7]] <- tmp2008.out7
dat[[8]] <- tmp2008.out8
dat[[9]] <- tmp2008.out9
dat[[10]] <- tmp2008.out10

m <- 365
n.sites <- 10
n.mcmc <- 5000
n.burn <- round(n.mcmc/4)
 
rpss.ver <- matrix(NA, n.sites)
colnames(rpss.ver) <- c("RPSS-Value")
rownames(rpss.ver) <- c("TG", "BLP", "HR", "LB", "BL", "DBP", "MC", "FAR", "TD", "PS")
q1 <- 0.25
q2 <- 0.75
cat <- 3

for (k in 1:n.sites){
	a <- matrix(apply(dat[[1]]$Y.pred[, n.burn:dat[[1]]$n.mcmc], 1, mean))
	nr <- nrow(a)
	b <- matrix(0, nr)
	d <- as.numeric(quantile(a,  probs = c(q1, q2)))

		for(i in 1:nr){
			if(a[i, ] <= d[1]){
     				b[i, ] = 1}
			else{
   				if(a[i, ] > d[1] & a[i, ] <= d[2]){
     				b[i, ] = 2
     				}
			else{
     			b[i, ] = 3
    	        }
   	         }
	      }

  prob <- matrix(NA, cat)
  for(i in 1:cat){
  prob[i, ] = round(length(which(b==i))/nr, cat)
  }
  pred <- matrix(rep(prob, nr), nr, byrow = TRUE)

  data <- matrix(dat[[k]]$Y[T, ])
  obs <- matrix(0, nr)
  for(i in 1:nr){
    if(data[i, ] <= d[1]){
        obs[i, ] = 1}
    else{
       if(data[i, ] > d[1] & data[i, ] <= d[2]){
       obs[i, ] = 2
         }
     else{
       obs[i, ] = 3
           }
        }
      }
 ver <- rps(obs = c(obs), pred = pred, baseline = c(0.33, 0.42, 0.25))
 rpss.ver[k, ] = round(ver$rpss, 4)
}
rpss2008 <- rpss.ver



T <- 31
dat<- vector("list", n.sites)
dat[[1]] <- tmp2009.out1
dat[[2]] <- tmp2009.out2
dat[[3]] <- tmp2009.out3
dat[[4]] <- tmp2009.out4
dat[[5]] <- tmp2009.out5
dat[[6]] <- tmp2009.out6
dat[[7]] <- tmp2009.out7
dat[[8]] <- tmp2009.out8
dat[[9]] <- tmp2009.out9
dat[[10]] <- tmp2009.out10

m <- 365
n.sites <- 10
n.mcmc <- 5000
n.burn <- round(n.mcmc/4)
 
rpss.ver <- matrix(NA, n.sites)
colnames(rpss.ver) <- c("RPSS-Value")
rownames(rpss.ver) <- c("TG", "BLP", "HR", "LB", "BL", "DBP", "MC", "FAR", "TD", "PS")
q1 <- 0.25
q2 <- 0.75
cat <- 3

for (k in 1:n.sites){
	a <- matrix(apply(dat[[1]]$Y.pred[, n.burn:dat[[1]]$n.mcmc], 1, mean))
	nr <- nrow(a)
	b <- matrix(0, nr)
	d <- as.numeric(quantile(a,  probs = c(q1, q2)))

		for(i in 1:nr){
			if(a[i, ] <= d[1]){
     				b[i, ] = 1}
			else{
   				if(a[i, ] > d[1] & a[i, ] <= d[2]){
     				b[i, ] = 2
     				}
			else{
     			b[i, ] = 3
    	        }
   	         }
	      }

  prob <- matrix(NA, cat)
  for(i in 1:cat){
  prob[i, ] = round(length(which(b==i))/nr, cat)
  }
  pred <- matrix(rep(prob, nr), nr, byrow = TRUE)

  data <- matrix(dat[[k]]$Y[T, ])
  obs <- matrix(0, nr)
  for(i in 1:nr){
    if(data[i, ] <= d[1]){
        obs[i, ] = 1}
    else{
       if(data[i, ] > d[1] & data[i, ] <= d[2]){
       obs[i, ] = 2
         }
     else{
       obs[i, ] = 3
           }
        }
      }
 ver <- rps(obs = c(obs), pred = pred, baseline = c(0.30, 0.45, 0.25))
 rpss.ver[k, ] = round(ver$rpss, 4)
}
rpss2009 <- rpss.ver


T <- 32
dat<- vector("list", n.sites)
dat[[1]] <- tmp2010.out1
dat[[2]] <- tmp2010.out2
dat[[3]] <- tmp2010.out3
dat[[4]] <- tmp2010.out4
dat[[5]] <- tmp2010.out5
dat[[6]] <- tmp2010.out6
dat[[7]] <- tmp2010.out7
dat[[8]] <- tmp2010.out8
dat[[9]] <- tmp2010.out9
dat[[10]] <- tmp2010.out10

m <- 365
n.sites <- 10
n.mcmc <- 5000
n.burn <- round(n.mcmc/4)
 
rpss.ver <- matrix(NA, n.sites)
colnames(rpss.ver) <- c("RPSS-Value")
rownames(rpss.ver) <- c("TG", "BLP", "HR", "LB", "BL", "DBP", "MC", "FAR", "TD", "PS")
q1 <- 0.25
q2 <- 0.75
cat <- 3

for (k in 1:n.sites){
	a <- matrix(apply(dat[[1]]$Y.pred[, n.burn:dat[[1]]$n.mcmc], 1, mean))
	nr <- nrow(a)
	b <- matrix(0, nr)
	d <- as.numeric(quantile(a,  probs = c(q1, q2)))

		for(i in 1:nr){
			if(a[i, ] <= d[1]){
     				b[i, ] = 1}
			else{
   				if(a[i, ] > d[1] & a[i, ] <= d[2]){
     				b[i, ] = 2
     				}
			else{
     			b[i, ] = 3
    	        }
   	         }
	      }

  prob <- matrix(NA, cat)
  for(i in 1:cat){
  prob[i, ] = round(length(which(b==i))/nr, cat)
  }
  pred <- matrix(rep(prob, nr), nr, byrow = TRUE)

  data <- matrix(dat[[k]]$Y[T, ])
  obs <- matrix(0, nr)
  for(i in 1:nr){
    if(data[i, ] <= d[1]){
        obs[i, ] = 1}
    else{
       if(data[i, ] > d[1] & data[i, ] <= d[2]){
       obs[i, ] = 2
         }
     else{
       obs[i, ] = 3
           }
        }
      }
 ver <- rps(obs = c(obs), pred = pred, baseline = c(0.25, 0.50, 0.25))
 rpss.ver[k, ] = round(ver$rpss, 4)
}
rpss2010 <- rpss.ver


T <- 33
dat<- vector("list", n.sites)
dat[[1]] <- tmp2011.out1
dat[[2]] <- tmp2011.out2
dat[[3]] <- tmp2011.out3
dat[[4]] <- tmp2011.out4
dat[[5]] <- tmp2011.out5
dat[[6]] <- tmp2011.out6
dat[[7]] <- tmp2011.out7
dat[[8]] <- tmp2011.out8
dat[[9]] <- tmp2011.out9
dat[[10]] <- tmp2011.out10

m <- 365
n.sites <- 10
n.mcmc <- 5000
n.burn <- round(n.mcmc/4)
 
rpss.ver <- matrix(NA, n.sites)
colnames(rpss.ver) <- c("RPSS-Value")
rownames(rpss.ver) <- c("TG", "BLP", "HR", "LB", "BL", "DBP", "MC", "FAR", "TD", "PS")
q1 <- 0.25
q2 <- 0.75
cat <- 3

for (k in 1:n.sites){
	a <- matrix(apply(dat[[1]]$Y.pred[, n.burn:dat[[1]]$n.mcmc], 1, mean))
	nr <- nrow(a)
	b <- matrix(0, nr)
	d <- as.numeric(quantile(a,  probs = c(q1, q2)))

		for(i in 1:nr){
			if(a[i, ] <= d[1]){
     				b[i, ] = 1}
			else{
   				if(a[i, ] > d[1] & a[i, ] <= d[2]){
     				b[i, ] = 2
     				}
			else{
     			b[i, ] = 3
    	        }
   	         }
	      }

  prob <- matrix(NA, cat)
  for(i in 1:cat){
  prob[i, ] = round(length(which(b==i))/nr, cat)
  }
  pred <- matrix(rep(prob, nr), nr, byrow = TRUE)

  data <- matrix(dat[[k]]$Y[T, ])
  obs <- matrix(0, nr)
  for(i in 1:nr){
    if(data[i, ] <= d[1]){
        obs[i, ] = 1}
    else{
       if(data[i, ] > d[1] & data[i, ] <= d[2]){
       obs[i, ] = 2
         }
     else{
       obs[i, ] = 3
           }
        }
      }
 ver <- rps(obs = c(obs), pred = pred, baseline = c(0.27, 0.48, 0.25))
 rpss.ver[k, ] = round(ver$rpss, 4)
}
rpss2011 <- rpss.ver


pdf(file = "Output/RPSS-Barplots(Fig_11).pdf", width = 18, height = 14, pointsize = 12, bg = "white")

layout (matrix(1:4, 2, 2))

par(mar=c(1.5, 4.5, 2, 0.1))
barplot(t(rpss2008), space = .25, col = 1, ylim = c(-0.00135, 0.0148), lwd = 2.3, cex.axis = 2, 
         cex.lab = 2, cex.names = 2, ylab = "RPSS", axisnames = FALSE)
abline(h=0, lwd = 2)
axis(1, at=c(0.75, 1.95, 3.2, 4.45, 5.72, 7, 8.2, 9.46, 10.74, 12),labels = FALSE, font = 2, lwd = 2)
box(lwd = 2)
text(x = 0.28, y = 0.0142, labels = "(a)", cex = 2.5, font = 2)
rect(xleft = -0.25, ybottom = 0.0136, xright = 0.8, ytop = 0.0151)

par(mar=c(3, 4.5, 0, 0.1))
barplot(t(rpss2009), space = .25, col = 1, ylim = c(-0.001, 0.024), lwd = 2.3, 
         cex.axis = 2, cex.lab = 2, cex.names = 2, ylab = "RPSS")
abline(h=0, lwd = 2)
axis(1, at=c(0.75, 1.95, 3.2, 4.45, 5.72, 7, 8.2, 9.46, 10.74, 12), labels = FALSE, font = 2, lwd = 2)
box(lwd = 2)
text(x = 0.28, y = 0.023, labels = "(b)", cex = 2.5, font = 2)
rect(xleft = -0.25, ybottom = 0.022, xright = 0.8, ytop = 0.024)

par(mar=c(1.5, 4, 2, 1))
barplot(t(rpss2010), space = .25, col = 1, ylim = c(-0.00021, 0.0045), lwd = 2.3, 
         cex.axis = 2, cex.lab = 2, cex.names = 2, ylab = "", axisnames = FALSE)
abline(h=0, lwd = 2)
axis(1, at=c(0.75, 1.95, 3.2, 4.45, 5.72, 7, 8.2, 9.46, 10.74, 12), labels = FALSE, font = 2, lwd = 2)
box(lwd = 2)
text(x = 0.28, y = 0.00432, labels = "(c)", cex = 2.5, font = 2)
rect(xleft = -0.25, ybottom = 0.00415, xright = 0.8, ytop = 0.0055)

par(mar=c(3, 4, 0, 1))
barplot(t(rpss2011), space = .25, col = 1, ylim = c(-0.0026, 0.0003), lwd = 2.3, 
         cex.axis = 2, cex.lab = 2, cex.names = 2, ylab = "")
abline(h=0, lwd = 2)
axis(1, at=c(0.75, 1.95, 3.2, 4.45, 5.72, 7, 8.2, 9.46, 10.74, 12), labels = FALSE, font = 2, lwd = 2)
box(lwd = 2)
text(x = 0.28, y = 0.00018, labels = "(d)", cex = 2.5, font = 2)
rect(xleft = -0.25, ybottom = 0.000073, xright = 0.8, ytop = 0.00035)

dev.off()


print("Done: All 25 Steps are Completed")
flush.console()



