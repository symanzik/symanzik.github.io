plot.swe.post <- function(dat, date = NULL, head = NULL){

#  
# Uses output from swe.svd.mcmc.R
#

####
####  Setup Variables 
####

n.burn <- round(dat$n.mcmc/4)
T <- dim(dat$Y)[1]
m <- dim(dat$Y)[2]
modays <- c(31, 30, 31, 31, 28, 31, 30, 31, 30, 31, 31, 30)
mos <- cumsum(modays)
#y.max <- max(dat$Y, na.rm = TRUE)
y.max <- 75


####
####  Get Prediction 50% and 95% Credible Intervals 
####

CI.95 <- apply(dat$Y.pred[, n.burn:dat$n.mcmc], 1, quantile, c(0.025, 0.975))
CI.95 <- c(CI.95[1, ], rev(CI.95[2, ]))
CI.50 <- apply(dat$Y.pred[, n.burn:dat$n.mcmc], 1, quantile, c(0.25, 0.75))
CI.50 <- c(CI.50[1, ],rev(CI.50[2, ]))


####
####  Plot The Graphics
####

matplot((dat$Y.pred[, sample(n.burn:dat$n.mcmc, 20)]),
        type    = "n",
        col     = 3,
        lty     = 1,
        ylab    = "SWE",
        ylim    = c(0,y.max),
        xlab    = "Day (in water-year)", 
        cex.lab = 1.65, 
        main    = paste(head),
        cex.main = 2.4, 
        axes    = FALSE)

axis(1, c(0, 100, 200, 300, 365), 
    c("Oct. 1", "Jan. 8", "Apr. 18", "Jul. 27", "Sep. 30"), 
    cex.axis = 1.7)
        
axis(2, cex.axis = 1.7)
box()

abline(v = c(0, mos), col = 8)
abline(v = 100, col = "brown", lty = 4, lwd = 4)
text(mos - 15, rep(y.max, 12), labels = c(10:12, 1:9))

matplot(t(apply(dat$Y[-T, ], 2, quantile, c(0.001,0.999))), 
        type = "l", 
        lty  = 2, 
        col  = 1, 
        lwd  = 6, 
        add  = TRUE)

polygon(c(1:m, m:1), CI.95, col = gray(.5), border = NA)
polygon(c(1:m, m:1), CI.50, col=gray(.25), border = NA)

lines(apply(dat$Y[-T, ], 2, mean), col = 4, lwd = 7)
lines(dat$Y[T, ], lwd = 7, col = 2)

legend("right", 
      col    = c(1, gray(0.25), gray(0.5), 4, 2, 8), lty = c(2, 1, 1, 1, 1, 1), cex = 1.8, 
      lwd    = c(6, 8, 8, 6, 6, 2),
      legend = c("prev. data env.","pred. CI: 50%","pred. CI: 95%","prev. data mean",
                 "current data","months"), bg = "white")
}
