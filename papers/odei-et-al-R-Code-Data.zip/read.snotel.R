read.snotel <- function(f = NULL, nskip = 1){
#  
#  Reads in snotel data downloaded from snotel website one year at a time and output vector of values
#  with NAs in place of blanks and '---'.
#

skip <- 7 + 43 * (nskip-1)
if(!is.null(f)){
  swe.vec <- as.real(as.matrix(read.fwf(f, skip = skip, widths = c(4, rep(6, 12)),
             na.strings = c("---", "     "))[1:31, -1]))
}
swe.vec
}
