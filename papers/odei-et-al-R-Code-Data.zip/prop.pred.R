prop.pred <- function(tmpswe, n = 10, outdat = 100, ncol = 6){
#
#   Uses output from swe.svd.mcmc.R
#
#   n is the number of selected sites
#

####
####  Setup Variables 
####

prop.mat <- matrix(NA, n, ncol)
colnames(prop.mat) <- c("50%CL.LL", "50%CL.UL", "50%CL.LLUL", 
                        "95%CL.LL", "95%CL.UL", "95%CL.LLUL")
rownames(prop.mat) <- c("TGswe", "BLPswe", "HRswe", "LBswe", "BLswe",
                        "DBPswe", "MCswe", "FARMswe", "TDswe", "PSswe")

####
####  Get Prediction Credible Intervals and Proportion of SWE measurements Outsite these Intervals
####

 for(i in 1:n){

  n.burn <- round(tmpswe[[i]]$n.mcmc/4)
  T <- dim(tmpswe[[i]]$Y)[1]
  m <- dim(tmpswe[[i]]$Y)[2]

  CI.50 <- apply(tmpswe[[i]]$Y.pred[, n.burn:tmpswe[[i]]$n.mcmc], 1, quantile,c(0.25, 0.75))
  CI.95 <- apply(tmpswe[[i]]$Y.pred[, n.burn:tmpswe[[i]]$n.mcmc], 1, quantile,c(0.025, 0.975))

  nc <- c(1:ncol)
  prop.mat[i, nc[1]] <- 100 * sum(tmpswe[[i]]$Y[T, (outdat + 1):m] < 
                        CI.50[1, (outdat + 1):m])/(m - outdat)
  prop.mat[i, nc[2]] <- 100 * sum(tmpswe[[i]]$Y[T, (outdat + 1):m] > 
                        CI.50[2, (outdat + 1):m])/(m - outdat)
  prop.mat[i, nc[3]] <- 100 * sum((tmpswe[[i]]$Y[T, (outdat + 1):m] < 
                        CI.50[1, (outdat + 1):m]), (tmpswe[[i]]$Y[T, (outdat + 1):m] > 
                        CI.50[2, (outdat + 1):m]))/(m - outdat)
  prop.mat[i, nc[4]] <- 100 * sum(tmpswe[[i]]$Y[T, (outdat + 1):m] < 
                        CI.95[1, (outdat + 1):m])/(m - outdat)
  prop.mat[i, nc[5]] <- 100 * sum(tmpswe[[i]]$Y[T, (outdat + 1):m] > 
                        CI.95[2, (outdat + 1):m])/(m - outdat)
  prop.mat[i, nc[6]] <- 100 * sum((tmpswe[[i]]$Y[T, (outdat + 1):m] < 
                        CI.95[1, (outdat + 1):m]),(tmpswe[[i]]$Y[T, (outdat + 1):m] > 
                        CI.95[2, (outdat + 1):m]))/(m - outdat)
 }
cat("\n")
list(prop.mat = prop.mat)
}
