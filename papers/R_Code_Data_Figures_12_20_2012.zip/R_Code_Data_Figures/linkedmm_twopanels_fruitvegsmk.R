# Linked micromap plots (two statistical panels)
# By         Daniel B. Carr (revised for current data by Nathan Voge)
#             
#
#            1 Import functions and data
#            2 Sort data and extract abbreviations
#            3 Colors and Graphics Device
#            4 Define panel layouts 
#
#            5 Define graphics parameters
#            6 Set up for processing in loops
#            7 Draw maps
#            8 Draw linking dots and state names
#
#            9 Draw estimates and confidence bounds
#           10 Draw counts
#           11 Draw title and legend
#           12 Outline groups of panels



# 1. Import needed functions and data_______________________________________

# read in data
fvsmk = read.csv("Data/fvsmk_DC.csv", row.names = 1, header = TRUE)  # row.names = 1 makes row numbers go away
                                                          
load("Data/panelLayout.Rdata")  # workspace that has all the panel layout functions

# read in polygon shapes for map 
stateVBorders = read.csv("Data/stateVisibilityBorders.txt", row.names = NULL, 
                         header = TRUE)  # "st" = state IDs, "x" and "y" are 
                                         # polygon coordinates   
nationVBorders = read.csv("Data/nationVisibilityBorders.txt", 
                          blank.lines.skip = FALSE, row.names = NULL, 
                          header = TRUE)

# get Fips codes which are numbers the government uses to identify states 
stateNamesFips = read.csv("Data/stateNamesFips.txt", row.names = 1, header = TRUE)

# save it as a .pdf (looks better)
pdf("fvsmk_22Jul_map.pdf", width = 7.5, height = 10)



# 2. Sort the data.frame by fruit and veg consumption (high to low) and
#    extract the state abbreviations for later use____________________________


ord = rev(order(fvsmk$Fruit_Vegs))
fvsmk = fvsmk[ord, ]
stateDataId = row.names(fvsmk)
  


# 3. Start Graphics Device and Define Colors____________________________________


#windows(width = 7.5, height = 10)

wgray = rgb(.82, .82, .82)  #white gray

rgbColors = matrix(c(
 1.00, .30, .30,
 1.00, .50, .00,
  .25,1.00, .25,
  .10, .65, 1.00,
  .80, .45, 1.00,
  .35, .35, .35,
  .85, .85, .85,
  .50, .50, .50,
 1.00, 1.00, .85,
  .85, .85, .85), ncol = 3, byrow = TRUE)
 hdColors = rgb(rgbColors[, 1], rgbColors[, 2], rgbColors[, 3])

               
               
# 4. Define panel layouts______________________________________________________


bot = .77
top = .73
left = 0
right = 0
panels = panelLayout(nrow = 11, ncol = 4,
	       topMar = top, bottomMar = bot,
	       leftMar = left, rightMar = right,
          rowSep = c(0, 0, 0, 0, 0, .07, .07, 0, 0, 0, 0, 0),
          rowSize = c(7, 7, 7, 7, 7, 1.5, 7, 7, 7, 7, 7),
          colSize = c(2.5, 2.2, 2.90, 2.90),
          colSep = c(0, 0, 0, 0, 0))

panelBlock = panelLayout(nrow = 3, ncol = 3,
 	       topMar = top, bottomMar = bot,
	       leftMar = left, rightMar = right,
             rowSep = c(0, .07, .07, 0),
             rowSize = c(35, 1.5, 35),
             colSize = c(4.7, 2.90, 2.90),
             colSep = c(0, 0, 0, 0))
 


# 5. Define graphics parameters_______________________________________________


dcex = .95
tCex = 1.08
cex = .65
fontsize = 12
font = 1
line1 = .2
line2 = 1.0
line3 = .2
ypad = .65
nameShift = .12



# 6. Set up indices for perceptual groups of states___________________________


iBegin = c(1, 6, 11, 16, 21, 26, 27, 32, 37, 42, 47)  # group beg subscript
iEnd   = c(5, 10, 15, 20, 25, 26, 31, 36, 41, 46, 51)  # group ending subscript
nGroups = length(iEnd)



# 7. Plot maps________________________________________________________________


# range for scale the polygon panels
rxpoly = range(stateVBorders$x, na.rm = TRUE)
rypoly = range(stateVBorders$y, na.rm = TRUE)

# polygon IDs, one per polygon 
polygonId = stateVBorders$st[is.na(stateVBorders$x)]

# panel titles
panelSelect(panels, 1, 1)
panelScale()
mtext(side = 3, line = line1, "Above Median States", cex = cex)
mtext(side = 3, line = line2, "Micromaps", cex = cex)

panelSelect(panels, 11, 1)
panelScale()
mtext(side = 1, line = line3, "Below Median States", cex = cex)

# drawing the maps
for (i in 1:nGroups) {
 if (i == 6) {    #map not drawn, median state in adjacent panels
   panelSelect(panels, 6, 1)
   panelScale()
   panelFill(col = wgray)
   panelOutline(col = "black")
   text(.5, .55, "Median", cex = cex)
   next  #  "next" halts the processing of the current iteration and advances 
         # the looping index.
 }
 panelSelect(panels, i, 1)
 panelScale(rxpoly, rypoly)
 gsubs = iBegin[i]:iEnd[i]
 if (i == 5) 
   gsubs = c(gsubs, 26)   # median state added here
 if (i == 7) 
   gsubs = c(gsubs, 26)   # median state added here
 if (i < 6) 
   cont = stateDataId[1:26] 
 else 
   cont = stateDataId[26:51]
          # cont means above or below median contour
 panelNames = stateDataId[gsubs]

# plot background (out of contour) states in gray with white outlines 
 back = is.na(match(stateVBorders$st, cont))
 polygon(stateVBorders$x[back], stateVBorders$y[back], col = wgray, 
         border = FALSE)  
 polygon(stateVBorders$x[back], stateVBorders$y[back], col = "white",
         density = 0) 
                                                               # outline states
                                                               
# plot foreground states for the panel in their special colors pens 1:5
# and other in contour states in light yellow pen 9
 fore = !back
 pen = match(polygonId, panelNames, nomatch = 9)[!is.na(match(polygonId, cont))]
 polygon(stateVBorders$x[fore], stateVBorders$y[fore], col = hdColors[pen], 
         border = FALSE) # outline states
 polygon(stateVBorders$x[fore], stateVBorders$y[fore], col = "black", 
         density = 0, lwd = 1) # outline states

# outline U.S.
 polygon(nationVBorders$x, nationVBorders$y, col = "black", density = 0, 
         lwd = 1) 
                                                        # outside boundary
}

   
      
# 8. Plot labels_______________________________________________________________


# get full state names in rate order
ord = match(stateDataId, stateNamesFips$ab)  # match state names  
stateNames = row.names(stateNamesFips)[ord]  # get the full state names except 
                                             # D.C.
cbind(stateDataId, stateNames)               # check that the matching has 
                                             # worked
# title column
panelSelect(panels, 1, 2)
panelScale()
mtext(side = 3, line = line1, "", cex = cex)
mtext(side = 3, line = line2, "States", cex = cex)

# draw state names
for (i in 1:nGroups) {
   gsubs = iBegin[i]:iEnd[i]
   gnams = stateNames[gsubs]
   nsubs = length(gnams)
   pen = 1:nsubs
   laby = nsubs:1
   panelSelect(panels, i, 2)
   panelScale(c(0, 1), c(1-ypad, nsubs + ypad))
   
   if (i == 6) {
     pen = 6
     panelFill(col = wgray)
     panelOutline()
   }  
   
   for (j in 1:length(pen)) {
      points(.1,laby[j], pch = 16, col = hdColors[pen[j]], cex = dcex)
      points(.1,laby[j], pch = 1, col = "black", cex = dcex)	
      text(.18, laby[j] + nameShift, gnams[j], cex = cex ,adj = 0, 
           col = "black", font = font)
   }
}



# 9. Plot rates with confidence bounds_________________________________________


countRange1 = range(fvsmk$Fruit_Vegs)
countRange1 = mean(countRange1) + 1.10 * diff(countRange1) * c(-.5, .5)
countGrid1 = panelInbounds(countRange1) # used pretty values that are in bounds

panelSelect(panels, 1, 3)
panelScale()
mtext(side = 3, line = line1, "(at least 5 times a day)", cex = cex)
mtext(side = 3, line = line2, "Fruit and Vegs Consumption", cex = cex)

for (i in 1:nGroups) {
   gsubs = iBegin[i]:iEnd[i]
   nsubs = length(gsubs)
   pen = 1:nsubs
   laby = nsubs:1
   panelSelect(panels, i, 3)
   panelScale(countRange1, c(1-ypad, nsubs + ypad))
   panelFill(col = wgray)
   panelGrid(x = countGrid1, col = "white", lwd = 1)
   panelGrid(x = 5.6, col = "black", lty = 2)  # hard code U.S. average
   panelOutline(col = "white")

   if (i == nGroups) {
     axis(side = 1, at = countGrid1, labels = as.character(countGrid1),
          col = "black", mgp = c(1, 0, 0), tck = -.04, cex.axis = cex)
	   mtext(side = 1, line = .7, "Percent", cex = cex)
   }
   
   if (i == 6) 
     pen = 6
     
   lines(fvsmk$Fruit_Vegs[gsubs], laby, col = "black", lwd = 1)
   
   for (j in 1:length(pen)) {
       points(fvsmk$Fruit_Vegs[gsubs[j]], laby[j], pch = 16,
              cex = dcex, col = hdColors[pen[j]])
       points(fvsmk$Fruit_Vegs[gsubs[j]], laby[j], pch = 1,
              cex = dcex, col = "black")
   } 
}



# 10. Plot counts____________________________________________________________


countRange = range(fvsmk$Smoke)
countRange = mean(countRange) + 1.10 * diff(countRange) * c(-.5, .5)
countGrid = panelInbounds(countRange) # used pretty values that are in bounds

panelSelect(panels, 1, 4)
panelScale()
mtext(side = 3, line = line1, "Smoking", cex = cex)
mtext(side = 3, line = line2, "Daily", cex = cex)

for (i in 1:nGroups) {
   gsubs = iBegin[i]:iEnd[i]
   nsubs = length(gsubs)
   pen = 1:nsubs
   laby = nsubs:1
   panelSelect(panels, i, 4)
   panelScale(countRange, c(1 - ypad, nsubs + ypad))
   panelFill(col = wgray)
   panelGrid(x = countGrid, col = "white")
   panelOutline(col = "white")
   
   if (i == nGroups) {
     axis(side = 1, at = countGrid, labels = as.character(countGrid),
          col = "black", mgp = c(1, 0, 0), tck = -.04, cex.axis = cex)
	   mtext(side = 1, line = .7, "Percent", cex = cex)
   }
   
   if(i == 6)
     pen = 6
     
   lines(fvsmk$Smoke[gsubs], laby, col = "black", lwd = 1)
   
   for (j in 1:length(pen)) {
       points(fvsmk$Smoke[gsubs[j]], laby[j], pch = 16,
              cex = dcex, col = hdColors[pen[j]])
       points(fvsmk$Smoke[gsubs[j]], laby[j], pch = 1,
              cex = dcex, col = "black")
   } 
}



# 11  Add Title and Legend _____________________________________________________


panelSelect(panels, margin = "top")
panelScale()
text(.5, .85, "Fruit and Vegetable Consumption and Smoking Statistics By State",
     cex = 1)

panelSelect(panels, margin = "bottom")
panelScale(inches = TRUE)
xs = 2.8
ys = -.42
# text(.01 + xs, .70 + ys, "U.S. Average", cex = cex, adj = 0, font = 1)
# lines(c(.78, 1.50) + xs, c(.70, .70) + ys, lty = 2, col = "black")
# text(.01 + xs, .53 + ys, "90% Confidence Interval", cex = cex, adj = 0, 
#      font = 1)
# lines(c(1.35, 1.61) + xs, c(.53, .53) + ys, lwd = 2, col = hdColors[1])



# 12. Outline groups of Panels__________________________________________________


for (i in 1:3) {
  for (j in 2:3) {
    panelSelect(panelBlock, i, j)
    panelScale()
    panelOutline(col = "black")
  }
}

panelSelect(panelBlock, 2, 1)
panelScale()
panelOutline(col = "black")

dev.off()


