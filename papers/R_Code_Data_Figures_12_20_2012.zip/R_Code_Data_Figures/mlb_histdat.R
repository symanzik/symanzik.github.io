# MLB Histogram
# By         Nathan Voge
#             
#
#            1 Import functions and data
#            2 Draw plots, define colors, create breaks


# 1. Import needed functions and data_______________________________________

library(RColorBrewer)
library(RgoogleMaps)
library(PBSmapping)

value = c(305, 405, 359, 617, 448, 315, 274, 352, 298, 292, 226, 416, 239, 368, 482, 235, 216,
          604, 1026, 234, 424, 250, 354, 410, 428, 429, 209, 353, 286, 440)
          
revenue = c(145, 172, 156, 206, 179, 157, 137, 150, 145, 146, 119, 173, 117, 167, 189, 131, 114,
            195, 277, 134, 176, 125, 158, 171, 179, 165, 116, 153, 136, 145) 

mlb = data.frame(value, revenue)

# read in data via a file, data = read.csv("Data/mlb_coordchg.csv", header = TRUE)


# 2. Draw plots, define colors, create breaks__________________________________

# save it as a .pdf 
pdf("mlb_18Jul_valhist.pdf", width = 11, paper = "USr")

                                     
value.breaks5 = c(200, 400, 600, 800, 1000, 1200)
pallette5 = brewer.pal(5, "OrRd")  # define colors 
hist(mlb$value, xlim = c(200, 1200), ylim = c(0, 20), xlab = "Value ($mil)", 
     main = "", col = pallette5, breaks = value.breaks5)
     
dev.off()     

# save it as a .pdf 
pdf("mlb_18Jul_revhist.pdf", width = 11, paper = "USr")     
     
revenue.breaks5 = seq(100, 300, 40)
hist(mlb$revenue, main = "", col = pallette5, xlab = "Revenue ($mil)", 
     breaks = revenue.breaks5, ylim = c(0, 20), xlim = range(revenue.breaks5),
     xaxt = "n")  # xaxt = "n" turns off the numbering for the x-axis

# reformat the x-axis with tick marks that fit our breaks     
axis(1, at = revenue.breaks5, labels = c("100", "140", "180", "220", "260", "300"))   
                                         
dev.off()                                            

# Extra histograms 
#value.breaks2 = c(200, 350, 500, 650, 800, 950, 1100)
#pallette6 = brewer.pal(7, "OrRd") 
#hist(mlb$value, xlim = c(200, 1200), ylim = c(0, 15), xlab = "Value ($mil)", 
#     main = "", col = pallette6, breaks = value.breaks2)
#
#pallette7 = brewer.pal(9, "OrRd") 
#hist(mlb$value, xlim = c(200, 1200), ylim = c(0, 12), xlab = "Value ($mil)", 
#     main = "", col = pallette7)

##Revenue
#pallette9 = brewer.pal(9, "OrRd")
#hist(mlb$revenue, main = "", col = pallette9, xlab = "Revenue ($mil)", 
#     xlim = c(100, 300), ylim = c(0, 10))

