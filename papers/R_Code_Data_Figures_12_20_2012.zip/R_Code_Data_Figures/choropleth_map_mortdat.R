# United States Choropleth Map
# By         Juergen Symanzik (revised for current data by Nathan Voge)
#             
#
#            1 Import functions and data
#            2 Sort the data and assign colors
#            3 Draw map, plot data, make titles, and create a legend


# 1. Import needed functions and data_______________________________________

# load required packages
library(RColorBrewer)
library(maps)

# read in data

## Note, D.C was in our data set, but not on the map we are using
## so it is deleted from the data set

State = c("Mississippi", "Louisiana", "Michigan", "Indiana", "Georgia",
	    "West Virginia", "Texas", "Tennessee", "Ohio", "Alabama",	
          "Kentucky", "South Carolina", "Pennsylvania", "North Carolina",
          "Arkansas", "Missouri", "Oklahoma", "Illinois", "Kansas",	
          "Rhode Island", "Maine", "Florida", "New York", "Nebraska",	
          "Massachusetts", "New Jersey", "Delaware", "Iowa", "New Hampshire",
          "Colorado", "New Mexico", "Connecticut", "Maryland", "Wisconsin",	
          "Nevada", "Utah", "Minnesota", "Virginia", "Arizona", "Vermont",
          "Idaho", "California", "Alaska", "Washington", "South Dakota",
          "Wyoming", "Montana", "North Dakota", "Oregon", "Hawaii")	
          
Delinquency = c(10.6, 9.1, 7.9, 7.8, 7.5, 7.4, 7.4, 7.3, 7.3, 7.1, 6.3, 6.3, 6.3, 6.1, 6.1,
                6.1, 6.1, 5.4, 5.1, 5.0, 4.9, 4.9, 4.8, 4.7, 4.5, 4.5, 4.5, 4.4, 4.4, 4.4, 4.3,
                4.3, 4.3, 4.1, 4.1, 4.0, 4.0, 3.7, 3.5, 3.4, 3.4, 3.3, 3.1, 2.9, 2.9, 2.9, 2.8,
                2.7, 2.6, 2.4)          		

mort = cbind(State, Delinquency)

# read in data via a file, mort = read.csv("DelinqRate_edit.csv", header = TRUE)


# 2. Sort the data and assign colors__________________________________________

# set how to divide up the data
breaks = c(2, 5, 8, 11)

# apply the breaks to the data set
m.class = cut(as.numeric(mort[, 2]), breaks)

# pick colors and assign colors to breaks
m.col = brewer.pal(3, "Blues")[m.class]

# match states in map to states in the data set
## Note, states in the map are "characters, so we must make the 
## the states in our data set "characters" as well
map.m.col = m.col[match.map("state", as.character(mort[, 1]))]


# 3. Draw map, plot data, make titles, and create a legend____________________

# save map as a .pdf
pdf("Mortagages_18Jul_Map.pdf", width = 11, paper = "USr")

# create the map
map("state", fill = T, col = map.m.col)
legend("bottomright", legend = levels(m.class), fill = brewer.pal(3, "Blues"))

# optional title: title("Mortgage Delinquency Rates (%) in 2007")

dev.off()
