# University Tuition Scatterplot and Plot of Residuals
# By         Nathan Voge
#             
#
#            1 Import functions and data
#            2 Draw scatterplot
#            3 Plot residuals

# 1. Import needed functions and data_______________________________________

library(RColorBrewer)
library(RgoogleMaps)
library(PBSmapping)

University = c("Kansas", "Texas", "Arizona", "Ohio State", "Cal-Davis",
             "Cal-Santa Barbara", "Iowa State", "Minnesota", "UCLA", "Iowa",
             "Illinois", "Cal-San Diego", "Virginia", "Cal-Irvine", "Colorado",
             "Purdue", "Wisconsin", "North Carolina", "Penn State", "Pittsburgh",
             "Indiana", "Cal-Berkeley", "Nebraska", "Missouri", "Maryland",
             "Michigan State", "Washington", "Oregon", "Rutgers", "Michigan",
             "Florida", "Buffalo")

Year_2000 = c(2725, 3575, 2348, 4383, 4072, 3832, 3132, 4877, 3698, 3204, 4994, 3848, 4335,
             3970, 3188, 3872, 3791, 2768, 7018, 7002, 4405, 4047, 3450, 4726, 5136, 5432,
             3761, 3819, 6333, 6926, 2256, 4715)

Year_2005 = c(5413, 6972, 4498, 8082, 7457, 6997, 5634, 8622, 6504, 5612, 8634, 6685,
              7370, 6770, 5372, 6458, 6284, 4613, 11508, 11436, 7112, 6512, 5540, 7415,
              7821, 8108, 5610, 5613, 9221, 9798, 3094, 6068)

tuit = data.frame(University, Year_2000, Year_2005)

# read in data via a file, tuit = read.csv("tuition.csv", header = TRUE)


# 2. Draw scatterplot__________________________________________________________

# save it as a .pdf 
pdf("tuit_18Jul_hist.pdf", width = 7)
            
plot(tuit$Year_2000, tuit$Year_2005, main = "", xlab = "Tuition in Year 2000", 
     ylab = "Tuition in Year 2005")
     
dev.off()     
     
# Scatterplot with names
# plot(tuit[, 2], tuit[, 3], type = "n")
# text(tuit[, 2], tuit[, 3], tuit[, 1])


# 3. Plot residuals___________________________________________________________

glmdat = glm(tuit$Year_2005 ~ tuit$Year_2000)
glmresid = residuals(glmdat)
glmpred = predict(glmdat)

# save it as a .pdf 
pdf("tuit_22Jul_resid.pdf", width = 7)

plot(tuit$Year_2000, glmresid, type = "n", xlim = c(2000,7500), xlab = "Tuition in Year 2000",
 main = "", ylab = "Residuals", cex.lab = 1) 

# optional title: Residual plot of Tuition in Year 2000

text(tuit$Year_2000, glmresid, tuit[, 1], cex = .9)

dev.off()

