# Tornado Damage Histogram
# By         Nathan Voge
#             
#
#            1 Import functions and data
#            2 Draw plot


# 1. Import needed functions and data_______________________________________

State = c("Alabama", "Arizona", "Arkansas", "California", "Colorado", "Connecticut",
          "Delaware", "Florida", "Georgia", "Idaho", "Illinois", "Indiana", "Iowa",
          "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts",
          "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska",
          "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York",
          "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon",
          "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota",
          "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington",
          "West Virginia", "Wisconsin", "Wyoming")
          # Puerto Rico, Hawaii, and Alaska were eliminated
          
Cost = c(51.88, 3.469, 40.96, 3.682, 4.623, 2.26, 0.2744, 37.32, 51.68, 0.2552, 62.94,
         53.13, 49.51, 49.28, 24.84, 27.75, 0.5252, 2.329, 4.418, 29.88, 84.84, 43.62,
         68.93, 2.266, 30.26, 0.0953, 0.6592, 2.94, 1.485, 15.73, 14.9, 14.69, 44.36,
         81.94, 5.52, 17.11, 0.0898, 17.19, 10.64, 23.47, 88.6, 3.565, 0.2416, 7.416,
         2.374, 2.143, 31.33, 1.779)
        
torn = data.frame(State, Cost)

# read in data via a file, torn = read.csv("tornado_alpha.csv", header = TRUE)

  
# 2. Draw plot________________________________________________________________

# save as a .pdf
pdf("torn_18Jul_hist.pdf", width = 11, paper = "USr")

hist(torn$Cost, xlim = c(0, 100), ylim = c(0, 25), main = "", 
     xlab = "Cost (in millions)")
     
dev.off()   

  