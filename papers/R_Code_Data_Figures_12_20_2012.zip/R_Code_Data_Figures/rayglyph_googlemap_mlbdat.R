# Google Map Featuring Ray-Glyph Lines
# By         Nathan Voge (based on work by Daniel B. Carr (ray-glyphs) and
#                         Markus Loecher (RgoogleMaps))
#             
#
#            1 Import functions and data
#            2 Create a Google map
#            3 Add ray-glyph lines to the map
#            4 Add colored circles depicting percent increase to the map
#            5 Create percent increase legend    
#            6 Create ray-glyph legend
#            7 Plot title    

# 1. Import needed functions and data_________________________________________

# load in required packages
library(RColorBrewer)
library(RgoogleMaps)
library(PBSmapping)

# read in data
team = c("Arizona Diamondbacks", "Atlanta Braves", "Baltimore Orioles",
         "Boston Red Sox", "Chicago Cubs", "Chicago White Sox", "Cincinnati Reds",
         "Cleveland Indians", "Colorado Rockies", "Detroit Tigers",
         "Florida Marlins", "Houston Astros", "Kansas City Royals",
         "Los Angeles Angels", "Los Angeles Dodgers", "Milwaukee Brewers",
         "Minnesota Twins", "New York Mets", "New York Yankees",
         "Oakland Athletics", "Philadelphia Phillies", "Pittsburgh Pirates",
         "San Diego Padres", "San Francisco Giants", "Seattle Mariners",
         "St Louis Cardinals", "Tampa Bay Devil Rays", "Texas Rangers",
         "Toronto Blue Jays", "Washington Nationals")
         
value = c(305, 405, 359, 617, 448, 315, 274, 352, 298, 292, 226, 416, 239, 368, 482, 235, 216,
          604, 1026, 234, 424, 250, 354, 410, 428, 429, 209, 353, 286, 440)
          
revenue = c(145, 172, 156, 206, 179, 157, 137, 150, 145, 146, 119, 173, 117, 167, 189, 131, 114,
            195, 277, 134, 176, 125, 158, 171, 179, 165, 116, 153, 136, 145)          
         
lat = c(33.445278, 33.735278, 39.583889, 42.346389, 42, 42.53, 39.0975, 41.495833,
        39.756111, 42.339167, 25.778056, 29.756944, 39.051389, 35.00278, 34.073611,
        43.948333, 44.981667, 40.756944, 41.829167, 37.951667, 39.905833, 40.446944,
        32.7073, 37.778333, 47.591389, 38.6225, 27.768333, 32.751389, 43.641389,
        38.872778)
        
lon = c(-112.066944, -84.389444, -76.621667, -71.0975, -87.655556, -86.7, -84.506667,
        -81.685278, -104.994167, -83.048611, -80.219722, -95.355556, -94.480556,
        -119.32778, -119.24, -87.971111, -93.278333, -73.845833, -73.926389,
        -121.200556, -75.166389, -80.005833, -117.1566, -122.389444, -122.3325,
        -90.193056, -82.653333, -97.082778, -79.389167, -77.0075)
        
data = data.frame(team, value, revenue, lat, lon)

# read in data via a file, data = read.csv("mlb_coordchg.csv", header = TRUE)


# 2. Create a Google map______________________________________________________

# Define x and y coordinates on map. In all RgoogleMaps packages, the latitude
# is read first followed by the longitude. For our data set, we looked up the 
# latitude and longitude online for each university.
x = data["lat"]
y = data["lon"]

# Define the bounding box (bb) for the map using the latitude and longitude from 
# our data set.
bb = qbbox(x, y, TYPE = "all", margin = list(m = rep(5, 4), 
           TYPE = c("perc", "abs")[1]))

# Create a Google map by loading a static map from the package and define 
# some options. bb$lonR, bb$latR are our latitude and longitude from the 
# previous line of code. We have a few choices on the type of map we want to use 
# such as "roadmap", "satellite", "terrain", etc. The default is a color map, 
# here we want it to be gray so we use the "GRAYSCALE" argument. If needed, we 
# can also use the "zoom" argument. This zooms in/out around the area we 
# define by using the argument "center".  

# save it as a .pdf (looks better)
pdf("mlb_18Jul_map.pdf", width = 7, paper = "USr")

MyMap = GetMap.bbox(bb$lonR, bb$latR, maptype = "roadmap", GRAYSCALE = TRUE)

# This command plots the map in the graphics window in R
PlotOnStaticMap(MyMap)

## Note: Content is added to the static map by using "PlotOnStaticMap".  
# "PlotOnStaticMap" is repeated for each color/item added to the map. "FUN" 
# identifies the plotting function, usually points or lines. "pch" and "cex" 
# normal plotting parameters.


# 3. Add Ray-glyph lines to the map___________________________________________

# Function to Calculate the Latitude and Longitude for Ray-glyph Lines 
# It uses the two variables you want to compare (var1, var2), the latitude
# and longitude for these variables (lat, lon), and the minimum and maximum
# of the two variables (min1, max1, min2, max2) respectively. It returns the
# latitude and longitude of the point away from the origin for each variable.

CalcRayGlyphMapLatLon = function(var1, var2, lat, lon, min1, max1, min2, 
                                   max2) {
	num1 = var1 - min1
	ratio1 = num1 / (max1 - min1)
	angle1 = 270 - ratio1 * 180
	rad1 = angle1 * pi / 180
	lon1 = lon + 2 * cos(rad1)
	lat1 = lat + 2 * sin(rad1)
	
	num2 = var2 - min2
	ratio2 = num2 / (max2 - min2)
	angle2 = 270 + ratio2 * 180
	rad2 = angle2 * pi / 180
	lon2 = lon + 2 * cos(rad2)
	lat2 = lat + 2 * sin(rad2)

	list = c(lat1 = lat1, lon1 = lon1, lat2 = lat2, lon2 = lon2)		
 }

# Function to Plot Ray-glyph lines. 
# "variable" is the plotting parameter. "lncolor1" is the color of the left 
# line. "lncolor2" is the color of the right line. "cexln" is the cex of the 
# line. "lwdln" is the line width. "ltyln1" and "ltyln2" and the respective 
# line types.
 
PlotRayGlyphLines = function(data, variable, lncolor1, lncolor2, cexln = 1.5, 
                          lwdln = 2, ltyln1 = 1, ltyln2 = 1) {
 colselect = subset(data, select = variable)
 for (i in 1:nrow(colselect)) {
	loc = data[colselect[i, ], ] # select each location
	PlotOnStaticMap(MyMap, 
	  lat = c(as.numeric(loc[4]), 
            as.numeric(CalcRayGlyphMapLatLon(loc[2], loc[3], loc[4], loc[5], 
                       min(data[2]), max(data[2]), min(data[3]), 
                       max(data[3]))[1])), 
	  lon = c(as.numeric(loc[5]) - .1, 
            as.numeric(CalcRayGlyphMapLatLon(loc[2], loc[3], loc[4], loc[5], 
                       min(data[2]), max(data[2]), min(data[3]), 
                       max(data[3]))[2]) - .1),
	  FUN = lines, col = lncolor1, add = TRUE, pch = 1, cex = cexln, lwd = lwdln, 
    lty = ltyln1) #Line on left
 	PlotOnStaticMap(MyMap, 
    lat = c(as.numeric(loc[4]), 
            as.numeric(CalcRayGlyphMapLatLon(loc[2], loc[3], loc[4], loc[5], 
                       min(data[2]), max(data[2]), min(data[3]),                
                       max(data[3]))[3])), 
    lon = c(as.numeric(loc[5]) + .1, 
            as.numeric(CalcRayGlyphMapLatLon(loc[2], loc[3], loc[4], loc[5], 
                       min(data[2]), max(data[2]), min(data[3]), 
                       max(data[3]))[4]) + .1),
	  FUN = lines, col = lncolor2, add = TRUE, pch = 1, cex = cexln, lwd = lwdln, 
    lty = ltyln2) #Line on right
 }
}

# Define color scheme for ray-glyph lines
palgreen = brewer.pal(9, "Greens")
lncolor1 = palgreen[8]
lncolor2 = palgreen[5]

# Run PlotRayGlyphLines function and plot ray-glyph lines. Change plotting
# variable. ("team" here)
PlotRayGlyphLines(data = data, variable = "team", lncolor1, lncolor2)



# 4. Add colored circles depicting percent increase to the map________________

# Function to Plot Colored Circles Outlined in Black.
# Data*[,4] and data*[,5] contain the latitude and longitude for each 
# respective level (*), which are our breaks in the data. 
# After many tries, we found 4 levels most useful 
# for our data set. "subset" allows us to identify how we want to divide up the
# data with "Percent_Increase" being our variable of interest. 
# Here we put black circles around the colors to make them more visible. 
# "pch = 1" is a circle. "cexcir" is the cex of the circles. "pchdot" is the pch
# of the dot. "pchcir" is the pch of the circle

## Note:  The data in "Percent_Increase" was not provided by the original data
## set. 


 
PlotPoints = function(data, num.breaks, cexcir = 1.5, pchdot = 19, pchcir = 1) {
  for (i in 1:num.breaks) {
    if (i == 1) {#i=1; variable = "value"
	    data1 = subset(data, value >= 200 & value < 400)
	    PlotOnStaticMap(MyMap, data1[, 4], data1[, 5], FUN = points, 
	                   col = palcircle[i], add = TRUE, pch = pchdot, cex = cexcir)
	    PlotOnStaticMap(MyMap, data1[,4], data1[,5], FUN = points, col = "black", 
                      add = TRUE, pch = pchcir, cex = cexcir, lwd = 1)
	  }  
    else if (i == 2) {#i=2; variable = "value"
	    data2 = subset(data, value >= 400 & value < 600)
	    PlotOnStaticMap(MyMap, data2[,4], data2[,5], FUN = points, 
                     col = palcircle[i], add = TRUE, pch = pchdot, cex = cexcir)
	    PlotOnStaticMap(MyMap, data2[,4], data2[,5], FUN = points, col = "black", 
	                    add = TRUE, pch = pchcir, cex = cexcir, lwd = 1)
	  }
    else if (i == 3) {
     	data3 = subset(data, value >= 600 & value < 800)
	    PlotOnStaticMap(MyMap, data3[,4], data3[,5], FUN = points, 
	                   col = palcircle[i], add = TRUE, pch = pchdot, cex = cexcir)
	    PlotOnStaticMap(MyMap, data3[,4], data3[,5], FUN = points, col = "black",
	                    add = TRUE, pch = pchcir, cex = cexcir, lwd = 1)
	  }
    else if (i == 4) {
	    data4 = subset(data, value >= 800 & value < 1000)
	    PlotOnStaticMap(MyMap, data4[,4], data4[,5], FUN = points,
	                   col = palcircle[i], add = TRUE, pch = pchdot, cex = cexcir)
	    PlotOnStaticMap(MyMap, data4[,4], data4[,5], FUN = points,
	                   col = "black", add = TRUE, pch = pchcir, cex = cexcir, 
                     lwd = 1)
	  }
    else if (i == 5) {
	    data5 = subset(data, value >= 1000 & value < 1200)
	    PlotOnStaticMap(MyMap, data5[,4], data5[,5], FUN = points,
	                   col = palcircle[i], add = TRUE, pch = pchdot, cex = cexcir)
	    PlotOnStaticMap(MyMap, data5[,4], data5[,5], FUN = points,
	                   col = "black", add = TRUE, pch = pchcir, cex = cexcir, 
                     lwd = 1)
	  }
   }
}

# Run PlotPoints function and plot dots/circles. 

# Define color scheme for our circles. We used the website 
# http://colorbrewer2.org to identify an appropriate color scheme with 4 levels.
# variable = "value"
num.breaks = 5
palcircle = brewer.pal(5, "OrRd")
cexcir = 1.5
pchdot = 19
pchcir = 1


# Run colored circles function
PlotPoints(data, num.breaks, cexcir, pchdot, pchcir)

## Note: If data doesn't have a percent increase variable, use the below code 
## to plot the circles

# PlotOnStaticMap(MyMap, data[,4], data[,5], FUN = points,
#	                col = palcircle[4], add = TRUE, pch = pchdot, cex = cexcir)
# PlotOnStaticMap(MyMap, data[,4], data[,5], FUN = points,
#	            col = "black", add = TRUE, pch = pchcir, cex = cexcir, 
#                 lwd = 1)


# 5. Create percent increase legend___________________________________________ 

# The x and y coordinates of the legend box are based on 
# the latitude and longitude of the static map from Google. The 
# function "LatLon2XY.centered" transforms latitude and longitude into x and 
# y coordinates on the map. 
# LatLon2XY.centered(MyMap,MyMap$BBOX$ll[1],MyMap$BBOX$ll[2])$newX and 
# LatLon2XY.centered(MyMap,MyMap$BBOX$ll[1],MyMap$BBOX$ll[2])$newY give the 
# lower left-corner coordinates of the static map. We use a fraction of
# them (.995, .61 respectively) to shift the legend to its default location.

# Define computed coordinates used on map (not RgoogleMaps/MyMap)
xcoord.max = LatLon2XY.centered(MyMap,MyMap$BBOX$ll[1], MyMap$BBOX$ur[2])$newX
xcoord.min = LatLon2XY.centered(MyMap,MyMap$BBOX$ll[1], MyMap$BBOX$ll[2])$newX
ycoord.max = LatLon2XY.centered(MyMap,MyMap$BBOX$ur[1], MyMap$BBOX$ll[2])$newY
ycoord.min = LatLon2XY.centered(MyMap,MyMap$BBOX$ll[1], MyMap$BBOX$ll[2])$newY


# Legend for percent increase  
legend(xcoord.min * .995, ycoord.min * .57, 
       legend = c("[200, 400)", "[400, 600)", "[600, 800)", "[800, 1000)",
                  "[1000, 1200)"),
       fill = palcircle , title = "Value Distribution ($mil)", cex = .9, 
       bg = "grey")


## Note: To put the legend in the top left corner we need change the Y and use
## MyMap$BBOX$ur[1] as the new reference point that gives us the Y coordinate
## in the "upper right" corner. But we just want Y (the latitude). So
## MyMap$BBOX$ll[2] stays the same. We also change the Y proportion to .995.

# legend(xcoord.min*.995, ycoord.max*.995, 
# legend = c("[25, 45)","[45,65)", "[65, 85)", "[85, 100)"),
# fill = brewer.pal(4, "OrRd"), title = "Percent Increase", cex = .7, 
# bg = "green")

## Note: To place the legend in the left-center, do the same, but change the 
## proportion on the Y coordinate to .15.
 
# legend(xcoord.min*.995, ycoord.max*.15, 
# legend = c("[25, 45)","[45,65)", "[65, 85)", "[85, 100)"),
# fill = brewer.pal(5, "Reds"), title = "Percent Increase", cex = .7, 
# bg = "blue")


# 6. Create ray-glyph legend__________________________________________________

# Define coordinates of ray-glyph legend box
x.left = xcoord.max*.6
y.bottom = ycoord.min*.961
x.right = xcoord.max*.99
y.top = ycoord.min*.45

# Convert rectangle x,y coordinates to latitude and longitude for use with MyMap
lat.bottom = XY2LatLon(MyMap, x.left, y.bottom)[1]
lon.left = XY2LatLon(MyMap, x.left, y.bottom)[2] 
lat.top = XY2LatLon(MyMap, x.right , y.top )[1] 
lon.right = XY2LatLon(MyMap, x.right , y.top )[2]

# Function to draw lines for the ray-glyph legend
CalcRayGlyphLegendLatLon = function(angle1, angle2, lat, lon) {

	rad1 = angle1 * pi / 180
	lon1 = lon + 2 * cos(rad1)
	lat1 = lat + 2 * sin(rad1)

	rad2 = angle2 * pi / 180
	lon2 = lon + 2 * cos(rad2)
	lat2 = lat + 2 * sin(rad2)

	list = c(lat1 = lat1, lon1 = lon1, lat2 = lat2, lon2 = lon2)
}


# Ray-glyph legend function. "cexln" is the cex of the line. "lwdln" is the 
# line width. "ltyln1" and "ltyln2" are the respective line types.
PlotRayglyphLegend = function(llabel, rlabel, llevels, rlevels, lncolor1, 
                              lncolor2, circolor, title, levelscex = .9, 
                              titlecex = .9, labelscex = .9, circex = cexcir, 
                              lwdln = 2, lncircolor = "black") {
 #title
 text((x.right + x.left) / 2, y.top * 1.1, labels = title, bg = "gray", 
      cex = labelscex)
 # Left side variable 
 text((x.right + x.left) / 2 * .84, y.bottom * .58, labels = llabel, 
       cex = labelscex)
 # Right side variable
 text((x.right + x.left) / 2 * 1.14, y.bottom * .58, labels = rlabel, 
      cex = labelscex) 
 for (i in 0:4) { 
  # Left lines
	PlotOnStaticMap(MyMap, 
	  lat = c(lat.bottom * 1.19 + i * 1.5, 
            CalcRayGlyphLegendLatLon(270 - i * 45, 270 - i * 45, 
                                     lat.bottom * 1.19 + i * 1.5, 
                                     (lon.right + lon.left) / 2)[3]), 
 	  lon = c((lon.right + lon.left)/2 - .1, 
            CalcRayGlyphLegendLatLon(270 - i * 45, 270 - i * 45, 
                                     lat.bottom * 1.15 + i * 1.5, 
                                     (lon.right + lon.left) / 2)[4]),
	  FUN = lines, col = lncolor1, add = TRUE, pch = pchcir, cex = circex, 
    lwd = lwdln) 
  # Right lines
	PlotOnStaticMap(MyMap, 
	  lat = c(lat.bottom * 1.19 + i * 1.5, 
            CalcRayGlyphLegendLatLon(270 + i * 45, 270 + i * 45, 
            lat.bottom * 1.19 + i * 1.5, (lon.right + lon.left) / 2)[3]), 
	  lon = c((lon.right + lon.left) / 2 + .1, 
            CalcRayGlyphLegendLatLon(270 + i * 45, 270 + i * 45, 
                                     lat.bottom * 1.15 + i * 1.5, 
                                     (lon.right + lon.left) / 2)[4]),
	  FUN = lines, col = lncolor2, add = TRUE, pch = pchcir, cex = circex, 
    lwd = lwdln)
  # circles  
	PlotOnStaticMap(MyMap, lat.bottom * 1.19 + i * 1.5, 
                  (lon.right + lon.left) / 2,
	  FUN = points, col = circolor, add = TRUE, pch = pchdot, cex = circex) 
	# outline circles  
	PlotOnStaticMap(MyMap, lat.bottom * 1.19 + i * 1.5, 
                  (lon.right + lon.left) / 2,
	  FUN = points, col = lncircolor, add = TRUE, pch = pchcir, cex = circex) 
	# Left side levels
  text((x.right + x.left) / 2 * .84, y.top * 1.95 + i * 20, 
       labels = llevels[1 + i], cex = labelscex) 
  # Right side levels         
	text((x.right + x.left) / 2 * 1.16, y.top * 1.95 + i * 20, 
       labels = rlevels[1 + i], cex = labelscex) 
 }
}

# Rectangle background, with form 
rect(x.left, y.bottom, x.right, y.top-28, col = "grey")

# Define values & generic labels
min1 = min(data[2])
max1 = max(data[2])
qtr1 = round((max1 - min1) * .25 + min1)
qtr2 = round((max1 - min1) * .5 + min1)
qtr3 = round((max1 - min1) * .75 + min1)
min2 = min(data[3])
max2 = max(data[3])
qtr21 = round((max2 - min2) * .25 + min2)
qtr22 = round((max2 - min2) * .5 + min2)
qtr23 = round((max2 - min2) * .75 + min2)


# Run the ray-glyph legend function. Change title and labels.

## Note: If labels run outside the bounds of the legend box you will have to 
## manually adjust the rectangle background above.  

PlotRayglyphLegend(llabel = ~underline(Value), rlabel = ~underline(Revenue),
                   title = "", 
                   llevels = c(min1, qtr1, qtr2, qtr3, max1),
                   rlevels = c(min2, qtr21, qtr22, qtr23, max2),
                   circolor = palcircle[4],
                   lncolor1 = lncolor1,
                   lncolor2 = lncolor2	 
)
    
    
# 7. Plot title_______________________________________________________________

# First shift down the margins so the title appears closer to the top of
# United States. 

# par(mar = c(0, 0, 12.5, 0)) 
# title(main = "Ray-Glyph Plot Showing Major League Baseball Valuations \nand 
#      Revenue ($mil) in 2007 (Forbes.com)")  # \n starts a new line 

dev.off()

