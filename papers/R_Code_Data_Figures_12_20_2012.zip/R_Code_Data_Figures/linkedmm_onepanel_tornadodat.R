# Linked micromap plots  (one statistical panel)
# By         Mike Minnotte (revised for current data by Nathan Voge)
#             
#
#            1 Import functions and data
#            2 Extract state names and sort the data
#            3 Colors and Graphics Device


# 1. Import needed functions and data_______________________________________

# read in data
# web link to data:  http://sciencepolicy.colorado.edu/sourcebook/tornadoes.html

State = c("Alabama", "Arizona", "Arkansas", "California", "Colorado", "Connecticut",
          "Delaware", "Florida", "Georgia", "Idaho", "Illinois", "Indiana", "Iowa",
          "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts",
          "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska",
          "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York",
          "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon",
          "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota",
          "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington",
          "West Virginia", "Wisconsin", "Wyoming")
          # Puerto Rico, Hawaii, Alaska were eliminated from the data set as 
          # they aren't included on the map
          
Cost = c(51.88, 3.469, 40.96, 3.682, 4.623, 2.26, 0.2744, 37.32, 51.68, 0.2552, 62.94,
         53.13, 49.51, 49.28, 24.84, 27.75, 0.5252, 2.329, 4.418, 29.88, 84.84, 43.62,
         68.93, 2.266, 30.26, 0.0953, 0.6592, 2.94, 1.485, 15.73, 14.9, 14.69, 44.36,
         81.94, 5.52, 17.11, 0.0898, 17.19, 10.64, 23.47, 88.6, 3.565, 0.2416, 7.416,
         2.374, 2.143, 31.33, 1.779)

torn = data.frame(State, Cost)       

# read in data via file, torn = read.csv("tornado_alpha.csv", header = TRUE)
                                                 

library(RColorBrewer)
library(maps)  # load map data


data(state)  # load state data


# 2. Extract state names and sort the data (high to low)______________________

tornado = torn[, 2]  # extract data
tornado.state = torn[, 1]   # get state names
tornado.name = tornado.state[order(tornado, decreasing = T)]
tornado = sort(tornado, decreasing = TRUE)

# 3. Start Graphics Device and Define Colors____________________________________

pal = brewer.pal(6, "Set1")  # rainbow colors
pal[6] = "#DDDDDD"  # gray

# save it as a .pdf (looks better)
pdf("Tornado_micromap_18Jul.pdf", width = 7.5, height = 10)

# create the layout
layout(matrix(1:36, nrow = 12, byrow = TRUE), widths = c(1, 1, 2),
       heights = c(rep(4, 5), 1, rep(4, 5), 3))

# visualize the layout: layout.show(36)

# loop that draws maps and plot everything
for (i in 1:10) {  # start of loop for each of the i panels, ends on line 159

 # compute colors
 par(mex = 0.5, mar = rep(.01, 4))

 # define colors above/below median to be gray (pal[6]) 
 if (i <= 5)  
   m.col = c(rep(pal[6], 25), rep(0, 25))
 else 
   m.col = c(rep(0, 25), rep(pal[6], 25))

 # define other colors on map (column 1)
 if (i <= 4) 
   m.col[(i-1) * 5 + 1:5] = pal[1:5]
 else if (i == 5) 
   m.col[(i-1) * 5 + 1:4] = pal[1:4]
 else if (i == 6) 
   m.col[(i-1) * 5 - 1 + 1:4] = pal[1:4]
 else 
   m.col[(i-1)*5 - 2 + 1:5] = pal[1:5]

 map.m.col = m.col[match.map("state", as.character(tornado.name))]
 
 # plot map
 map("state", fill = TRUE, col = map.m.col, border = 1,
     xlim = c(-125, -65), ylim = c(25, 50)) 

# plot labels (column 2)  
 par(mar = rep(.1, 4))
 plot(0, 0, xlim = c(0, 1), ylim = c(0, 1), type = "n", bty = "n",
      xaxt = "n", yaxt = "n", xlab = "", ylab = "")

 if (i <= 4) 
   points(rep(.1, 5), seq(.9, .1, by = -.2), pch = 21, bg = pal[1:5], cex = 2)
 else if (i == 5)  # notice in i==5/6, we change seq(...) and pal[...] because 
                   # there are only 4 states/dots here. This is repeated below.
   points(rep(.1, 4), seq(.8, .2, by = -.2), pch = 21, bg = pal[1:4], cex = 2) 
 else if (i == 6) 
   points(rep(.1, 4), seq(.8, .2, by = -.2), pch = 21, bg = pal[1:4], cex = 2)
 else 
   points(rep(.1, 5), seq(.9, .1, by = -.2), pch = 21, bg = pal[1:5], cex = 2)

 if (i <= 4) 
   text(rep(.18, 5), seq(.9, .1, by = -.2), tornado.name[(i-1) * 5 + 1:5], 
        pos = 4, cex = 1.0)
 else if (i == 5) 
   text(rep(.18, 4), seq(.8, .2, by = -.2), tornado.name[(i-1) * 5 + 1:4], 
        pos = 4, cex = 1.0)
 else if (i == 6) 
   text(rep(.18, 4), seq(.8, .2, by = -.2), tornado.name[(i-1) * 5 - 1 + 1:4], 
        pos = 4, cex = 1.0)
 else 
   text(rep(.18, 5), seq(.9, .1, by = -.2), tornado.name[(i-1) * 5 - 2 + 1:5], 
        pos = 4, cex = 1.0)

# plot dotplot of values (column 3)
 par(mar = rep(.1, 4))
 if (i == 10) 
   plot(0, 0, xlim = range(tornado), ylim = c(0, 1), type = "n", yaxt = "n", 
        xlab = "", ylab = "")
 else 
   plot(0, 0, xlim = range(tornado), ylim = c(0, 1), type = "n", xaxt = "n", 
        yaxt = "n", xlab = "", ylab = "")

 if (i <= 4)  
   abline(h = seq(.9, .1, by = -.2), lty = 3, col = "grey")
 else if (i == 5) 
   abline(h = seq(.8, .2, by = -.2), lty = 3, col = "grey")
 else if (i == 6) 
   abline(h = seq(.8, .2, by = -.2), lty = 3, col = "grey")
 else 
   abline(h = seq(.9, .1, by = -.2), lty = 3, col = "grey")

 if (i <= 4) 
   points(tornado[(i-1) * 5 + 1:5], seq(.9, .1, by = -.2), pch = 21, 
          bg = pal[1:5], cex = 2)
 else if (i == 5) 
   points(tornado[(i-1) * 5 + 1:4], seq(.8, .2, by = -.2), pch = 21, 
          bg = pal[1:4], cex = 2)
 else if (i == 6) 
   points(tornado[(i-1) * 5 - 1 + 0:3], seq(.8, .2, by = -.2), pch = 21, 
          bg = pal[1:4], cex = 2)
 else 
   points(tornado[(i-1) * 5 - 2 - 2 + 1:5], seq(.9, .1, by = -.2), pch = 21, 
          bg = pal[1:5], cex = 2)

# separate states above and below median, j is the columns, i the rows
 if (i == 5) {
   for (j in 1:3){
     plot(0, 0, xlim = c(0, 1), ylim = c(0, 1), type = "n", bty = "n", 
          xaxt = "n", yaxt = "n", xlab = "", ylab = "")
     abline(h = .5, lwd = 3, col = pal[6])
   }
 }

# Plot through remaining (empty) cells
 if (i == 10) 
   for (j in 1:3)
     plot(0, 0, xlim = c(0, 1), ylim = c(0, 1), type = "n", bty = "n", 
          xaxt = "n", yaxt = "n", xlab = "", ylab = "")
}  # end of loop


# Label for dot plots
text(0.5, 0.35, "Property Damage Due to \nTornadoes in Millions of Dollars", 
     cex = 1.5)

dev.off()

