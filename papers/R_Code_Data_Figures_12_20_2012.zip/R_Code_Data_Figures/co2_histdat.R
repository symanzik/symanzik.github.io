# CO2 Histogram
# By         Nathan Voge
#             
#
#            1 Import functions and data
#            2 Draw plots, define colors, create breaks

# 1. Import needed functions and data_______________________________________

library(grDevices)
library(RColorBrewer)
library(maptools) 

data(wrld_simpl)       

CO2 = c(19.9, 17.0, 16.0, 11.0, 10.2, 10.0, 9.7, 9.1, 9.0, 8.8, 8.1, 8.0, 7.6, 7.3, 6.8, 6.1, 5.1, 4.8,
        4.6, 3.9, 3.9, 3.8, 3.7, 3.6, 2.8, 2.5, 2.5, 2.3, 1.8, 1.7, 1.4, 1.2, 1.0, 0.9, 0.9, 0.8, 0.7,
        0.5, 0.3, 0.3, 0.2 ,0.2, 0.2, 0.2, 0.1, 0.1, 0.0, 0.0)            
            
co2.2 = as.numeric(CO2)  

# read in data via a file, co2.2 = read.csv("CO2_2.csv", header = TRUE) 
        

# 2. Draw plots, define colors, create breaks_____________________________________

brewcol = brewer.pal(6, "Oranges")  # define colors

breaks = c(-.5, 2.5, 5.5, 8.5, 11.5, 14.5, 17.5, 20.5)

print(paste("Histogram of World", ~CO[2], "Emissions"))

# save it as a .pdf (looks better)
pdf("co2.2_18Jul_hist.pdf", width = 11, paper = "USr")

hist(co2.2, breaks = breaks, 
     xlab = "Amount of"~CO[2]~"(metric tons per person)", ylim = c(0, 25), xlim = range(breaks), 
     xaxt = "n", main = "")

# optional title: ("Histogram of World" ~CO[2]~"Emissions")

axis(1, at = breaks, labels = c("-.5", "2.5", "5.5", "8.5", 
                                "11.5", "14.5", "17.5", "20.5"))
                                
# shut down the current graphic device so can save as a pdf
dev.off()                                 
