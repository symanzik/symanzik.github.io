# Google Map Featuring Ray-Glyph Lines
# By         Nathan Voge (based on work by Daniel B. Carr (ray-glyphs) and
#                         Markus Loecher (RgoogleMaps))
#             
#
#            1 Import functions and data
#            2 Create a Google map
#            3 Add ray-glyph lines to the map
#            4 Add colored circles depicting percent increase to the map
#            5 Create percent increase legend    
#            6 Create ray-glyph legend
#            7 Plot title    

# 1. Import needed functions and data_________________________________________

# load in required packages
library(RColorBrewer)
library(RgoogleMaps)
library(PBSmapping)

# read in data
University = c("Kansas", "Texas", "Arizona", "Ohio State", "Cal-Davis",
             "Cal-Santa Barbara", "Iowa State", "Minnesota", "UCLA", "Iowa",
             "Illinois", "Cal-San Diego", "Virginia", "Cal-Irvine", "Colorado",
             "Purdue", "Wisconsin", "North Carolina", "Penn State", "Pittsburgh",
             "Indiana", "Cal-Berkeley", "Nebraska", "Missouri", "Maryland",
             "Michigan State", "Washington", "Oregon", "Rutgers", "Michigan",
             "Florida", "Buffalo")

Year_2000 = c(2725, 3575, 2348, 4383, 4072, 3832, 3132, 4877, 3698, 3204, 4994, 3848, 4335,
             3970, 3188, 3872, 3791, 2768, 7018, 7002, 4405, 4047, 3450, 4726, 5136, 5432,
             3761, 3819, 6333, 6926, 2256, 4715)

Year_2005 = c(5413, 6972, 4498, 8082, 7457, 6997, 5634, 8622, 6504, 5612, 8634, 6685,
              7370, 6770, 5372, 6458, 6284, 4613, 11508, 11436, 7112, 6512, 5540, 7415,
              7821, 8108, 5610, 5613, 9221, 9798, 3094, 6068)
              
Latitude = c(38.953611, 30.28614, 32.231667, 40, 38.54, 34.41254, 42.023949,
             44.975278, 34.072222, 41.655833, 40.110539, 32.881, 38.035, 33.64535,
             40.006667, 40.424, 43.075, 35.908333, 40.796036, 40.444565, 39.1661583,
             37.87, 40.8175, 38.9453, 38.9875, 42.723387, 47.6599, 44.044044,
             40.741632, 42.283, 29.64833, 42.9286688)
             
Longitude = c(-95.26, -97.73942, -110.951944, -83.0145, -121.75, -119.84813,
              -93.647595, -93.234167, -118.444097, -91.525, -88.228411, -117.238,
              -78.505, -117.842642, -105.267222, -86.929, -89.417222, -79.05,
              -77.862739, -79.953274, -86.5263857, -122.259, -96.701389, -92.3288,
              -76.94, -84.481366, -122.306, -123.075736, -74.17486, -83.735,
              -82.34944, -78.8480905)
              
Percent_Increase = c(0.9864, 0.9502, 0.9157, 0.8439, 0.8313, 0.8259, 0.7989, 0.7679,
                     0.7588, 0.7516, 0.7289, 0.7373, 0.7001, 0.7053, 0.6851, 0.6679,
                     0.6576, 0.6665, 0.6398, 0.6332, 0.6145, 0.6091, 0.6058, 0.5690,
                     0.5228, 0.4926, 0.4916, 0.4698, 0.4560, 0.4147, 0.3715, 0.2870)

data = data.frame(University, Year_2000, Year_2005, Latitude, Longitude,
                  Percent_Increase)

# read in data via a file, tuit = read.csv("tuition.csv", header = TRUE)


# 2. Create a Google map______________________________________________________

# Define x and y coordinates on map. In all RgoogleMaps packages, the latitude
# is read first followed by the longitude. For our data set, we looked up the 
# latitude and longitude online for each university.
x = data["Latitude"]
y = data["Longitude"]

# Define the bounding box (bb) for the map using the latitude and longitude from 
# our data set.
bb = qbbox(x, y, TYPE = "all", margin = list(m = rep(5, 4), 
           TYPE = c("perc", "abs")[1]))

# Create a Google map by loading a static map from the package and define 
# some options. bb$lonR, bb$latR are our latitude and longitude from the 
# previous line of code. We have a few choices on the type of map we want to use 
# such as "roadmap", "satellite", "terrain", etc. The default is a color map, 
# here we want it to be gray so we use the "GRAYSCALE" argument. If needed, we 
# can also use the "zoom" argument. This zooms in/out around the area we 
# define by using the argument "center".  

# save it as a .pdf (looks better)
pdf("tuit_18Jul_map.pdf", width = 7, paper = "USr")


MyMap = GetMap.bbox(bb$lonR, bb$latR, maptype = "roadmap", GRAYSCALE = TRUE)

# This command plots the map in the graphics window in R
PlotOnStaticMap(MyMap)

## Note: Content is added to the static map by using "PlotOnStaticMap".  
# "PlotOnStaticMap" is repeated for each color/item added to the map. "FUN" 
# identifies the plotting function, usually points or lines. "pch" and "cex" 
# normal plotting parameters. 


# 3. Add Ray-glyph lines to the map___________________________________________

# Function to Calculate the Latitude and Longitude for Ray-glyph Lines 
# It uses the two variables you want to compare (var1, var2), the latitude
# and longitude for these variables (lat, lon), and the minimum and maximum
# of the two variables (min1, max1, min2, max2) respectively. It returns the
# latitude and longitude of the point away from the origin for each variable.

CalcRayGlyphMapLatLon = function(var1, var2, lat, lon, min1, max1, min2, 
                                   max2) {
	num1 = var1 - min1
	ratio1 = num1 / (max1 - min1)
	angle1 = 270 - ratio1 * 180
	rad1 = angle1 * pi / 180
	lon1 = lon + 2 * cos(rad1)
	lat1 = lat + 2 * sin(rad1)
	
	num2 = var2 - min2
	ratio2 = num2 / (max2 - min2)
	angle2 = 270 + ratio2 * 180
	rad2 = angle2 * pi / 180
	lon2 = lon + 2 * cos(rad2)
	lat2 = lat + 2 * sin(rad2)

	list = c(lat1 = lat1, lon1 = lon1, lat2 = lat2, lon2 = lon2)		
 }

# Function to Plot Ray-glyph lines. 
# "variable" is the plotting parameter. "lncolor1" is the color of the left 
# line. "lncolor2" is the color of the right line. "cexln" is the cex of the 
# line. "lwdln" is the line width. "ltyln1" and "ltyln2" and the respective 
# line types.
 
PlotRayGlyphLines = function(data, variable, lncolor1, lncolor2, cexln = 1.5, 
                          lwdln = 2, ltyln1 = 1, ltyln2 = 1) {
 colselect = subset(data, select = variable)
 for (i in 1:nrow(colselect)) {
	loc = data[colselect[i, ], ] # select each location
	PlotOnStaticMap(MyMap, 
	      lat = c(as.numeric(loc[4]), 
            as.numeric(CalcRayGlyphMapLatLon(loc[2], loc[3], loc[4], loc[5], 
                       min(data[2]), max(data[2]), min(data[3]), 
                       max(data[3]))[1])), 
	      lon = c(as.numeric(loc[5]) - .1, 
            as.numeric(CalcRayGlyphMapLatLon(loc[2], loc[3], loc[4], loc[5], 
                       min(data[2]), max(data[2]), min(data[3]), 
                       max(data[3]))[2]) - .1),
	      FUN = lines, col = lncolor1, add = TRUE, pch = 1, cex = cexln, 
            lwd = lwdln, lty = ltyln1) #Line on left
 	PlotOnStaticMap(MyMap, 
            lat = c(as.numeric(loc[4]), 
            as.numeric(CalcRayGlyphMapLatLon(loc[2], loc[3], loc[4], loc[5], 
                       min(data[2]), max(data[2]), min(data[3]),                
                       max(data[3]))[3])), 
            lon = c(as.numeric(loc[5]) + .1, 
            as.numeric(CalcRayGlyphMapLatLon(loc[2], loc[3], loc[4], loc[5], 
                       min(data[2]), max(data[2]), min(data[3]), 
                       max(data[3]))[4]) + .1),
	      FUN = lines, col = lncolor2, add = TRUE, pch = 1, cex = cexln, 
            lwd = lwdln, lty = ltyln2) #Line on right
 }
}

# Define color scheme for ray-glyph lines
palgreen = brewer.pal(9, "Greens")
lncolor1 = palgreen[8]
lncolor2 = palgreen[5]

# Run PlotRayGlyphLines function and plot ray-glyph lines. Change plotting
# variable. ("University" here)
PlotRayGlyphLines(data = data, variable = "University", lncolor1, lncolor2)



# 4. Add colored circles depicting percent increase to the map________________

# Function to Plot Colored Circles Outlined in Black.
# Data*[,4] and data*[,5] contain the latitude and longitude for each 
# respective level (*), which are our breaks in the data. 
# After many tries, we found 4 levels most useful 
# for our data set. "subset" allows us to identify how we want to divide up the
# data with "Percent_Increase" being our variable of interest. 
# Here we put black circles around the colors to make them more visible. 
# "pch = 1" is a circle. "cexcir" is the cex of the circles. "pchdot" is the pch
# of the dot. "pchcir" is the pch of the circle

## Note:  The data in "Percent_Increase" was not provided by the original data
## set. 
 
PlotPoints = function(data, cexcir = 1.5, pchdot = 19, pchcir = 1) {
  for (i in 1:4) {
    if (i == 1) {
	    data1 = subset(data, Percent_Increase >= .25 & Percent_Increase < .45)
	    PlotOnStaticMap(MyMap, data1[, 4], data1[, 5], FUN = points, 
	                    col = palcircle[i], add = TRUE, pch = pchdot, cex = cexcir)
	    PlotOnStaticMap(MyMap, data1[,4], data1[,5], FUN = points, 
                          col = "black", add = TRUE, pch = pchcir, cex = cexcir, 
                          lwd = 1)
	  }  
    else if (i == 2) {
	    data2 = subset(data,Percent_Increase>=.45 & Percent_Increase<.65)
	    PlotOnStaticMap(MyMap, data2[,4], data2[,5], FUN = points, 
                          col = palcircle[i], add = TRUE, pch = pchdot, 
                          cex = cexcir)
	    PlotOnStaticMap(MyMap, data2[,4], data2[,5], FUN = points, 
                          col = "black", add = TRUE, pch = pchcir, cex = cexcir, 
                          lwd = 1)
	  }
    else if (i == 3) {
     	data3 = subset(data,Percent_Increase>=.65 & Percent_Increase<.85)
	    PlotOnStaticMap(MyMap, data3[,4], data3[,5], FUN = points, 
	                    col = palcircle[i], add = TRUE, pch = pchdot, 
                          cex = cexcir)
	    PlotOnStaticMap(MyMap, data3[,4], data3[,5], FUN = points, 
                          col = "black", add = TRUE, pch = pchcir, cex = cexcir,
                          lwd = 1)
	  }
    else if (i == 4) {
	    data4 = subset(data,Percent_Increase>=.85 & Percent_Increase<1.0)
	    PlotOnStaticMap(MyMap, data4[,4], data4[,5], FUN = points,
	                   col = palcircle[i], add = TRUE, pch = pchdot, 
                         cex = cexcir)
	    PlotOnStaticMap(MyMap, data4[,4], data4[,5], FUN = points,
	                   col = "black", add = TRUE, pch = pchcir, cex = cexcir, 
                         lwd = 1)
	  }
  }
}

# Run PlotPoints function and plot dots/circles. 

# Define color scheme for our circles. We used the website 
# http://colorbrewer2.org to identify an appropriate color scheme with 4 levels.
palcircle = brewer.pal(4, "OrRd")
cexcir = 1.5
pchdot = 19
pchcir = 1


# Run colored circles function
PlotPoints(data, cexcir, pchdot, pchcir)

## Note: If data doesn't have a percent increase variable, use the below code 
## to plot the circles

# PlotOnStaticMap(MyMap, data[,4], data[,5], FUN = points,
#	            col = palcircle[4], add = TRUE, pch = pchdot, cex = cexcir)
# PlotOnStaticMap(MyMap, data[,4], data[,5], FUN = points,
#	            col = "black", add = TRUE, pch = pchcir, cex = cexcir, 
#                 lwd = 1)


# 5. Create percent increase legend___________________________________________ 

# The x and y coordinates of the legend box are based on 
# the latitude and longitude of the static map from Google. The 
# function "LatLon2XY.centered" transforms latitude and longitude into x and 
# y coordinates on the map. 
# LatLon2XY.centered(MyMap,MyMap$BBOX$ll[1],MyMap$BBOX$ll[2])$newX and 
# LatLon2XY.centered(MyMap,MyMap$BBOX$ll[1],MyMap$BBOX$ll[2])$newY give the 
# lower left-corner coordinates of the static map. We use a fraction of
# them (.995, .61 respectively) to shift the legend to its default location.

# Define computed coordinates used on map (not RgoogleMaps/MyMap)
xcoord.max = LatLon2XY.centered(MyMap,MyMap$BBOX$ll[1], MyMap$BBOX$ur[2])$newX
xcoord.min = LatLon2XY.centered(MyMap,MyMap$BBOX$ll[1], MyMap$BBOX$ll[2])$newX
ycoord.max = LatLon2XY.centered(MyMap,MyMap$BBOX$ur[1], MyMap$BBOX$ll[2])$newY
ycoord.min = LatLon2XY.centered(MyMap,MyMap$BBOX$ll[1], MyMap$BBOX$ll[2])$newY


# Legend for percent increase  
legend(xcoord.min * .995, ycoord.min * .61, 
       legend = c("[25, 45)", "[45, 65)", "[65, 85)", "[85, 100)"),
       fill = brewer.pal(4, "OrRd"), title = "Percent Increase", cex = .8, 
       bg = "grey")


## Note: To put the legend in the top left corner we need change the Y and use
## MyMap$BBOX$ur[1] as the new reference point that gives us the Y coordinate
## in the "upper right" corner. But we just want Y (the latitude). So
## MyMap$BBOX$ll[2] stays the same. We also change the Y proportion to .995.

# legend(xcoord.min*.995, ycoord.max*.995, 
# legend = c("[25, 45)", "[45, 65)", "[65, 85)", "[85, 100)"),
# fill = brewer.pal(4, "OrRd"), title = "Percent Increase", cex = .7, 
# bg = "green")

## Note: To place the legend in the left-center, do the same, but change the 
## proportion on the Y coordinate to .15.
 
# legend(xcoord.min*.995, ycoord.max*.15, 
# legend = c("[25, 45)", "[45, 65)", "[65, 85)", "[85, 100)"),
# fill = brewer.pal(5, "Reds"), title = "Percent Increase", cex = .7, 
# bg = "blue")


# 6. Create ray-glyph legend__________________________________________________

# Define coordinates of ray-glyph legend box
x.left = xcoord.max*.6
y.bottom = ycoord.min*.961
x.right = xcoord.max*.99
y.top = ycoord.min*.45

# Convert rectangle x,y coordinates to latitude and longitude for use with MyMap
lat.bottom = XY2LatLon(MyMap, x.left, y.bottom)[1]
lon.left = XY2LatLon(MyMap, x.left, y.bottom)[2] 
lat.top = XY2LatLon(MyMap, x.right , y.top )[1] 
lon.right = XY2LatLon(MyMap, x.right , y.top )[2]

# Function to draw lines for the ray-glyph legend
CalcRayGlyphLegendLatLon = function(angle1, angle2, lat, lon) {

	rad1 = angle1 * pi / 180
	lon1 = lon + 2 * cos(rad1)
	lat1 = lat + 2 * sin(rad1)

	rad2 = angle2 * pi / 180
	lon2 = lon + 2 * cos(rad2)
	lat2 = lat + 2 * sin(rad2)

	list = c(lat1 = lat1, lon1 = lon1, lat2 = lat2, lon2 = lon2)
}


# Ray-glyph legend function. "cexln" is the cex of the line. "lwdln" is the 
# line width. "ltyln1" and "ltyln2" are the respective line types.
PlotRayglyphLegend = function(llabel, rlabel, llevels, rlevels, lncolor1, 
                              lncolor2, circolor, title, levelscex = .8, 
                              titlecex = .8, labelscex = .8, circex = cexcir, 
                              lwdln = 2, lncircolor = "black") {
 #title
 text((x.right + x.left) / 2, y.top * 1.1, labels = title, bg = "gray", 
      cex = labelscex)
 # Left side variable 
 text((x.right + x.left) / 2 * .84, y.bottom * .58, labels = llabel, 
       cex = labelscex)
 # Right side variable
 text((x.right + x.left) / 2 * 1.14, y.bottom * .58, labels = rlabel, 
      cex = labelscex) 
 for (i in 0:4) { 
  # Left lines
	PlotOnStaticMap(MyMap, 
	  lat = c(lat.bottom * 1.19 + i * 1.5, 
            CalcRayGlyphLegendLatLon(270 - i * 45, 270 - i * 45, 
                                     lat.bottom * 1.19 + i * 1.5, 
                                     (lon.right + lon.left) / 2)[3]), 
 	  lon = c((lon.right + lon.left)/2 - .1, 
            CalcRayGlyphLegendLatLon(270 - i * 45, 270 - i * 45, 
                                     lat.bottom * 1.15 + i * 1.5, 
                                     (lon.right + lon.left) / 2)[4]),
	  FUN = lines, col = lncolor1, add = TRUE, pch = pchcir, cex = circex, 
    lwd = lwdln) 
  # Right lines
	PlotOnStaticMap(MyMap, 
	  lat = c(lat.bottom * 1.19 + i * 1.5, 
            CalcRayGlyphLegendLatLon(270 + i * 45, 270 + i * 45, 
            lat.bottom * 1.19 + i * 1.5, (lon.right + lon.left) / 2)[3]), 
	  lon = c((lon.right + lon.left) / 2 + .1, 
            CalcRayGlyphLegendLatLon(270 + i * 45, 270 + i * 45, 
                                     lat.bottom * 1.15 + i * 1.5, 
                                     (lon.right + lon.left) / 2)[4]),
	  FUN = lines, col = lncolor2, add = TRUE, pch = pchcir, cex = circex, 
    lwd = lwdln)
  # circles  
	PlotOnStaticMap(MyMap, lat.bottom * 1.19 + i * 1.5, 
                  (lon.right + lon.left) / 2,
	  FUN = points, col = circolor, add = TRUE, pch = pchdot, cex = circex) 
	# outline circles  
	PlotOnStaticMap(MyMap, lat.bottom * 1.19 + i * 1.5, 
                  (lon.right + lon.left) / 2,
	  FUN = points, col = lncircolor, add = TRUE, pch = pchcir, cex = circex) 
	# Left side levels
  text((x.right + x.left) / 2 * .84, y.top * 1.95 + i * 20, 
       labels = llevels[1 + i], cex = labelscex) 
  # Right side levels         
	text((x.right + x.left) / 2 * 1.16, y.top * 1.95 + i * 20, 
       labels = rlevels[1 + i], cex = labelscex) 
 }
}

# Rectangle background, with form 
rect(x.left, y.bottom, x.right, y.top, col = "grey")

# Define values & generic labels
min1 = min(data[2])
max1 = max(data[2])
qtr1 = round((max1 - min1) * .25 + min1)
qtr2 = round((max1 - min1) * .5 + min1)
qtr3 = round((max1 - min1) * .75 + min1)
min2 = min(data[3])
max2 = max(data[3])
qtr21 = round((max2 - min2) * .25 + min2)
qtr22 = round((max2 - min2) * .5 + min2)
qtr23 = round((max2 - min2) * .75 + min2)
levelscex = .8 
titlecex = .8
labelscex = .8

# Run the ray-glyph legend function. Change title and labels.

## Note: If labels run outside the bounds of the legend box you will have to 
## manually adjust the rectangle background above.  

PlotRayglyphLegend(llabel = ~underline(2000), rlabel = ~underline(2005),
                   title = "Tuition Trend from\n 2000 to 2005", 
                   llevels = c(min1, qtr1, qtr2, qtr3, max1),
                   rlevels = c(min2, qtr21, qtr22, qtr23, max2),
                   circolor = palcircle[4],
                   lncolor1 = lncolor1,
                   lncolor2 = lncolor2	 
)
    
    
# 7. Plot title_______________________________________________________________

# First shift down the margins so the title appears closer to the top of
# United States. 

# par(mar = c(0, 0, 12.5, 0)) 
# title(main = "Ray-Glyph Plot Showing Cost of Tuition and\n Percent Increase from 2000 to 2005")  
# \n starts a new line 

dev.off()

