# World Choropleth Map
# By         Juergen Symanzik (revised for current data by Nathan Voge)
#             
#
#            1 Import functions and data
#            2 Sort the data and assign colors
#            3 Draw map, plot data, make titles, and create a legend


# 1. Import needed functions and data_______________________________________

library(RColorBrewer)
brew.color = brewer.pal(6, "Oranges")

library(maptools) 
data(wrld_simpl)

# read in data

Country = c("United States", "Australia", "Canada", "Saudi Arabia",
            "Russia", "Germany", "Korea, Republic of", "Japan",
            "United Kingdom", "Korea, Democratic People's Republic of",
            "South Africa", "Poland", "Ukraine", "Italy", "Spain", "France",
            "Venezuela", "Uzbekistan", "Malaysia", "Argentina", "Romania", "Iran",
            "Mexico", "Iraq", "Turkey", "China", "Thailand", "Algeria", "Brazil",
            "Egypt", "Columbia", "Indonesia", "Morocco", "India", "Philippines",
            "Peru", "Pakistan", "Vietnam", "Kenya", "Nigeria", "Bangladesh",
            "Ghana", "Myanmar", "Sudan", "Nepal", "Tanzania", "Congo", "Ethiopia")
            
            # changed some of the country names in the data set to match the 
            # map. Ex. United States, Russia, Rep. of Korea

CO.2 = c(19.9, 17.0, 16.0, 11.0, 10.2, 10.0, 9.7, 9.1, 9.0, 8.8, 8.1, 8.0, 7.6, 7.3, 6.8, 6.1, 5.1, 4.8,
        4.6, 3.9, 3.9, 3.8, 3.7, 3.6, 2.8, 2.5, 2.5, 2.3, 1.8, 1.7, 1.4, 1.2, 1.0, 0.9, 0.9, 0.8, 0.7,
        0.5, 0.3, 0.3, 0.2, 0.2, 0.2, 0.2, 0.1, 0.1, 0.0, 0.0)                  
            
co2.2 = data.frame(Country, CO.2) 

# read in data via a file, co2 = read.csv("CO2_2.csv", header = TRUE)
 

# extract country names and CO2 values 
country.data = (co2.2[, 1])  # countries of data set, 48 here
country.co2 = (co2.2[, 2])
country.map = wrld_simpl$NAME  # countries' names as coded in wrld_simpl data 
                               # set, contains 246 countries. Make sure 
                               # countries' names in data sets match (spelled 
                               # the same etc.), use: for (i in 1:104)
                               # print(grep(country.data[i],country.map)) 
n.map = length(country.map) 
color.map = numeric(n.map) 


# 2. Sort the data and assign colors__________________________________________

# use "grep" to match country.data with country.map and assign a color level
for (i in 1:length(country.data)){ 
  if (country.co2[i] >= 16)
    color.map[grep(country.data[i], country.map)] = 6
  else if (country.co2[i] >= 8.8)
    color.map[grep(country.data[i], country.map)] = 5
  else if (country.co2[i] >= 6.1)
    color.map[grep(country.data[i], country.map)] = 4
  else if (country.co2[i] >= 2.5)
    color.map[grep(country.data[i], country.map)] = 3
  else if (country.co2[i] >= 0)
    color.map[grep(country.data[i], country.map)] = 2
} 

# collect countries with actual scores (not equal to zero) as listed in 
# country.data 
collected.countries = (color.map != 0) 
color.map2 = color.map 

# assign colors
color.map2[!collected.countries] = brew.color[1] # use light grey for countries 
                                                 # not listed in country.data 
                                                 # object 
color.map2[collected.countries] = brew.color[color.map[collected.countries]] 


# 3. Draw map, plot data, make titles, and create a legend____________________

# save it as a .pdf (looks better)
pdf("co2.2_18Jul_Map.pdf", width = 11, paper = "USr")

# plot map
plot(wrld_simpl, col = color.map2, axes = FALSE, ylim = c(-55, 90))

# create a legend
legend(-180, -15, legend = c("N/A", "[0, 2.5)", "[2.5, 5.5)", "[5.5, 8.5)", 
  "[8.5, 11.5)", "[11.5, 20]"), fill = brewer.pal(6, "Oranges"), bg = "white")

# make a title at the top  
# par(mar = c(0, 0, 12.5, 0))
# title("Carbon Dioxide Emissions (metric tons per person)")

# shut down the current graphic device so can save as a pdf
dev.off() 

